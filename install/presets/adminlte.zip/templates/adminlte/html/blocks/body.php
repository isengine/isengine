<?php

namespace is;
use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Parser;
use is\Masters\View;

$view = View::getInstance();

$class = null;
$fixed = Parser::fromString($view -> get('vars|fixed'));

if (System::typeIterable($fixed)) {
	if (Objects::match($fixed, 'layout')) {
		$class .= ' layout-fixed';
	}
	if (Objects::match($fixed, 'navbar')) {
		$class .= ' layout-navbar-fixed';
	}
	if (Objects::match($fixed, 'footer')) {
		$class .= ' layout-footer-fixed';
	}
}

if ($view -> get('vars|dark')) {
	$class .= ' dark-mode';
}

?>
<!--
`body` tag options:

  Apply one or more of the following classes to to the body tag
  to get the desired effect

  * sidebar-collapse
  * sidebar-mini
-->
<body class="hold-transition sidebar-mini<?= $class; ?>">