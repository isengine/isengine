<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$variant = $view -> get('vars|variant');

?>
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $view -> get('layout') -> launch('blocks', 'control-sidebar'); ?>
<?php $view -> get('layout') -> launch('blocks', 'footer'); ?>

</div>
<!-- ./wrapper -->

<?php $view -> get('layout') -> launch('blocks', 'scripts' . $variant); ?>

</body>
</html>