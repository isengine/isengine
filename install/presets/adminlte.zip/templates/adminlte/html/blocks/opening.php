<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$variant = $view -> get('vars|variant');

?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php $view -> get('layout') -> launch('blocks', 'head' . $variant); ?>
</head>
<?php $view -> get('layout') -> launch('blocks', 'body'); ?>
<div class="wrapper">
<?php $view -> get('layout') -> launch('blocks', 'preloader'); ?>
<?php $view -> get('layout') -> launch('blocks', 'nav'); ?>
<?php $view -> get('layout') -> launch('blocks', 'aside'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

<?php $view -> get('layout') -> launch('blocks', 'content-header'); ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">