<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$animation = $view -> get('vars|preloader');

if (!$animation) {
	return;
}

?>
  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__<?= $animation; ?>" src="/dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>