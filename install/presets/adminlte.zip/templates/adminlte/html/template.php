<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Paths;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

//$view -> get('layout') -> launch('blocks:default', 'items:opening');
//$view -> get('layout') -> launch('blocks', 'opening');

$view -> get('layout') -> launch('blocks:default', 'items:routing');

//$view -> get('layout') -> launch('blocks:default', 'items:ending');
//$view -> get('layout') -> launch('blocks', 'ending');

?>