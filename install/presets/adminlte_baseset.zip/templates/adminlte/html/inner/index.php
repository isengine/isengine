<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="container-fluid">
	<?php $view -> get('block') -> launch('widgets:small-box'); ?>
	<div class="row">
		<section class="col-lg-7 connectedSortable">
			<?php $view -> get('block') -> launch('main:charts-with-tabs'); ?>
			<?php $view -> get('module') -> launch('data', 'adminlte-direct-chat'); ?>
			<?php $view -> get('block') -> launch('main:to-do-list'); ?>
		</section>
		<section class="col-lg-5 connectedSortable">
			<?php $view -> get('block') -> launch('main:map-card'); ?>
			<?php $view -> get('block') -> launch('main:solid-sales-graph'); ?>
			<?php $view -> get('block') -> launch('main:calendar'); ?>
		</section>
	</div>
</div>