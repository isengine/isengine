<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

//System::debug($this -> settings);

$view -> get('display') -> addBuffer('
');

$view -> get('display') -> addBuffer('
');

?>