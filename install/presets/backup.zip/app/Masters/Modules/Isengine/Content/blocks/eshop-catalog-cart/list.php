<?php

namespace is\Masters\Modules\Isengine\Content;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Local;
use is\Helpers\Paths;
use is\Helpers\Prepare;
use is\Helpers\Sessions;

use is\Masters\View;

$view = View::getInstance();

$data = $item -> getData();

$name = $item -> getEntryKey('name');
$parents = Strings::join($item -> getEntryKey('parents'), '/');
$id = ($parents ? Strings::join($item -> getEntryKey('parents'), ':') . ':' : null) . $name;
$val = Sessions::getCookie(Prepare::urlencode($id));

$image = $data['image'] ? $data['image'] : '/content/' . $parents . '/' . $name . '.jpg';
$link = '/' . $parents . '/' . $name . '/';

$data['price'] = System::set($data['price']) ? Objects::sort($data['price']) : [];
$price = [
	'current' => $data['sale'] ? ceil($data['price'][0] - $data['price'][0] / 100 * $data['sale']) : $data['price'][0],
	'old' => $data['sale'] ? $data['price'][0] : $data['price'][1],
	'sale' => null
];
$price['sale'] = $price['old'] ? ceil(100 - (100 * $price['current'] / $price['old'])) : null;
if ($price['old'] == $price['current']) {
	$price['old'] = null;
	$price['sale'] = null;
}

?>
<div class="col-12 py-2 item" data-step="<?= $data['step']; ?>" data-name="<?= $id; ?>" data-price="<?= $price['current']; ?>" data-price-old="<?= $price['old']; ?>" is-parent="item" is-name="<?= $id; ?>">
	<div class="row align-items-center justify-content-between">
		
		<div class="d-none d-sm-block col-sm-1 px-0">
			<a href="<?= $link ?>" class="item-link">
			<div class="item-image">
				<?= $view -> get('tvars') -> launch('{img|' . ($data['image'] ? $data['image'] : $image) . ':/content/catalog/default.jpg:lazyload w-100:' . $data['title'] . '}'); ?>
			</div>
			</a>
		</div>
				
		<div class="col-4 col-md-6 text-start">
			<a href="<?= $link ?>" class="item-link color-dark">
				<span class="item-title">
					<?= $data['title'] . ($data['description'] ? ', ' . $data['description'] : null); ?>
				</span>
			</a>
		</div>
		
		<div class="col-8 col-sm-7 col-md-5">
			<div class="row item-cart flex-nowrap align-items-center justify-content-between">
				
			<?php if ($price['current']) { ?>
				<div class="col-7 col-sm-6">
					<div class="row">
					
					<a href="javascript:void(0);" class="col-auto item-cart__button item-cart__dec btn btn-round bg-second">
						-
					</a>
					
					<input type="text" name="" class="col item-cart__input border-0 px-0 px-sm-2 py-2 mx-2 text-center" value="<?= $val && $val > 0 ? $val : 0; ?>">
					
					<a href="javascript:void(0);" class="col-auto item-cart__button item-cart__inc btn btn-round bg-second">
						+
					</a>
					
					</div>
				</div>
				
				<div class="col-auto item-price">
					<?php if ($price['current']) { ?>
						<span class="item-price_el"><?= $price['current'] * $val; ?></span>&nbsp;₽
					<?php } ?>
					<?php if ($price['old']) { ?>
						<span class="item-price_old color-grey ps-1 d-block d-sm-inline"><s><span class="item-price_old_el"><?= $price['old'] * $val; ?></span>&nbsp;₽</s></span>
					<?php } ?>
				</div>
				
				<a href="javascript:void(0);" class="col-auto item-cart__del btn p-0">
					<i class="bi bi-trash"></i>
				</a>
				
			<?php } else { ?>
				<span class="col-12 item-price__none color-grey d-block">
					нет в наличии
				</span>
			<?php } ?>
			
			</div>
		</div>
		
	</div>
</div>