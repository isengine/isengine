<?php

namespace is\Masters\Modules\Isengine\Content;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Local;
use is\Helpers\Paths;
use is\Helpers\Prepare;
use is\Helpers\Sessions;

use is\Masters\View;

$view = View::getInstance();

$data = $item -> getData();

$name = $item -> getEntryKey('name');
$parents = Strings::join($item -> getEntryKey('parents'), '/');
$id = ($parents ? Strings::join($item -> getEntryKey('parents'), ':') . ':' : null) . $name;
$val = Sessions::getCookie(Prepare::urlencode($id));

$image = $data['image'] ? $data['image'] : '/content/' . $parents . '/' . $name . '.jpg';
$link = '/' . $parents . '/' . $name . '/';

$data['price'] = System::set($data['price']) ? Objects::sort($data['price']) : [];
$price = [
	'current' => $data['sale'] ? ceil($data['price'][0] - $data['price'][0] / 100 * $data['sale']) : $data['price'][0],
	'old' => $data['sale'] ? $data['price'][0] : $data['price'][1],
	'sale' => null
];
$price['sale'] = $price['old'] ? ceil(100 - (100 * $price['current'] / $price['old'])) : null;
if ($price['old'] === $price['current']) {
	$price['old'] = null;
	$price['sale'] = null;
}

?>
<div class="col-6 col-sm-4 col-lg-3 p-2 item" is-parent="item" is-name="<?= $id; ?>">
	<div class="p-3 item-inner d-flex flex-column justify-content-between">
		
		<?php if ($price['sale'] || $data['special']) { ?>
		<div class="item-badges d-flex flex-column align-items-end">
			<?php Objects::each($data['special'], function($item){ ?>
				<span class="d-block mb-1 badge bg-theme"><?= $item; ?></span>
			<?php }); ?>
			<?php if ($price['sale']) { ?>
				<span class="d-block mb-1 badge bg-second">скидка <?= $price['sale']; ?>%</span>
			<?php } ?>
		</div>
		<?php } ?>
		
		<div class="item-icons d-flex flex-column align-items-end">
			<a href="javascript:void(0);" class="item-icons__button fs-5">
				<i class="bi bi-star"></i>
			</a>
			<a href="javascript:void(0);" class="item-icons__button fs-5">
				<i class="bi bi-bar-chart"></i>
			</a>
		</div>
		
		<div class="item-info h-100">
			<a href="<?= $link ?>" class="item-link d-flex flex-column h-100">
				<div class="item-image">
					<?= $view -> get('tvars') -> launch('{img|' . ($data['image'] ? $data['image'] : $image) . ':/content/catalog/default.jpg:lazyload contain:' . $data['title'] . '}'); ?>
				</div>
				<h3 class="h6 item-title">
					<span is-data="title"><?= $data['title'] . ($data['description'] ? ', ' . $data['description'] : null); ?></span>
				</h3>
				<div class="item-price<?= $price['current'] ? ' mt-auto' : null; ?>">
					<?php if ($price['old']) { ?>
						<span class="item-price__old d-block"><s is-data="price-old"><?= $price['old']; ?> ₽</s></span>
					<?php } ?>
					<?php if ($price['current']) { ?>
						<span is-data="price" class="item-price__current"><?= $price['current']; ?> ₽</span>
						<span class="item-price__units">за 1 <span is-data="units"><?= $data['units']; ?></span></span>
					<?php } else { ?>
						<span class="item-price__none d-block">
							нет в наличии
						</span>
					<?php } ?>
				</div>
			</a>
		</div>
			
		<div class="item-cart" data-step="<?= $data['step']; ?>" data-name="<?= $id; ?>" data-price="<?= $price['current']; ?>" data-price-old="<?= $price['old']; ?>" is-data-from="true">
			<?/*
			<div class="item-cart__block d-flex justify-content-<?= $price['current'] ? 'between' : 'end'; ?> mt-3">
				<?php if ($price['current']) { ?>
				<a href="" class="item-cart__buy flex-grow-1 btn bg-second fs-5 me-3">
					<i class="bi bi-cart-plus"></i>
				</a>
				<?php } ?>
				<a href="" class="btn item-cart__icon fs-5">
					<i class="bi bi-star"></i>
				</a>
				<a href="" class="btn item-cart__icon fs-5">
					<i class="bi bi-bar-chart"></i>
				</a>
			</div>
			*/?>
			<?php if ($price['current']) { ?>
				<div class="item-cart__block<?= $val && $val > 0 ? ' d-none' : null; ?> mt-3">
					<a href="javascript:void(0);" class="item-cart__buy w-100 flex-grow-1 btn bg-second" is-action="buy">
						в корзину
					</a>
				</div>
				<div class="item-cart__block<?= $val && $val > 0 ? null : ' d-none'; ?> d-flex justify-content-between mt-3">
					<a href="javascript:void(0);" class="item-cart__button item-cart__dec btn bg-second" is-action="dec">
						-
					</a>
					<input type="text" name="" class="item-cart__input w-100 border-0 text-center" value="<?= $val && $val > 0 ? $val : 0; ?>" is-data="value" is-action="enter">
					<a href="javascript:void(0);" class="item-cart__button item-cart__inc btn bg-second" is-action="inc">
						+
					</a>
				</div>
			<?php } ?>
		</div>
	</div>
</div>