<?php

namespace is\Masters\Modules\Isengine\Content;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

$cart = $view -> get('vars|cart');
$data = Objects::keys($cart);

$this -> data -> leaveByList($data, 'name');

?>
<div class="row flex-column justify-content-between eshop-cart" id="eshop-catalog-cart">
	<?php $this -> iterate(); ?>
</div>
<?/*
<div class="row flex-column justify-content-between bg-grey p-2">
	<div>
		Вы уже получаете
	</div>
	<div>
		Закажите на XXX р и получите
	</div>
	<div>
		от 500 - бесплатную доставку
		<br>
		от 1000 по 1% - XX р на бонусный счет
		<br>
		от 2000 - дополнительную скидку 10 %
		<br>
		от 3000 - промокод на следующую покупку на скидку 10%
		<br>
		от 2000 - промокод на покупки у наших партнеров
		<br>
		от 3000 - бесплатный подарок
		<br>
		по акции - подарок к празднику
		<br>
		от 5000 на 10% - любой товар на выбор на сумму до 500 р
		<br>
		что-то еще?..
	</div>
	<div>
		CURR р ======= NEED р
		осталось XXX р
	</div>
</div>
*/?>
<div class="row justify-content-between align-items-center py-2" id="eshop-catalog-cart-total">
	<div class="col fs-5">
		Итого товаров <strong class="eshop-catalog-cart-total-count">__</strong> на общую сумму <strong><span class="eshop-catalog-cart-total-price">____</span>&nbsp;₽</strong>
		<?php // + дополнительные скидки <strong>__</strong>, к оплате <strong>____ Р</strong> // это все при оформлении ?>
	</div>
	<div class="col-auto">
		<a href="/cart/" class="btn bg-theme">
			Оформить
		</a>
	</div>
</div>
