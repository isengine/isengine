<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\Datasheet;
use is\Masters\View;

$view = View::getInstance();

//$name = $item -> getEntryKey('name');
//$parents = Strings::join($item -> getEntryKey('parents'), '/');
//$id = ($parents ? Strings::join($item -> getEntryKey('parents'), ':') . ':' : null) . $name;
//$val = Sessions::getCookie(Prepare::urlencode($id));

$cart = $view -> get('vars|cart');
$cart_is = System::typeIterable($cart);

/*
Есть вопрос:
Мы формируем корзину - как будем брать информацию?
Конечно же через базу данных.
Но читать будем только те данные, которые нам нужны. Т.е.
фильтровать базу по name и parents

Но как теперь работает фильтр? Ведь раньше name был просто name
А теперь name состоит из parents:name, а точнее parent1:parent2:...:name

Так как теперь работает фильтр?

В то же время, как это будет работать, если включить кэширование запросов в бд???
Вариаций товаров будет миллион, и кэш раздуется до невероятных размеров

Можно ли ограничить кэширование? Т.е. отменить его только здесь?

Смотрим драйвер БД...
Нет, это надо делать через вызов модуля Контент
Нужно вызывать тот же модуль, что и при формировании контента,
с теми же настройками, но другим шаблоном,
принудительно выключать кэш контента и кэш модуля
и задавать фильтр по name
*/

?>

<div class="container pb-4<?= $cart_is ? ' d-none' : null; ?>">
	<div class="h1">В корзине ничего нет</div>
	<p class="fs-6">Для выбора товаров, перейдите в каталог</p>
	<p><a class="btn bg-theme btn-lg mt-4" href="/catalog/" role="button">В каталог</a></p>
</div>

<div class="container px-3<?= !$cart_is ? ' d-none' : null; ?>">
	<?php
		if ($cart_is) {
			$sets = '{
				"name" : null,
				"parents" : null,
				
				"filter" : {
					//"name" : "baklazhany:kabachki"
				},
				
				"routing" : null,
				"cookie" : false,
				"rest" : null
			}';
			$view -> get('module') -> launch('content', 'eshop-catalog:eshop-catalog-cart', $sets, null);
		}
	?>
</div>

<div class="container d-none" id="eshop-catalog-cart-template">
	<div class="col-12 py-2 item" data-step="" data-name="" data-price="" data-price-old="" is-parent="item" is-name="">
		<div class="row align-items-center justify-content-between">
			<div class="d-none d-sm-block col-sm-1 px-0">
				<a href="" class="item-link">
				<div class="item-image">
					<img src="" alt="" class="lazyload w-100">
				</div>
				</a>
			</div>
			<div class="col-4 col-md-6 text-start">
				<a href="" class="item-link color-dark">
					<span class="item-title"></span>
				</a>
			</div>
			<div class="col-8 col-sm-7 col-md-5">
				<div class="row item-cart flex-nowrap align-items-center justify-content-between">
					<div class="col-7 col-sm-6">
						<div class="row">
						<a href="javascript:void(0);" class="col-auto item-cart__button item-cart__dec btn btn-round bg-second">
							-
						</a>
						<input type="text" name="" class="col item-cart__input border-0 px-0 px-sm-2 py-2 mx-2 text-center" value="0">
						<a href="javascript:void(0);" class="col-auto item-cart__button item-cart__inc btn btn-round bg-second">
							+
						</a>
						</div>
					</div>
					<div class="col-auto item-price">
							<span class="item-price_el"></span>&nbsp;₽
							<span class="item-price_old color-grey ps-1 d-block d-sm-inline"><s><span class="item-price_old_el"></span>&nbsp;₽</s></span>
					</div>
					<a href="javascript:void(0);" class="col-auto item-cart__del btn p-0">
						<i class="bi bi-trash"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>