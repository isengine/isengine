<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<form>
	
	<div class="row justify-content-between align-items-center py-1">
		<div class="col-auto">
			<label for="exampleInputEmail1" class="col-form-label">Email</label>
		</div>
		<div class="col col-sm-auto">
			<input type="email" id="exampleInputEmail1" class="form-control" aria-describedby="emailHelp">
		</div>
	</div>
	
	<div class="row justify-content-between align-items-center py-1">
		<div class="col-auto">
			<label for="exampleInputPassword1" class="col-form-label">Пароль</label>
		</div>
		<div class="col col-sm-auto">
			<input type="password" id="exampleInputPassword1" class="form-control" aria-describedby="passwordHelpInline">
		</div>
	</div>
	
	<div class="row justify-content-between align-items-center py-1">
		<div class="col-auto">
			<div id="emailHelp" class="form-text text-start">
				<a href="" class="color-grey">Забыли пароль?</a><br><a href="" class="color-grey">Зарегистрироваться</a>
			</div>
		</div>
		<div class="col-auto">
			<button type="submit" class="btn bg-theme">Войти</button>
		</div>
	</div>
	
	
</form>