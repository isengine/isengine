<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

use is\Masters\View;

/*
<section class="container-fluid mb-2 pb-0 top-alert alert rounded-0" id="top-alert" role="alert">
	<div class="container">
		<div class="row">
			<div class="col">
				<?php Objects::each($this -> getData(), function($item) { ?>
					<div class="row pb-3">
						<div class="col">
							<?= $item; ?>
						</div>
					</div>
				<?php }); ?>
			</div>
			<div class="col-auto">
				<button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		</div>
	</div>
</section>
*/
?>

<?php $this -> iterate(function($item, $key, $pos){ ?>
<section class="container-fluid<?= $pos === 'alone' || $pos === 'last' ? ' mb-2' : ' mb-0'; ?><?= $item['class'] ? ' ' . $item['class'] : null; ?> top-alert alert rounded-0" id="top-alert-<?= $key; ?>" role="alert">
	<div class="container-md">
		<div class="row">
			<div class="col">
				<?= $item['message']; ?>
				<?php
					if ($item['link']) {
						$view = View::getInstance();
				?>
				<a href="<?= $item['link']; ?>" class="color-white">
					<u><?= $view -> get('lang|common:readmore'); ?></u>
				</a>
				<?php } ?>
			</div>
			<div class="col-auto">
				<button type="button" class="btn-close btn-close-white" id="top-alert-<?= $key; ?>-button" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		</div>
	</div>
	<?php if ($item['cookie']) { ?>
	<script>
		let button_<?= $key; ?> = document.getElementById("top-alert-<?= $key; ?>-button"); 
		button_<?= $key; ?>.onclick = function() {
			<?= $item['cookie']; ?>
			let block_<?= $key; ?> = document.getElementById("top-alert-<?= $key; ?>");
			block_<?= $key; ?>.remove();
		};
	</script>
	<?php } ?>
</section>
<?php }, null, null); ?>