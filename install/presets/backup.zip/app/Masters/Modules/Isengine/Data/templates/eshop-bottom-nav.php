<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;

use is\Masters\View;

$view = View::getInstance();
$url = $view -> get('state|url');

?>
<div class="row align-items-end justify-content-between flex-nowrap bottom-nav w-100 m-0 px-0 pb-2 py-3 text-center d-md-none">
	<?php Objects::each($this -> getData(), function($item, $key) use ($url) { ?>
	<a
	<?php if ($item['type'] === 'menu') { ?>
		href="#offcanvasCatalog" data-bs-toggle="offcanvas" role="button" aria-controls="offcanvasCatalog"
	<?php } else { ?>
		href="<?= $item['link'] ? $item['link'] : $url . '#'; ?>"
	<?php } ?>
	class="col color-mg<?= !$key ? ' active' : null; ?>">
		<i class="<?= $item['icon']; ?> fs-2"></i>
		<p class="p-0 m-0"><?= $item['title']; ?></p>
	</a>
	<?php }); ?>
</div>