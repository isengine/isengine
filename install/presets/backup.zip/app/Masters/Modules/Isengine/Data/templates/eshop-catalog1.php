<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

//echo print_r($this -> getData(), 1);

global $index;
$index = 0;

function isEshopCatalogNavFull($array) {
	Objects::each($array, function($item, $key) {
		global $index;
		$index++;
		$isarray = System::typeOf($item, 'iterable');
?>
	<div class="accordion-item">
		<div class="accordion-header my-1 " id="accordion-<?= $index; ?>">
			<?php if ($isarray) { ?>
			<button class="btn p-0 collapsed d-flex justify-content-between align-items-center w-100" type="button" data-bs-toggle="collapse" data-bs-target="#accordionCollapse-<?= $index; ?>" aria-expanded="false" aria-controls="accordionCollapse-<?= $index; ?>">
				<span class="color-nav px-1 text-start">
					<?= $key; ?>
				</span>
				<i class="bi-chevron-right rotate"></i>
			</button>
			<?php } else { ?>
			<a href="" class="color-nav p-1 d-block text-start">
				<?= $item; ?>
			</a>
			<?php } ?>
		</div>
		<?php if ($isarray) { ?>
		<div id="accordionCollapse-<?= $index; ?>" class="accordion-collapse collapse" aria-labelledby="accordion-<?= $index; ?>">
			<a href="" class="color-nav fs-6 fw-bold p-1 d-block">
				Все товары категории
			</a>
			<div class="accordion-body p-0">
				<?php isEshopCatalogNavFull($item); ?>
			</div>
		</div>
		<?php } ?>
	</div>
<?php 
	}, false);
}

function isEshopCatalogNavList($array) {
	Objects::each($array, function($item, $key) {
		$isarray = System::typeOf($item, 'iterable');
?>
		<a href="" class="color-nav d-block">
			<?= $isarray ? $key : $item; ?>
		</a>
		<?php if ($isarray) { ?>
		<?/*
		<div class="accordion-body d-flex flex-column mb-3">
		*/?>
		<div class="accordion-body mb-3">
			<?php isEshopCatalogNavList($item); ?>
		</div>
		<?php } ?>
<?php 
	}, false);
}
?>

<div class="row accordion" id="accordionNav">
	<div class="col-12 d-block d-md-none">
		<?php isEshopCatalogNavFull($this -> getData()); ?>
	</div>
	<div class="col-auto d-none d-md-block">
		<?php
			Objects::each(Objects::keys($this -> getData()), function($item, $key){
				$key++;
		?>
		<div class="accordion-item">
			<div class="accordion-header d-flex justify-content-between align-items-center" id="accordionList-<?= $key; ?>">
				<button class="btn py-0<?= $key === 1 ? '' : ' collapsed' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#accordionListCollapse-<?= $key; ?>" aria-expanded="false" aria-controls="accordionListCollapse-<?= $key; ?>">
					<span class="color-nav">
						<?= $item; ?>
					</span>
					<i class="bi-chevron-right translate"></i>
				</button>
			</div>
		</div>
		<?php }); ?>
	</div>
	<div class="col d-none d-md-block col-double">
		<?php
			Objects::each($this -> getData(), function($item, $key){
				static $index;
				$index++;
		?>
		<div id="accordionListCollapse-<?= $index; ?>" class="accordion-collapse collapse<?= $index === 1 ? ' show' : '' ?>" aria-labelledby="accordionList-<?= $index; ?>" data-bs-parent="#accordionNav">
			<div class="accordion-body">
				<a href="" class="color-nav h5 d-block">
					<?= $key; ?>
				</a>
				<a href="" class="color-nav fw-bold py-2 d-block">
					Все товары категории
				</a>
				<?php isEshopCatalogNavList($item); ?>
			</div>
		</div>
		<?php
			});
		?>
	</div>
</div>