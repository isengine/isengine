<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="about-wrap-layout1" data-bg-image="/img/about/background.jpg">
	<div class="container">
		<div class="row">
			<div class="about-box-layout1 order-xl-2 col-xl-5 col-12">
				<div class="item-content">
					<?php $view -> get('layout') -> launch('blocks', 'about:submain'); ?>
				</div>
			</div>
			<div class="about-box-layout2 order-xl-3 col-xl-4 col-lg-7 col-12">
				<?php $view -> get('module') -> launch('data', 'base-action:base-action-in-about'); ?>
			</div>
			<div class="about-box-layout2 order-xl-1 col-xl-3 col-lg-5 col-12">
				<div class="item-img">
					<?php $view -> get('layout') -> launch('blocks', 'about:image'); ?>
				</div>
			</div>
		</div>
	</div>
</section>