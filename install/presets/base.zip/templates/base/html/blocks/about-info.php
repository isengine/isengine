<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="about-wrap-layout2">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-12">
				<div class="about-box-layout3">
					<h2 class="item-title"><?= $view -> get('lang|this:about:title'); ?></h2>
					<?= $view -> get('lang|this:about:description'); ?>
				</div>
			</div>
			<div class="col-lg-8 col-12">
				<div class="row">
					<?php $view -> get('module') -> launch('data', 'base-info:base-info-in-about'); ?>
				</div>
			</div>
		</div>
	</div>
</section>