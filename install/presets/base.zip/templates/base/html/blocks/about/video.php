<?php

namespace is;

use is\Masters\View;

$view = View::getInstance();

$item = $view -> get('lang|this:about:video');

?>
<div class="item-video">
	<img src="https://img.youtube.com/vi/<?= $item; ?>/maxresdefault.jpg" alt="about">
	<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=<?= $item; ?>">
		<i class="fas fa-play"></i>
	</a>
</div>