<div class="item-inner-wrapper">
	<img src="/img/feature/title.jpg" class="img-responsive" alt="feature">
</div>