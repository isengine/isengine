<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="gallery-wrap-layout1 bg-light-secondary100">
	<?php $view -> get('module') -> launch('data', 'base-gallery'); ?> 
</section>