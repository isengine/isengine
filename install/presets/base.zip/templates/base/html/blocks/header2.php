<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Header Area Start Here -->
<header id="header_2">
	<div class="header-top-bar top-bar-border-bottom bg-light-primary100 d-none d-md-block">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 logo-area-layout2">
					<?php $view -> get('layout') -> launch('blocks', 'sub:top-logo'); ?>
				</div>
				<div class="col-lg-9 col-md-9 col-12 header-contact-layout2">
					<ul>
						<li>
							<div class="media">
								<i class="fas fa-map-marker-alt"></i>
								<div class="media-body space-sm">
									<div class="title"><?= $view -> get('lang|common:address', 'upperFirst'); ?></div>
									<div class="info"><?= $view -> get('lang|information:address'); ?></div>
								</div>
							</div>
						</li>
						<li>
							<div class="media">
								<i class="fas fa-phone"></i>
								<div class="media-body space-sm">
									<div class="title"><?= $view -> get('lang|common:phone', 'upperFirst'); ?></div>
									<div class="info"><?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-dark}'); ?></div>
								</div>
							</div>
						</li>
						<li>
							<div class="media">
								<i class="far fa-clock"></i>
								<div class="media-body space-sm">
									<div class="title"><?= $view -> get('lang|common:work', 'upperFirst'); ?></div>
									<div class="info"><?php $view -> get('layout') -> launch('blocks', 'sub:work-alone'); ?></div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="header-menu-area header-menu-layout2">
		<div class="container">
			<div class="row no-gutters d-flex align-items-center">
				<div class="col-md-9 position-static">
					<div class="template-main-menu">
						<?php //$view -> get('layout') -> launch('blocks', 'sub:nav'); ?>
						<?php $view -> get('module') -> launch('data', 'base-nav'); ?>
					</div>
				</div>
				<div class="col-md-3">
					<div class="header-action-items-layout2">
						<ul>
							<li class="d-none d-xl-block">
								<?php $view -> get('layout') -> launch('blocks', 'sub:search'); ?>
							</li>
							<li class="cart-area-dark">
								<?php $view -> get('layout') -> launch('blocks', 'sub:cart'); ?>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<!-- Header Area End Here -->