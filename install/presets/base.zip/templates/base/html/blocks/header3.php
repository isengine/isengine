<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Header Area Start Here -->
<header id="header_3">
	<div class="header-menu-area header-menu-layout3">
		<div class="container">
			<div class="row no-gutters d-flex align-items-center">
				<div class="col-lg-2 col-md-2 logo-area-layout1">
					<?php $view -> get('layout') -> launch('blocks', 'sub:top-logo-light'); ?>
				</div>
				<div class="col-lg-7 col-md-7 position-static">
					<div class="template-main-menu">
						<?php //$view -> get('layout') -> launch('blocks', 'sub:nav'); ?>
						<?php $view -> get('module') -> launch('data', 'base-nav'); ?>
					</div>
				</div>
				<div class="col-lg-3 col-md-3">
					<div class="header-action-items-layout1">
						<ul>
							<li class="d-none d-xl-block">
								<?php $view -> get('layout') -> launch('blocks', 'sub:search-light'); ?>
							</li>
							<li class="cart-area-light">
								<?php $view -> get('layout') -> launch('blocks', 'sub:cart'); ?>
							</li>
							<li>
								<a href="<?= $view -> get('lang|this:calltoaction:link'); ?>" class="action-items-light-btn ml-3"><?= $view -> get('lang|this:calltoaction:title'); ?></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<!-- Header Area End Here -->