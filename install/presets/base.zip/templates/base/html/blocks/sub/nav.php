<?php //module(['menu', 'header', null]); ?>
<nav id="dropdown">
	<ul>
		
		<li>
			<a href="#">Home</a>
			<ul class="dropdown-menu-col-1">
				<li><a href="/index/">Home 1</a></li>
				<li><a href="/index2/">Home 2</a></li>
				<li><a href="/index3/">Home 3</a></li>
				<li><a href="/index4/">Home 4</a></li>
			</ul>
		</li>
		<li>
			<a href="#">About</a>
			<ul class="dropdown-menu-col-1">
				<li><a href="/about1/">About 1</a></li>
				<li><a href="/about2/">About 2</a></li>
				<li><a href="/about3/">About 3</a></li>
			</ul>
		</li>                                        
		<li>
			<a href="#">Departments</a>
			<ul class="dropdown-menu-col-1">
				<li><a href="/departments1/">Departments 1</a></li>
				<li><a href="/departments2/">Departments 2</a></li>
				<li><a href="/departments3/">Departments 3</a></li>
				<li><a href="/single-departments/">Departments Details</a></li>
			</ul>
		</li>
		<li>
			<a href="#">Doctors</a>
			<ul class="dropdown-menu-col-1">
				<li><a href="/doctors1/">Doctors 1</a></li>
				<li><a href="/doctors2/">Doctors 2</a></li>
				<li><a href="/single-doctor/">Doctors Details</a></li>
			</ul>
		</li>
		
		<li class="position-static hide-on-mobile-menu">
			<a href="#">Pages</a>
			<div class="template-mega-menu">
				<div class="container">
					<div class="row">
						<div class="col-3">
							<div class="menu-ctg-title">Home</div>
							<ul class="sub-menu">
								<li><a href="/index/"><i class="fas fa-home"></i>Home 1</a></li>
								<li><a href="/index2/"><i class="fas fa-home"></i>Home 2</a></li>
							</ul>
							<div class="menu-ctg-title">About</div>
							<ul class="sub-menu">
								<li><a href="/about/"><i class="fab fa-cloudversify"></i>About</a></li>
							</ul>
							<div class="menu-ctg-title">Doctors</div>
							<ul class="sub-menu">
								<li><a href="/doctors1/"><i class="fas fa-user-md"></i>Doctors 1</a></li>
							</ul>
						</div>
						<div class="col-3">
							<ul class="sub-menu">
								<li><a href="/doctors2/"><i class="fas fa-user-md"></i>Doctors 2</a></li>
								<li><a href="/single-doctor/"><i class="fas fa-user-md"></i>Doctors Details</a></li>
							</ul>
							<div class="menu-ctg-title">Departments</div>
							<ul class="sub-menu">
								<li><a href="/departments1/"><i class="fas fa-hospital"></i>Department 1</a></li>
								<li><a href="/departments2/"><i class="fas fa-hospital"></i>Department 2</a></li>
								<li><a href="/departments3/"><i class="fas fa-hospital"></i>Department 3</a></li>
								<li><a href="/single-departments/"><i class="fas fa-hospital"></i>Department Details</a></li>
							</ul>
						</div>
						<div class="col-3">
							<div class="menu-ctg-title">Pages</div>
							<ul class="sub-menu">
								<li><a href="/gallery/"><i class="fas fa-clone"></i>Gallery</a></li>
								<li><a href="/appointment/"><i class="far fa-calendar-check"></i>Appointment</a></li>
								<li><a href="/price-table/"><i class="far fa-money-bill-alt"></i>Price Table</a></li>
								<li><a href="/shop/"><i class="fas fa-shopping-basket"></i>Shop</a></li>
								<li><a href="/single-shop/"><i class="fas fa-shopping-basket"></i>Shop Details</a></li>
								<li><a href="/contacts/"><i class="fas fa-envelope"></i>Contacts</a></li>
							</ul>
						</div>
						<div class="col-3">
							<ul class="sub-menu">
								<li><a href="/faq/"><i class="fas fa-file-archive"></i>Faq List</a></li>
								<li><a href="/404/"><i class="fas fa-exclamation-triangle"></i>404 Error</a></li>
								<li><a href="/coming-soon/"><i class="fas fa-sort-amount-up"></i>Coming Soon</a></li>
							</ul>
							<div class="menu-ctg-title">News</div>
							<ul class="sub-menu">
								<li><a href="/news1/"><i class="far fa-newspaper"></i>News 1</a></li>
								<li><a href="/news2/"><i class="far fa-newspaper"></i>News 2</a></li>
								<li><a href="/single-news/"><i class="far fa-newspaper"></i>News Details</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</li>
		
		<li class="hide-on-desktop-menu">
			<a href="#">Pages</a>
			<ul>
				<li><a href="/gallery/">Gallery</a></li>
				<li><a href="/appointment/">Appointment</a></li>
				<li><a href="/price-table/">Price Table</a></li>
				<li><a href="/shop/">Shop</a></li>
				<li><a href="/single-shop/">Shop Details</a></li>
				<li><a href="/faq/">Faq List</a></li>
				<li><a href="/404/">404 Error</a></li>
				<li><a href="/coming-soon/">Coming Soon</a></li>
			</ul>
		</li>
		
		<li>
			<a href="#">News</a>
			<ul class="dropdown-menu-col-1">
				<li><a href="/news1/">News 1</a></li>
				<li><a href="/news2/">News 2</a></li>
				<li><a href="/single-news/">News Details</a></li>
			</ul>
		</li>
		
		<li><a href="/contacts/">Contacts</a></li>
		
	</ul>
</nav>