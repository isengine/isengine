<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="appointment-wrap-layout1 bg-light-accent100">
	<div class="container">
		<div class="row no-gutters">
			<div class="col-xl-6">
				<div class="appointment-box-layout1">
					<h2 class="title title-bar-primary2"><?= $view -> get('lang|this:appointment:title'); ?></h2>
					<p><?= $view -> get('lang|this:appointment:description'); ?></p>
					<?php $view -> get('module') -> launch('data', 'base-form-appointment'); ?>
				</div>
			</div>
			<div class="col-xl-6">
				<div class="appointment-banner">
					<img src="/img/appointment/title.png" alt="appointment" class="img-fluid">
				</div>
			</div>
		</div>
	</div>
</section>
