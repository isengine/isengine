<div id="wrapper" class="wrapper">
	<!-- Coming Soon Page Area Start Here -->
	<section class="comingsoon-page">
		<div class="comingsoon-back-img"></div>
		<div class="comingsoon-content-wrap">
			<div class="comingsoon-content">
				<div class="comingsoon-logo">
					<img src="/img/logo-light.png" alt="logo">
				</div>
				<h1>We Are Coming Soon!</h1>
				<div class="countdown-layout1">
					<div id="countdown"></div>
				</div>
				<div class="comingsoon-newsletter">
					<div class="input-group stylish-input-group justify-content-center">
						<input type="email" placeholder="Enter your e-mail" name="email" class="form-control"
							required="">
						<span class="input-group-addon">
							<button type="submit">
								Subscribe
							</button>
						</span>
					</div>
				</div>
				<div class="comingsoon-bottom">
					<div class="container">
						<div class="row">
							<div class="col-md-6 col-12">
								<div class="comingsoon-social">
									<ul>
										<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
										<li><a href="#"><i class="fab fa-twitter"></i></a></li>
										<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
										<li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
										<li><a href="#"><i class="fab fa-skype"></i></a></li>
										<li><a href="#"><i class="fab fa-youtube"></i></a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-6 col-12">
								<div class="comingsoon-copy-right">
									<p>Copyright @ 2018 medilink. All Rights Reserved.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Coming Soon Page Area End Here -->
</div>