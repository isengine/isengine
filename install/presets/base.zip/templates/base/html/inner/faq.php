<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="faq-wrap-layout1">
	<div class="container">
		<div class="row">
			<div class="col-xl-6 col-lg-7 col-12">
				<div class="faq-content-layout1">
					<div class="item-heading">
						<h2 class="item-title title-bar-primary4"><?= $view -> get('lang|this:faq:title'); ?></h2>
						<p class="sub-title"><?= $view -> get('lang|this:faq:description'); ?></p>
					</div>
					<div class="faq-list-layout1">
						<?php $view -> get('module') -> launch('data', 'base-faq:base-accordeon'); ?>
					</div>
				</div>
			</div>
			<div class="col-xl-6 col-lg-5 d-none d-lg-block">
				<div class="faq-img-layout1">
					<?php $view -> get('layout') -> launch('blocks', 'about:image'); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="faq-wrap-layout2 bg-light-accent100">
	<div class="container">
		<div class="row justify-content-center d-flex">
			<div class="col-lg-8">
				<div class="faq-ask-question-layout1">
					<h2 class="title"><?= $view -> get('lang|this:faq:form'); ?></h2>
					<?php $view -> get('module') -> launch('data', 'base-form-faq'); ?>
				</div>
			</div>
		</div>
	</div>
</section>