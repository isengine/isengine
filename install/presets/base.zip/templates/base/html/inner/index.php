<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header1');
$view -> get('module') -> launch('data', 'base-slider');
$view -> get('layout') -> launch('blocks', 'about-action');
$view -> get('module') -> launch('data', 'base-services:base-services-carousel');
$view -> get('layout') -> launch('blocks', 'feature2');
$view -> get('module') -> launch('data', 'base-progress');
$view -> get('module') -> launch('data', 'base-award');
$view -> get('module') -> launch('data', 'base-team');
$view -> get('module') -> launch('data', 'base-schedule');
$view -> get('layout') -> launch('blocks', 'banner1');
$view -> get('module') -> launch('data', 'base-testimonials:base-testimonials-news');
$view -> get('layout') -> launch('blocks', 'banner3');

?>