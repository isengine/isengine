<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header2');
$view -> get('module') -> launch('data', 'base-slider:base-slider4');
$view -> get('module') -> launch('data', 'base-action');
$view -> get('layout') -> launch('blocks', 'about-info');
$view -> get('module') -> launch('data', 'base-services:base-services-slider');
$view -> get('module') -> launch('data', 'base-indicators:base-indicators2');
$view -> get('module') -> launch('data', 'base-progress');
$view -> get('module') -> launch('data', 'base-schedule');
$view -> get('module') -> launch('data', 'base-testimonials');
$view -> get('layout') -> launch('blocks', 'gallery:normal');
$view -> get('layout') -> launch('blocks', 'banner1');
$view -> get('module') -> launch('data', 'base-news');
$view -> get('module') -> launch('data', 'base-brands');

?>