<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header3');
$view -> get('module') -> launch('data', 'base-slider:base-slider3');
$view -> get('module') -> launch('data', 'base-info:base-info2');
$view -> get('layout') -> launch('blocks', 'about-video');
$view -> get('module') -> launch('data', 'base-services:base-services2');
$view -> get('layout') -> launch('blocks', 'feature');
$view -> get('module') -> launch('data', 'base-progress');
$view -> get('module') -> launch('data', 'base-team2');
$view -> get('module') -> launch('data', 'base-award');
$view -> get('layout') -> launch('blocks', 'gallery:normal');
$view -> get('layout') -> launch('blocks', 'banner3');
$view -> get('module') -> launch('data', 'base-testimonials:base-testimonials-news');
$view -> get('module') -> launch('data', 'base-brands');

?>