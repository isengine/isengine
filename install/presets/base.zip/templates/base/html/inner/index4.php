<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header4');
$view -> get('module') -> launch('data', 'base-slider:base-slider2');
$view -> get('module') -> launch('data', 'base-info:base-info-in-previous');
$view -> get('layout') -> launch('blocks', 'about');
$view -> get('module') -> launch('data', 'base-services:base-services-more');
$view -> get('module') -> launch('data', 'base-progress');
$view -> get('module') -> launch('data', 'base-award');
$view -> get('module') -> launch('data', 'base-team3');
$view -> get('module') -> launch('data', 'base-schedule');
$view -> get('module') -> launch('data', 'base-indicators');
$view -> get('module') -> launch('data', 'base-shop');
$view -> get('module') -> launch('data', 'base-testimonials');
$view -> get('module') -> launch('data', 'base-news:base-news2');
$view -> get('layout') -> launch('blocks', 'banner4');

?>