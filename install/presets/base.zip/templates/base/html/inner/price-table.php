<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="pricing-wrap-layout1 bg-light-accent100">
	<div class="container">
		<div class="section-heading heading-dark text-center heading-layout3">
			<h2><?= $view -> get('lang|this:plans:title'); ?></h2>
			<p><?= $view -> get('lang|this:plans:description'); ?></p>
		</div>
		<?php $view -> get('module') -> launch('data', 'base-plans'); ?>
	</div>
</section>
<?php $view -> get('layout') -> launch('blocks', 'banner4'); ?>