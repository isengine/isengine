<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="departments-wrap-layout8">
	<div class="container">
		<div class="row">
			<?php $view -> get('module') -> launch('data', 'base-services:base-services-main2'); ?>
		</div>
	</div>
</section>

<?php $view -> get('layout') -> launch('blocks', 'banner2'); ?>