<?php
namespace is\Helpers;

class Math {

	static public function random() {
		
		// функция получения случайного числа
		
		return rand(1000, 9999);
		
	}

}

?>