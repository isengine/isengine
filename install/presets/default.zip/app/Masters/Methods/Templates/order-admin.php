<?php

namespace is\Masters\Methods\Templates;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;

use is\Helpers\Prepare;

use is\Components\Globals;

// читаем глобальные данные
$globals = Globals::getInstance();
$total = $globals -> get('total');
$order = $globals -> get('order');
//$print = $globals -> get('print');

$print = '<table>
<thead>
<tr>
	<th>№</th>
	<th>Название</th>
	<th>Кол-во</th>
	<th>Сумма</th>
	<th>Расчет</th>
</tr>
</thead>
<tbody>
';

$index = 0;
foreach ($order as $item) {
	$index++;
	//$print .= '[' . $index . '] : ' . $item['title'] . ', ' . $item['value'] . ' ' . $item['units'] . ' - ' . $item['price']['total'] . ' руб (' . $item['value'] . ' x ' . $item['price']['current'] . ' руб)<br>';
	$print .= '<tr>
		<td>' . $index . '</td>
		<td>' . $item['title'] . '</td>
		<td>' . $item['value'] . ' ' . $item['units'] . '</td>
		<td>' . $item['price']['total'] . ' руб</td>
		<td>' . $item['value'] . ' x ' . $item['price']['current'] . ' руб</td>
	</tr>';
}
unset($index, $item);
$print .= '
<tbody>
</table>
<style>
	table {
		width: 100%;
	}
	table th {
		background-color: #eee;
	}
	table td {
		
	}
	table th,
	table td {
		border: 1px solid #ccc;
		padding: 0.5em 1em;
	}
</style>
';

$map = null;
$coords = $this -> message['coords'];
if ($coords) {
	$coords = Strings::split($coords, ':');
	$coords = $coords[1] . '%2C' . $coords[0];
	$map = '<a href="https://yandex.ru/maps/?ll=' . $coords . '&mode=whatshere&whatshere%5Bpoint%5D=' . $coords . '&whatshere%5Bzoom%5D=16&z=16" target="blank">открыть карту</a>';
}

$email = $this -> message['email'];
$phone = $this -> message['phone'];

$message = Strings::combine([
	'Имя заказчика' => $this -> message['name'],
	'Адрес' => $this -> message['address'],
	'Адрес на карте' => $map,

	'Телефон' => $phone ? '<a href="tel:' . $phone . '" target="blank">' . $phone . '</a> | <a href="https://wa.me/' . Prepare::numeric($phone) . '" target="blank">написать в whatsapp (если есть)</a>' : 'не указан',
	'Email' => $email ? '<a href="mailto:' . $email . '" target="blank">' . $email . '</a>' : 'не указан',
	'Время' => 'с ' . $this -> message['time-from'] . ' до ' . $this -> message['time-to'],

	'Примечания к заказу' => '<br>' . $this -> message['message'],
	'Состав заказа' => '<div class="row">' . $print . '</div>',
	'Итого' => $total . '&nbsp;₽',

	'Дата' => date('d.m.Y H:i'),
	'Сессия' => 'current:' . Sessions::getCookie('current-url') . ' | previous: . ' . Sessions::getCookie('previous-url')
], '<br>', ' : ');

file_put_contents(DR . 'app' . DS . 'Orders' . DS . date('Y-m-d_H-i-s_') . mt_rand(100, 999) . '_' . Prepare::numeric($phone) . '.ini', $message);

$this -> message = $message;

?>