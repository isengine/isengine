<?php

namespace is\Masters\Methods\Templates;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;

use is\Helpers\Prepare;

use is\Components\Globals;

// читаем глобальные данные
$globals = Globals::getInstance();
$total = $globals -> get('total');
$order = $globals -> get('order');
//$print = $globals -> get('print');

$style = '
<style>
	table {
		width: 100%;
	}
	table th {
		background-color: #eee;
	}
	table td {
		
	}
	table th,
	table td {
		border: 1px solid #ccc;
		padding: 0.5em 1em;
	}
</style>
';

$notice = '
<h2>Ваш заказ на ' . System::server('host') . ' принят в работу!</h2>
<p style="color: #bb3742;">Все заказы, созданные после 13:00, будут доставлены на следующий день.</p>
<hr>
<h4>Детали заказа</h4>
<hr>
';

$print = '<table>
<thead>
<tr>
	<th>№</th>
	<th>Название</th>
	<th>Кол-во</th>
	<th>Сумма</th>
	<th>Расчет</th>
</tr>
</thead>
<tbody>
';

$index = 0;
foreach ($order as $item) {
	$index++;
	//$print .= '[' . $index . '] : ' . $item['title'] . ', ' . $item['value'] . ' ' . $item['units'] . ' - ' . $item['price']['total'] . ' руб (' . $item['value'] . ' x ' . $item['price']['current'] . ' руб)<br>';
	$print .= '<tr>
		<td>' . $index . '</td>
		<td>' . $item['title'] . '</td>
		<td>' . $item['value'] . ' ' . $item['units'] . '</td>
		<td>' . $item['price']['total'] . ' руб</td>
		<td>' . $item['value'] . ' x ' . $item['price']['current'] . ' руб</td>
	</tr>';
}
unset($index, $item);
$print .= '
<tbody>
</table>
';

$email = $this -> message['email'];
$phone = $this -> message['phone'];

$message = Strings::combine([
	'Ваше имя' => $this -> message['name'],
	'Указанный телефон' => $phone ? $phone : 'не указан',
	'Указанный адрес' => $this -> message['address'],
	'Дата составления заказа' => date('d.m.Y H:i'),
	'Примечания к заказу' => '<p>' . $this -> message['message'] . '</p>',
	'Состав заказа' => '<br>' . $print . '<br>'
], '<br>', ' : ');

$end = '
<h4>Итого: ' . $total . '&nbsp;₽</h4>
<p style="color: #bb3742;">В связи с тем, что ФАКТИЧЕСКИЙ вес обычно ОТЛИЧАЕТСЯ от заказанного, итоговая сумма пересчитывается и может меняться как в большую, так и в меньшую сторону.</p>
';

$this -> message = '<html><head>' . $style . '</head><body>' . $notice . $message . $end . '</body></html>';

?>