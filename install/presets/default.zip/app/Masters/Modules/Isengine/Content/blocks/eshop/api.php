<?php

namespace is\Masters\Modules\Isengine\Content;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Components\Globals;

$data = $item ? $item -> getData() : ['price' => ['current' => true]];

$globals = Globals::getInstance();

$total = $globals -> get('total');
$total += $data['price']['total'];
$globals -> set('total', $total);
$globals -> set('order', [$data['id'] => $data]);

$print = '
<div class="col-12">
	<a href="' . System::server('domain') . $data['link'] . '">
		' . $data['title'] . '
	</a>
	<p>
		(' . $data['id'] . ')
	</p>
	<p>
		<img src="' . System::server('domain') . $data['img'] . '">
	</p>
	
	' . ($data['price']['current'] ? ('
		<p>
			' . $data['price']['total'] . '&nbsp;₽ за ' . $data['value'] . ' ' . $data['units'] . '
		</p>
		<p>
			( по ' . $data['price']['current'] . '&nbsp;₽ за 1 ' . $data['units'] . '
			' . ($data['price']['old'] ? ('
				/ старая цена: ' . $data['price']['old'] . '&nbsp;₽ за 1 ' . $data['units'] . '
			') : null) . ')
		</p>
	') : ('
		<p>
			нет в наличии
		</p>
	')) . '
</div>
';

$globals -> set('print', [$data['id'] => $print]);

?>