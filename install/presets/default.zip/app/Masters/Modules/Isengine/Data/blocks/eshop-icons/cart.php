<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;

use is\Masters\View;

$view = View::getInstance();

$sets = '
	"id" : "cart",
	"name" : null,
	"parents" : null,
	"filter" : {},
	"routing" : null,
	"cookie" : false,
	"rest" : null
';

$view -> get('module') -> launch('content', 'eshop-catalog:eshop-catalog-cart', '{' . $sets . '}', null);

?>