<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

//echo print_r($this -> getData(), 1);

global $index;
$index = 0;

function isEshopCatalogNavFull($array) {
	Objects::each($array, function($item, $key) {
		global $index;
		$index++;
		$isarray = System::typeOf($item, 'iterable');
?>
	<div class="accordion-item">
		<div class="accordion-header flex justify-content-between align-items-center" id="accordion-<?= $index; ?>">
			<a href="" class="color-gray-800 color-theme-hover py-025">
				<?= $isarray ? $key : $item; ?>
			</a>
			<?php if ($isarray) { ?>
			<button class="btn py-0 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accordionCollapse-<?= $index; ?>" aria-expanded="false" aria-controls="accordionCollapse-<?= $index; ?>">
				<i class="bi-chevron-right rotate"></i>
			</button>
			<?php } ?>
		</div>
		<?php if ($isarray) { ?>
		<div id="accordionCollapse-<?= $index; ?>" class="accordion-collapse collapse" aria-labelledby="accordion-<?= $index; ?>">
			<div class="accordion-body">
				<?php isEshopCatalogNavFull($item); ?>
			</div>
		</div>
		<?php } ?>
	</div>
<?php 
	}, false);
}

function isEshopCatalogNavList($array) {
	Objects::each($array, function($item, $key) {
		$isarray = System::typeOf($item, 'iterable');
?>
		<a href="" class="color-gray-800 color-theme-hover">
			<?= $isarray ? $key : $item; ?>
		</a>
		<?php if ($isarray) { ?>
		<div class="accordion-body flex flex-column mb-1">
			<?php isEshopCatalogNavList($item); ?>
		</div>
		<?php } ?>
<?php 
	}, false);
}
?>

<div class="row accordion" id="accordionNav">
	<div class="col-12 block sm-none">
		<?php isEshopCatalogNavFull($this -> getData()); ?>
	</div>
	<div class="col-auto none sm-block">
		<?php
			Objects::each(Objects::keys($this -> getData()), function($item, $key){
				$key++;
		?>
		<div class="accordion-item">
			<div class="accordion-header flex justify-content-between align-items-center" id="accordionList-<?= $key; ?>">
				<button class="btn py-0<?= $key === 1 ? '' : ' collapsed' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#accordionListCollapse-<?= $key; ?>" aria-expanded="false" aria-controls="accordionListCollapse-<?= $key; ?>">
					<span class="color-gray-800 color-theme-hover">
						<?= $item; ?>
					</span>
					<i class="bi-chevron-right translate"></i>
				</button>
			</div>
		</div>
		<?php }); ?>
	</div>
	<div class="col none sm-block col-double">
		<?php
			Objects::each($this -> getData(), function($item, $key){
				static $index;
				$index++;
		?>
		<div id="accordionListCollapse-<?= $index; ?>" class="accordion-collapse collapse<?= $index === 1 ? ' show' : '' ?>" aria-labelledby="accordionList-<?= $index; ?>" data-bs-parent="#accordionNav">
			<div class="accordion-body">
				<a href="" class="color-gray-800 color-theme-hover h5 block">
					<?= $key; ?>
				</a>
				<a href="" class="color-gray-800 color-theme-hover fw-bold py-05 block">
					Все товары категории
				</a>
				<?php isEshopCatalogNavList($item); ?>
			</div>
		</div>
		<?php
			});
		?>
	</div>
</div>