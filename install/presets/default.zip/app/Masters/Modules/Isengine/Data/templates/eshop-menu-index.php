<?php

namespace is\Masters\Modules\Isengine\Content;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$instance = $this -> get('instance');
$sets = &$this -> settings;

$this -> custom();
//$this -> custom('format', 'ftim');
//$this -> custom('ctime', 'ctim');
//$this -> custom('dtime', 'dtim');
?>
<div class="row">
<?php
Objects::each($this -> data, function($value, $key){
	
	$iterable = System::typeOf($value, 'iterable');
	
	if ($iterable) {
		if (System::type($key, 'numeric') && $value['title']) {
			$name = $value['title'];
		} else {
			$name = $key;
		}
	} else {
		$name = $value;
	}
	
	if (!System::type($name, 'string')) {
		return;
	}
	
	$translit = $this -> translit(Strings::replace(Prepare::lower(Prepare::words($name)), ' ', '_'), 'en', 'ru');
	
	$link = '/catalog/' . $translit . '/';
	$image = '{img|/content/groups/' . $name . '.jpg:/content/catalog/default.jpg:lazyload w-100 align-image-contain rounded-3:' . $name . '}';
	
	$this -> tvars($image);
	
	//System::debug($link, '!q');
	//System::debug($image, '!q');
	//System::debug($name);
	
?>

<div class="col-6 sm-col-4 md-col-3 align-center mb-2">
		<a href="<?= $link ?>" class="block m-05">
			<div class="block border rounded-3 mt-1">
				<?= $image; ?>
			</div>
		</a>
		<a href="<?= $link ?>" class="btn bg-theme">
			<div class="">
				<?= $name; ?>
			</div>
		</a>
</div>

<?php
});
?>
</div>