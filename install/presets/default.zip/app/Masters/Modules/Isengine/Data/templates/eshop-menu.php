<?php

namespace is\Masters\Modules\Isengine\Content;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$this -> custom();

$print = [
	'desktop_main' => null,
	'desktop_sub' => null,
	'mobile' => null
];

$link_array = ['catalog'];

$this -> iterate(function($data) use (&$print, &$link_array){
	
	/*
	* Каталог для мобильной версии
	* все элементы меню вместе
	*/
	
	$key = Strings::join($data['id'], '-');
	
	$translit = $this -> translit(Prepare::spaces(Prepare::lower(Prepare::alphanumeric($data['title'])), '_'), 'en', 'ru');
	$link_array[] = $translit;
	$link = ($data['link'] ? '/catalog/' . ($data['link'] === true ? $translit : $data['link']) : '/' . Strings::join($link_array, '/')) . '/';
	
	$print['mobile'] .= '
	<div class="accordion-item">
		<div class="accordion-header my-025 " id="accordion-' . $key . '">
	';
	
	if ($data['iterable']) {
		$print['mobile'] .= '
			<button class="btn p-0 collapsed flex justify-content-between align-items-center w-100" type="button" data-bs-toggle="collapse" data-bs-target="#accordionCollapse-' . $key . '" aria-expanded="false" aria-controls="accordionCollapse-' . $key . '">
				<span class="color-gray-800 color-theme-hover px-025 align-left">
					' . ($data['class'] ? '<i class="' . $data['class'] . '"></i>' : null) . '
					' . Prepare::upperFirst($data['title']) . '
				</span>
				<i class="bi-chevron-right rotate"></i>
			</button>
		';
	} else {
		$print['mobile'] .= '
			<a href="' . $link . '" class="color-gray-800 color-theme-hover p-025 block align-left">
				' . $data['title'] . '
			</a>
		';
	}
	
	$print['mobile'] .= '
		</div>
	';
	
	if ($data['iterable']) {
		$print['mobile'] .= '
		<div id="accordionCollapse-' . $key . '" class="accordion-collapse collapse accordion-mobile" aria-labelledby="accordion-' . $key . '">
			<a href="' . $link . '" class="color-gray-800 color-theme-hover p-025 block">
				<strong>Показать все товары</strong>
			</a>
			<div class="accordion-body p-0">
		';
	}
		
}, function($data) use (&$print, &$link_array){
	
	$link_array = Objects::unlast($link_array);
	
	if ($data['iterable']) {
		$print['mobile'] .= '
			</div>
		</div>
		';
	}
	
	$print['mobile'] .= '
	</div>
	';
	
});

$this -> iterate(function($data) use (&$print){
	
	$key = $data['id'][0];
	
	$translit = $this -> translit(Prepare::spaces(Prepare::lower(Prepare::alphanumeric($data['title'])), '_'), 'en', 'ru');
	$link = ($data['link'] ? '/catalog/' . ($data['link'] === true ? $translit : $data['link']) : '/#') . '/';
	
	if (!System::typeOf($data['data'], 'iterable')) {
		
		$print['desktop_main'] .= '
		<div class="accordion-item">
			<div class="accordion-header flex justify-content-between align-items-center" id="accordionList-' . $key . '">
				<a href="' . $link . '" class="btn py-0' . (!$key ? null : ' collapsed') . '">
					<span class="color-gray-800 color-theme-hover">
						' . ($data['class'] ? '<i class="' . $data['class'] . '"></i>' : null) . '
						' . Prepare::upperFirst($data['title']) . '
					</span>
				</a>
			</div>
		</div>
		';
		//System::debug($data);
		return;
	}
	
	/*
	* Каталог для десктопной версии
	* отдельно элементы меню верхнего уровня
	*/
	
	$print['desktop_main'] .= '
	<div class="accordion-item">
		<div class="accordion-header flex justify-content-between align-items-center" id="accordionList-' . $key . '">
			<button class="btn py-0' . (!$key ? null : ' collapsed') . '" type="button" data-bs-toggle="collapse" data-bs-target="#accordionListCollapse-' . $key . '" aria-expanded="false" aria-controls="accordionListCollapse-' . $key . '">
				<span class="color-gray-800 color-theme-hover">
					' . ($data['class'] ? '<i class="' . $data['class'] . '"></i>' : null) . '
					' . Prepare::upperFirst($data['title']) . '
				</span>
				<i class="bi-chevron-right translate"></i>
			</button>
		</div>
	</div>
	';
	
	/*
	* Каталог для десктопной версии
	* начало вложенния
	*/
	
	$print['desktop_sub'] .= '
	<div id="accordionListCollapse-' . $key . '" class="accordion-collapse collapse' . (!$key ? ' show' : '') . '" aria-labelledby="accordionList-' . $key . '" data-bs-parent="#accordionNav">
		<div class="accordion-body">
			<a href="' . $link . '" class="color-gray-800 color-theme-hover h5 block">
				' . Prepare::upperFirst($data['title']) . '
			</a>
			<a href="' . $link . '" class="color-gray-800 color-theme-hover fw-bold py-05 block">
				Все товары категории
			</a>
	';
	
	/*
	* Каталог для десктопной версии
	* перебор вложения
	*/
	
	$print['desktop_sub'] .= $this -> iterate(function($i) use ($link){
		
		$translit = $this -> translit(Prepare::spaces(Prepare::lower(Prepare::alphanumeric($i['title'])), '_'), 'en', 'ru');
		$link = ($i['link'] ? '/catalog/' . ($i['link'] === true ? $translit : $i['link']) : $link . $translit) . '/';
		
		$print = '<a href="' . $link . '" class="color-gray-800 color-theme-hover block">' . Prepare::upperFirst($i['title']) . '</a>';
		
		if ($i['iterable']) {
			
			$print .= '<div class="accordion-body mb-1">';
			
			$print .= $this -> iterate(function($ii) use ($link){
				
				$translit = $this -> translit(Prepare::spaces(Prepare::lower(Prepare::alphanumeric($ii['title'])), '_'), 'en', 'ru');
				$link = ($ii['link'] ? '/catalog/' . ($ii['link'] === true ? $translit : $ii['link']) : $link . $translit) . '/';
				
				$print = '<a href="' . $link . '" class="color-gray-800 color-theme-hover block">' . Prepare::upperFirst($ii['title']) . '</a>';
				return $print;
				
			}, null, $i, null);
			
			$print .= '</div>';
			
			return $print;
			
		}
		
		return $print;
		
	}, null, $data, null);
	
	/*
	* Каталог для десктопной версии
	* конец вложенния
	*/
	
	$print['desktop_sub'] .= '
		</div>
	</div>
	';
	
}, null, null, null);

?>

<div class="row accordion sm-pl-025" id="accordionNav">
	<div class="col-12 block sm-none">
		<?/* Каталог для мобильной версии, слитый вместе */?>
		<?php //isEshopCatalogNavFull($this -> getData()); ?>
		<?php //$this -> iterate(function($data){ ?>
		<?= $print['mobile']; ?>
	</div>
	<div class="col-auto none sm-block">
		<?/*
		* Каталог для десктопной версии
		* отдельно элементы меню верхнего уровня
		*/?>
		<?= $print['desktop_main']; ?>
	</div>
	<div class="col none sm-block col-double">
		<?/*
		* Каталог для десктопной версии
		* отдельно вложенные элементы двух уровней
		*/?>
		<?= $print['desktop_sub']; ?>
	</div>
</div>


<?/*
<div class="<?= $instance; ?>">
	
	<?php
		$this -> iterate(function($data){
			if ($data['level']) {
				return;
			}
	?>
	<div class="item">
		<a href="<?= $data['link']; ?>">
			<p><?= $data['name']; ?></p>
		</a>
		<?php System::debug($data); ?>
	</div>
	<? }); ?>
	
	<?php $this -> blocks('block'); ?>
	
</div>
*/?>