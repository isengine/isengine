<?php

namespace is\Masters\Modules\Isengine\Form;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;

$element = $item[0];
$item = $item[1];
$data = $item['options'];

$name = 'eshop-form-login-' . $item['name'];

$element -> addId($name);

?>
<div class="mb-05">
	<div class="form-check">
		<?php $element -> print(); ?>
		<label class="<?= $name; ?>-label" for="<?= $name; ?>">
			<?= $data['label']; ?>
			<br>
			<span class="color-gray-600">
				<?= $data['description']; ?>
			</span>
		</label>
	</div>
</div>
