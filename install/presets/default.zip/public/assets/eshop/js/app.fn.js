is.App.fn = class {
	
	static cart() {
		
		let cart = {};
		//$.each(
		//	is.Helpers.Sessions.getSession(),
		//	function(k, i){
		//		if (k.indexOf("catalog:") === 0) {
		//			cart[k] = parseFloat(i);
		//		}
		//	}
		//);
		$.each(
			is.Helpers.Sessions.getCookie(),
			function(k, i){
				if (k.indexOf("catalog:") === 0) {
					cart[k] = parseFloat(i);
				}
			}
		);
		return cart;
		
	}
	
	static count() {
		
		let cart = is.App.fn.cart();
		let c = is.Helpers.Objects.len(cart);
		
		if (c) {
			$(".eshop-catalog-cart").removeClass("none");
			$(".eshop-catalog-cart-none").addClass("none");
			$("#block-collapse-cart__icons .icons-box span").removeClass("none").html(c);
			$(".bottom-nav .cart span").removeClass("none").html(c);
		} else {
			$(".eshop-catalog-cart").addClass("none");
			$(".eshop-catalog-cart-none").removeClass("none");
			$("#block-collapse-cart__icons .icons-box span").addClass("none").html("");
			$(".bottom-nav .cart span").addClass("none").html("");
		}
		
		let t = 0;
		
		$(".eshop-catalog-cart-main").first().find(".item [is-data=\"sum\"]").each(function(){
			t = t + parseFloat($(this).html());
		});
		
		$(".eshop-catalog-cart-total .eshop-catalog-cart-total-count").html(c);
		$(".eshop-catalog-cart-total .eshop-catalog-cart-total-price").html(t);
		
	}
	
	static match(t, block, del = null) {
		
		let v = parseFloat(t.data("value:value"));
		let step = parseFloat(t.data("step"));
		let first = block.find(".item-first");
		let second = block.find(".item-second");
		
		v = Math.floor(v / step) * step;
		
		if (!v || v <= 0) {
			v = 0;
			first.removeClass("none");
			second.addClass("none");
			is.Helpers.Sessions.unCookie(t.name());
			//is.Helpers.Sessions.unSession(t.name());
			if (del) {
				block.each(function(){
					if ( $(this).is(".item-delete") ) {
						$(this).remove();
					}
				});
			}
		} else {
			first.addClass("none");
			second.removeClass("none");
			is.Helpers.Sessions.setCookie(t.name(), v);
			//is.Helpers.Sessions.setSession(t.name(), v);
		}
		
		t.data("value:value", v);
		t.data("sum", t.data("price") * v);
		t.data("sum-old", t.data("price-old") * v);
		
		if (t.data("sum-old") && t.data("sum-old") > 0) {
			block.find(".sum-old").removeClass("xs-none").removeClass("none");
		} else {
			block.find(".sum-old").addClass("xs-none").addClass("none");
		}
		
		is.App.fn.count();
		
	}
	
}