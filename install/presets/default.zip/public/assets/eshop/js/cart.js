var eshop = new is.View.Elements();
var cart = is.App.fn.cart();

$.each(
	eshop.items,
	function(i){
		
		let block = this._items;
		let name = this.name();
		let val = cart[name] ? parseFloat(cart[name]) : 0;
		
		this.data("value:value", val);
		this.value("step", (i) => i ? parseFloat(i) : 0);
		
		let step = this.data("step");
		let t = this;
		
		is.App.fn.match(t, block);
		
		this.action("buy", "click",
			function() {
				t.data("value:value", step);
				
				let clone = t.clone(name, ".eshop-catalog-cart-template .item");
				clone.find("img.lazyload").attr("srcset", "");
				clone.appendTo($(".eshop-catalog-cart-main"));
				
				is.App.fn.match(t, block);
			}
		);
		
		this.action("del", "click",
			function() {
				t.data("value:value", "");
				is.App.fn.match(t, block, true);
			}
		);
		
		this.action("inc", "click",
			function() {
				t.value("value:value", (i) => i + step);
				is.App.fn.match(t, block);
			}
		);
		
		this.action("dec", "click",
			function() {
				t.value("value:value", (i) => i - step);
				is.App.fn.match(t, block, true);
			}
		);
		
		this.action("enter", "focusout",
			function() {
				let v = $(this).val();
				t.value("value:value", (i) => parseFloat(v));
				is.App.fn.match(t, block, true);
			}
		);
		
	}
);

if ( $("#eshop-catalog-cart-main [is-name]").length < Object.keys(cart).length ) {
	//document.location.reload();
	//Location.reload();
}
