/*
is.App.toast({
	"title" : "Bootstrap",
	"datetime" : "just now",
	"body" : "See? Just like this."
}, 2);

is.App.toast({
	"title" : "Bootstrap",
	"body" : "Heads up, toasts will stack automatically",
	"color" : "green"
});
*/

if (is.Helpers.Sessions.getCookie("eshop-order-complete")) {
	is.App.toast({
		"title" : "Заказ принят",
		"body" : "Ваш заказ принят в обработку",
		"color" : "orange"
	});
	is.Helpers.Sessions.unCookie("eshop-order-complete");
}

if (is.Helpers.Sessions.getCookie("eshop-login")) {
	is.App.toast({
		"title" : "Добро пожаловать",
		"body" : "Мы снова рады видеть Вас!",
		"color" : "orange"
	});
	is.Helpers.Sessions.unCookie("eshop-login");
}

if (is.Helpers.Sessions.getCookie("eshop-logout")) {
	is.App.toast({
		"title" : "До свидания",
		"body" : "Возвращайтесь скорее. Мы будем рады видеть Вас снова!",
		"color" : "orange"
	});
	is.Helpers.Sessions.unCookie("eshop-logout");
}

if (is.Helpers.Sessions.getCookie("eshop-register")) {
	is.App.toast({
		"title" : "Вы зарегистрированы",
		"body" : "Регистрация прошла успешно. Теперь вы должны получить письмо со ссылкой на активацию. Без активации Вы не сможете пользоваться личным кабинетом! Это сделано для защиты от мошенников. Приносим извинения за неудобства.",
		"color" : "orange"
	});
	is.Helpers.Sessions.unCookie("eshop-register");
}

if (is.Helpers.Sessions.getCookie("eshop-activate")) {
	is.App.toast({
		"title" : "Активация прошла успешно",
		"body" : "Вы можете войти в свой личный кабинет!",
		"color" : "orange"
	});
	is.Helpers.Sessions.unCookie("eshop-activate");
}
