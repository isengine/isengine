<?php

echo 'file.php';

?>