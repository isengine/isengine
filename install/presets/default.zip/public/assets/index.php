<?php

echo 'index.php';

?>