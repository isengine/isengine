<?php

// Set base namespace
// Рабочее пространство имен

namespace is;

// Set base constants
// Базовые константы

if (!defined('isENGINE')) { define('isENGINE', microtime(true)); }
if (!defined('DS')) { define('DS', DIRECTORY_SEPARATOR); }
if (!defined('DP')) { define('DP', '..' . DIRECTORY_SEPARATOR); }

// Set base path configuration
// Use first configuration if you want to isolate system from public access by placing it in the folder above
// Otherwise use second code
// Only one option needs to be uncommented

// Выбор базового пути
// Используйте первую конфигурацию, если вы хотите изолировать систему от публичного доступа, разместив ее папкой выше
// Иначе используйте второй код
// Только один вариант должен быть раскомментирован

if (!defined('isPATH')) { define('isPATH', realpath(__DIR__ . DS . '..') . DS . 'vendor' . DS . 'isengine' . DS); }
//if (!defined('isPATH')) { define('isPATH', realpath(__DIR__) . DS . 'vendor' . DS . 'isengine' . DS); }

// To install/update system uncomment the code below
// Usually this code should be commented out

// Для установки/обновления системы, раскомментируйте код ниже
// В обычном режиме этот код должен быть закомментирован

//$install = isPATH . 'install' . DS . 'index.php';

// Launch install process
// Запускаем процесс установки

if (!empty($install) && file_exists($install) && hash_file('md5', $install) === '0a63e87a0e86d78ed2e1fc416cf2b2b7') {
	// Hash check is protect system from fake installation file
	// Проверка хэша защищает от подделки установочного файла
	require_once $install;
	unset($install);
	exit;
}

// To launch test uncomment the code below and set query test in address
// Usually this code should be commented out

// Для запуска тестирования, раскомментируйте код ниже и установите запрос test в адресе
// В обычном режиме этот код должен быть закомментирован

//if (isset($_GET['test'])) require_once isPATH . 'framework' . DS . 'test' . DS . 'init.php';

// Launch core
// Загружаем ядро

require_once isPATH . 'core' . DS . 'init.php';

?>