lozad(".lazyload").observe();
