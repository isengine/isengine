<?php

// Set base namespace
// Рабочее пространство имен

namespace is;

// Set base constants
// Базовые константы

if (!defined('isENGINE')) { define('isENGINE', microtime(true)); }
if (!defined('DS')) { define('DS', DIRECTORY_SEPARATOR); }
if (!defined('DP')) { define('DP', '..' . DIRECTORY_SEPARATOR); }

// Set index path automatically from this
// Автоматическая установка индексной папки

if (!defined('DI')) { define('DI', __DIR__ . DS); }

// Set base path configuration
// Use first configuration if you want to isolate system from public access by placing it in the folder above
// Otherwise use second code
// Only one option needs to be uncommented

// Выбор базового пути
// Используйте первую конфигурацию, если вы хотите изолировать систему от публичного доступа, разместив ее папкой выше
// Иначе используйте второй код
// Только один вариант должен быть раскомментирован

if (!defined('DR')) { define('DR', realpath(__DIR__ . DS . '..') . DS); }
//if (!defined('DR')) { define('DR', __DIR__ . DS); }

// To install/update system uncomment the code below
// Usually this code should be commented out

// Для установки/обновления системы, раскомментируйте код ниже
// В обычном режиме этот код должен быть закомментирован

//$install = DR . 'install' . DS . 'index.php';

// Launch install process
// Запускаем процесс установки

if (!empty($install) && file_exists($install) && hash_file('md5', $install) === '00ad9e8eecc21f24810619548e779ab7') {
	// Hash check is protect system from fake installation file
	// Проверка хэша защищает от подделки установочного файла
	require_once $install;
	unset($install);
	exit;
}

// Launch core
// Загружаем ядро

require_once DR . 'vendor' . DS . 'isengine' . DS . 'core' . DS . 'init.php';

?>