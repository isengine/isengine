<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
<?php $view -> get('layout') -> launch('blocks', 'side:logo'); ?>
    <!-- Sidebar -->
    <div class="sidebar">
<?php
$view -> get('layout') -> launch('blocks', 'side:user-panel');
$view -> get('layout') -> launch('blocks', 'side:search');
$view -> get('layout') -> launch('blocks', 'side:nav');
?>
    </div>
    <!-- /.sidebar -->
  </aside>