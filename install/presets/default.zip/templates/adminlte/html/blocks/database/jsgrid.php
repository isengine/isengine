<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="card">
	<div class="card-body">
		<div id="jsGrid"></div>
	</div>
</div>