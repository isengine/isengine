<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$pagename = $view -> get('vars|pagename');

?>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $view -> get('layout') -> launch('blocks', 'control-sidebar'); ?>
<?php $view -> get('layout') -> launch('blocks', 'footer'); ?>

</div>
<!-- ./wrapper -->

<?php $view -> get('layout') -> launch('blocks', 'scripts:' . $pagename); ?>

</body>
</html>