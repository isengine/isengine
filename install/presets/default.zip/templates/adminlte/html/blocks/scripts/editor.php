<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Parser;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- jQuery -->
<script src="/assets/isjs.min.js"></script>
<!-- jQuery -->
<script src="/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="/dist/js/demo.js"></script>
<!-- Page specific script -->
<!-- Bootstrap Switch -->
<script src="/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script>
$(function () {
	
	var glob = new is.View.Globals();
	
	$("input[data-bootstrap-switch]").each(function(){
		$(this).bootstrapSwitch('state', $(this).prop('checked'));
	});
	
	var content = <?= Parser::toJson($view -> get('vars|content')); ?>;
	//console.log(collection);
	
	$('div[type="adminlte-form-editor-array"] input').each(function(){
		let i = $(this);
		let p = i.parent();
		
		let group = $("<div class=\"row mb-1\"></div>");
		let inner = $("<div class=\"col-auto\"><button class=\"btn btn-sm text-white adminlte-form-editor-array-remove\" type=\"button\"><i class=\"fas fa-trash\"></i></button></div>");
		
		i.appendTo(group);
		inner.appendTo(group);
		group.appendTo(p);
	});
	
	$('.adminlte-form-editor-array-add').click(function(){
		let name = $(this).attr('for');
		let target = $(this).siblings('#' + name).first();
		let element = target.children().last().clone();
		//element.val(null).attr('value', null);
		element.find('input').val(null).attr('value', null);
		element.appendTo(target);
	});
	
	$('body').on('click', '.adminlte-form-editor-array-remove', function(){
		let n = $(this).parents('div[type="adminlte-form-editor-array"]').children('.row').length;
		if (n > 1) {
			$(this).parents('.row').first().empty().remove();
		}
	});
	
});
</script>