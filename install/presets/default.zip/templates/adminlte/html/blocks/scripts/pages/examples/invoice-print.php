<!-- Page specific script -->
<script>
  window.addEventListener("load", window.print());
</script>