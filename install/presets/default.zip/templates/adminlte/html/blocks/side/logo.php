<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Brand Logo -->
<a href="/adminlte/" class="brand-link">
	<img src="/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
	<span class="brand-text font-weight-light">AdminLTE 3</span>
</a>