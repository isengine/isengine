<?php

namespace is;
use is\Masters\View;
use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;

$view = View::getInstance();

$class = null;
$sets = $view -> get('vars|adminlte:sidebar');

if ($sets['flat']) { $class .= ' nav-flat'; }
if ($sets['lagacy']) { $class .= ' nav-legacy'; }
if ($sets['indent']) { $class .= ' nav-child-indent'; }

?>
<!-- Sidebar Menu -->
<nav class="mt-2">
	<ul class="nav nav-pills nav-sidebar flex-column<?= $class; ?>" data-widget="treeview" role="menu" data-accordion="false">
		<li class="nav-item">
			<a href="/adminlte/" class="nav-link">
				<i class="nav-icon fas fa-tachometer-alt"></i>
				<p>Dashboard</p>
			</a>
		</li>
		<li class="nav-item menu-open">
			<a href="#" class="nav-link active">
				<i class="nav-icon fas fa-tachometer-alt"></i>
				<p>
					Variations
					<i class="right fas fa-angle-left"></i>
				</p>
			</a>
			<ul class="nav nav-treeview">
				<li class="nav-item">
					<a href="/adminlte/index/" class="nav-link active">
						<i class="far fa-circle nav-icon"></i>
						<p>Dashboard v1</p>
					</a>
				</li>
				<li class="nav-item">
					<a href="/adminlte/index2/" class="nav-link">
						<i class="far fa-circle nav-icon"></i>
						<p>Dashboard v2</p>
					</a>
				</li>
				<li class="nav-item">
					<a href="/adminlte/index3/" class="nav-link">
						<i class="far fa-circle nav-icon"></i>
						<p>Dashboard v3</p>
					</a>
				</li>
			</ul>
		</li>
		<?php
			$state = [];
			Objects::each($view -> get('state|structure:adminlte:pages'), function($item, $key) use ($view, $state) {
				$state[] = $key;
				
				$array = $view -> get('lang|this');
				$target = 'pages:' . Strings::join($state, ':');
				$lang = $array['pagenames'][$target];
				$icon = $array['icons'][$target];
				
				if (!System::typeOf($item, 'iterable')) {
		?>
		<li class="nav-item">
			<a href="/adminlte/<?= Strings::replace($target, ':', '/'); ?>/" class="nav-link">
				<i class="<?= $icon; ?> nav-icon"></i>
				<p>
					<?= $lang; ?>
				</p>
			</a>
		</li>
		<?php
				} else {
		?>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="<?= $icon; ?> nav-icon"></i>
				<p>
					<?= $lang; ?>
					<i class="right fas fa-angle-left"></i>
				</p>
			</a>
			<ul class="nav nav-treeview">
			<?php
				Objects::each($item, function($i, $k) use ($view, $state) {
					$state[] = $k;
					$array = $view -> get('lang|this');
					$target = 'pages:' . Strings::join($state, ':');
					$lang = $array['pagenames'][$target];
					$icon = $array['icons'][$target];
			?>
				<li class="nav-item">
					<a href="/adminlte/<?= Strings::replace($target, ':', '/'); ?>/" class="nav-link">
						<i class="<?= $icon; ?> nav-icon"></i>
						<p><?= $lang; ?></p>
					</a>
				</li>
			<?php
					$state = Objects::unlast($state);
				}, true);
			?>
			</ul>
		</li>
		<?php
				}
				$state = Objects::unlast($state);
			}, true);
		?>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="nav-icon fas fa-search"></i>
				<p>
					Search
					<i class="fas fa-angle-left right"></i>
				</p>
			</a>
			<ul class="nav nav-treeview">
				<li class="nav-item">
					<a href="/adminlte/pages/search/simple/" class="nav-link">
						<i class="far fa-circle nav-icon"></i>
						<p>Simple Search</p>
					</a>
				</li>
				<li class="nav-item">
					<a href="/adminlte/pages/search/enhanced/" class="nav-link">
						<i class="far fa-circle nav-icon"></i>
						<p>Enhanced</p>
					</a>
				</li>
			</ul>
		</li>
		<li class="nav-header">MISCELLANEOUS</li>
		<li class="nav-item">
			<a href="/adminlte/iframe/" class="nav-link">
				<i class="nav-icon fas fa-ellipsis-h"></i>
				<p>Tabbed IFrame Plugin</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="https://adminlte.io/docs/3.1/" class="nav-link">
				<i class="nav-icon fas fa-file"></i>
				<p>Documentation</p>
			</a>
		</li>
		<li class="nav-header">MULTI LEVEL EXAMPLE</li>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="fas fa-circle nav-icon"></i>
				<p>Level 1</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="nav-icon fas fa-circle"></i>
				<p>
					Level 1
					<i class="right fas fa-angle-left"></i>
				</p>
			</a>
			<ul class="nav nav-treeview">
				<li class="nav-item">
					<a href="#" class="nav-link">
						<i class="far fa-circle nav-icon"></i>
						<p>Level 2</p>
					</a>
				</li>
				<li class="nav-item">
					<a href="#" class="nav-link">
						<i class="far fa-circle nav-icon"></i>
						<p>
							Level 2
							<i class="right fas fa-angle-left"></i>
						</p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="#" class="nav-link">
								<i class="far fa-dot-circle nav-icon"></i>
								<p>Level 3</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link">
								<i class="far fa-dot-circle nav-icon"></i>
								<p>Level 3</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link">
								<i class="far fa-dot-circle nav-icon"></i>
								<p>Level 3</p>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item">
					<a href="#" class="nav-link">
						<i class="far fa-circle nav-icon"></i>
						<p>Level 2</p>
					</a>
				</li>
			</ul>
		</li>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="fas fa-circle nav-icon"></i>
				<p>Level 1</p>
			</a>
		</li>
		<li class="nav-header">LABELS</li>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="nav-icon far fa-circle text-danger"></i>
				<p class="text">Important</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="nav-icon far fa-circle text-warning"></i>
				<p>Warning</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="#" class="nav-link">
				<i class="nav-icon far fa-circle text-info"></i>
				<p>Informational</p>
			</a>
		</li>
	</ul>
</nav>
<!-- /.sidebar-menu -->