<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="container-fluid">
	<?php $view -> get('layout') -> launch('blocks', 'widgets:small-box'); ?>
	<div class="row">
		<section class="col-lg-7 connectedSortable">
			<?php $view -> get('layout') -> launch('blocks', 'main:charts-with-tabs'); ?>
			<?php $view -> get('module') -> launch('data', 'adminlte-direct-chat'); ?>
			<?php $view -> get('layout') -> launch('blocks', 'main:to-do-list'); ?>
		</section>
		<section class="col-lg-5 connectedSortable">
			<?php $view -> get('layout') -> launch('blocks', 'main:map-card'); ?>
			<?php $view -> get('layout') -> launch('blocks', 'main:solid-sales-graph'); ?>
			<?php $view -> get('layout') -> launch('blocks', 'main:calendar'); ?>
		</section>
	</div>
</div>