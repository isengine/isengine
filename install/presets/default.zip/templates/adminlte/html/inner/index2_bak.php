<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
      <div class="container-fluid">
        <?php $view -> get('block') -> launch('main:info-boxes'); ?>
        <?php $view -> get('block') -> launch('main:monthly-recap-report'); ?>

        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <div class="col-md-8">
			<?php $view -> get('block') -> launch('main:map-box-pane'); ?>
            <div class="row">
              <div class="col-md-6">
				<?php
					$sets = '
						"common" : "direct-chat-warning",
						"badge" : "badge-warning",
						"button" : "btn-warning"
					';
					$view -> get('module') -> launch('data', 'adminlte-direct-chat', '{"classes":{' . $sets . '}}');
				?>
              </div>
              <!-- /.col -->
              <div class="col-md-6">
				<?php $view -> get('block') -> launch('main:users-list'); ?>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
			<?php $view -> get('block') -> launch('main:table-latest-orders'); ?>
          </div>
          <!-- /.col -->

          <div class="col-md-4">
			<?php $view -> get('block') -> launch('main:info-boxes2'); ?>
			<?php $view -> get('block') -> launch('main:browser-usage'); ?>
			<?php $view -> get('block') -> launch('main:product-list'); ?>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->