<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
			<?php $view -> get('block') -> launch('main:online-store-visitors'); ?>
			<?php $view -> get('block') -> launch('main:products'); ?>
          </div>
          <!-- /.col-md-6 -->
          <div class="col-lg-6">
			<?php $view -> get('block') -> launch('main:sales'); ?>
			<?php $view -> get('block') -> launch('main:online-store-overview'); ?>
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->