<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
			<?php $view -> get('layout') -> launch('blocks', 'main:online-store-visitors'); ?>
			<?php $view -> get('layout') -> launch('blocks', 'main:products'); ?>
          </div>
          <!-- /.col-md-6 -->
          <div class="col-lg-6">
			<?php $view -> get('layout') -> launch('blocks', 'main:sales'); ?>
			<?php $view -> get('layout') -> launch('blocks', 'main:online-store-overview'); ?>
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->