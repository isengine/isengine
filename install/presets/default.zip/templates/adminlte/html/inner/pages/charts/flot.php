<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
			<?php $view -> get('layout') -> launch('blocks', 'widgets:charts:flot:interactive-area-chart'); ?>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
        <div class="row">
          <div class="col-md-6">
			<?php $view -> get('layout') -> launch('blocks', 'widgets:charts:flot:line-chart'); ?>
			<?php $view -> get('layout') -> launch('blocks', 'widgets:charts:flot:area-chart'); ?>
          </div>
          <!-- /.col -->
          <div class="col-md-6">
			<?php $view -> get('layout') -> launch('blocks', 'widgets:charts:flot:bar-chart'); ?>
			<?php $view -> get('layout') -> launch('blocks', 'widgets:charts:flot:donut-chart'); ?>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->