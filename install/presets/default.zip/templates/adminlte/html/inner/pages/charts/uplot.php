<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
      <div class="container-fluid">
		<?php $view -> get('layout') -> launch('blocks', 'widgets:charts:uplot:area-chart'); ?>
		<?php $view -> get('layout') -> launch('blocks', 'widgets:charts:uplot:line-chart'); ?>
      </div>
      <!-- /.container-fluid -->