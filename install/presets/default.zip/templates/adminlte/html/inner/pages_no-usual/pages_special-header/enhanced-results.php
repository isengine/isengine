  <!-- Navbar -->
  <!-- aside -->

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <h2 class="text-center display-4">Enhanced Search</h2>
      </div>
      <!-- /.container-fluid -->
    </section>
