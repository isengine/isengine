<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;
use is\Components\Config;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

if (Sessions::getCookie('agree')) { return; }

//$link = objectProcess('system:cookiesagree');
$link = null;
?>

<div id="cookies" class="cookies">
	<div class="cookies_content">
		<?= $view -> get('lang|common:cookie'); ?>
	</div>
	<div class="cookies_buttons">
		<a href="<?= $link['action'] . $link['string'] . '&close=1'; ?>" class="cookies_button cookies_buttons__argee">
			<?= $view -> get('lang|common:agree'); ?>
		</a>
		<a href="/cookie" class="cookies_button cookies_buttons__readmore">
			<?= $view -> get('lang|common:readmore'); ?>
		</a>
	</div>
</div>

<style>
#cookies {
	position: absolute;
	top: auto;
	bottom: 0;
	left: 0;
	right: 0;
	padding: 2em;
	background: white;
	z-index: 9999;
}
#cookies .cookies_content {
	padding-bottom: 1em;
	font-size: 1.25em;
	text-align: center;
}
#cookies .cookies_buttons {
	text-align: center;
}
#cookies .cookies_button {
	margin: 0.5em;
	padding: 0.5em;
	text-transform: uppercase;
}
</style>

<?php
unset($link);
?>