<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

$view -> get('layout') -> launch('blocks:' . $view -> get('state|template'), 'footer');

$view -> get('layout') -> launch('blocks:default', 'item:check');
$view -> get('layout') -> launch('blocks:default', 'item:cookies');
$view -> get('layout') -> launch('blocks:default', 'item:assets');
$view -> get('layout') -> launch('blocks:default', 'item:inspect');
//page('backup', 'item');

?>

</body>
</html>