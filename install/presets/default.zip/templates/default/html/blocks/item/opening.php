<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;
use is\Components\Display;
use is\Components\Log;
use is\Components\State;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

$view -> get('layout') -> launch('blocks:default', 'item:html');

?>
<head>
<?php
	
	$view -> get('layout') -> launch('blocks:default', 'item:google');
	$view -> get('layout') -> launch('blocks:default', 'item:yandex');
	$view -> get('layout') -> launch('blocks:default', 'item:meta');
	$view -> get('layout') -> launch('blocks:default', 'item:webapp');
	$view -> get('layout') -> launch('blocks:default', 'item:icons');
	$view -> get('layout') -> launch('blocks:default', 'item:ie');
	
	$view -> get('layout') -> launch('blocks:default', 'item:preload');
	
	$view -> get('layout') -> launch('blocks:default', 'item:libraries');
	$view -> get('layout') -> launch('blocks:default', 'item:variables');
	$view -> get('layout') -> launch('blocks:default', 'item:assets');
	
	$view -> get('layout') -> launch('blocks:' . $view -> get('state|template'), 'head');
	
?>
</head>
<?php
	
	$view -> get('layout') -> launch('blocks:default', 'item:body');
	$view -> get('layout') -> launch('blocks:default', 'item:assets');
	
	$view -> get('layout') -> launch('blocks:' . $view -> get('state|template'), 'header');
	
	$view -> get('layout') -> launch('blocks:default', 'item:h1');
	
?>