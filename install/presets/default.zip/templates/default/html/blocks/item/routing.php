<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;
use is\Components\Display;
use is\Components\Log;
use is\Components\Router;
use is\Masters\View;

// читаем

$view = View::getInstance();
$router = Router::getInstance();

$cache = $router -> current -> get('cache:page');

$lang = $view -> get('state|lang');
$route = $view -> get('state|route');
Objects::relast($route, Objects::last($route, 'value') . '.' . $lang);
$path = $view -> get('state|real') . 'html' . DS . 'inner' . DS . (System::typeIterable($route) ? Strings::join($route, DS) : 'index.' . $lang) . '.php';
unset($lang);

if (!file_exists($path)) {
	$route = $view -> get('state|route');
}

$view -> get('layout') -> launch(
	'pages',
	Strings::join($route, DS),
	System::set($cache)
);

// ЧЕГО НЕ ХВАТАЕТ
// нет прочтения настроек кэширования из структуры
// и отсчета указанного времени от времени кэшированного файла
// нет проверки кэширования по времени
// если дата изменения файла больше даты изменения кэша, то файл кэшируется заново
// ^ этот момент будет реализован в мастере layout
// оба этих пункта должны учитываться для сброса кэша, а не только один из них
// но как их совместить - это вопрос
// возможно, писать метод очистки кэша определенного файла и вызывать его при проверке

// код

/*
//if (empty($lang) || !page('before' . '.' . $lang -> lang, 'wrapper')) {
//	page('before', 'wrapper');
//}
page((thispage('home') ? 'home_' : 'inner_') . 'before', 'wrapper');

if (
	objectGet('content', 'name') ||
	$template -> page['type'] === 'content'
) {
	
	module(['content', $template -> page['name']]);
	
//} elseif (!page(thispage('is'))) {
} elseif (
	$template -> page['type'] === 'db' &&
	objectGet('user', 'authorised')
) {
	
	module(['db', $template -> page['name']], $template -> page['name']);
	
} elseif (!page(true)) {
	
	// в этом условии как бы подразумевается вызов текущей страницы
	// а выполнение условия происходит только, если текущая страница не была найдена
	
	// также здесь грузится страница секции
	// но т.к. мы изменили принцип загрузки секций, то могут возникнуть сбои
	// в частности, вызов данного файла из-под секции может привести к неожиданным результатам
	
	if (!page('nopage', 'html')) {
		page('nopage', 'item');
	}
	
}

//if (empty($lang) || !page('after' . '.' . $lang -> lang, 'wrapper')) {
//	page('after', 'wrapper');
//}
page((thispage('home') ? 'home_' : 'inner_') . 'after', 'wrapper');
*/

?>