<?php

namespace is;

use is\Helpers\Strings;
use is\Helpers\Paths;
use is\Components\Config;

$config = Config::getInstance();

$file = DR . 'vendor' . DS . 'isengine' . DS . 'frameworkjs' . DS . 'init.php';
if (file_exists($file)) {
	if (!defined('isPATH')) { define('isPATH', Paths::toUrl(Strings::get($config -> get('path:assets'), Strings::len(DI)))); }
	require_once $file;
}

?>