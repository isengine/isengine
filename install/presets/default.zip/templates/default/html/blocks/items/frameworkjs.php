<?php

namespace is;

$file = DR . 'vendor' . DS . 'isengine' . DS . 'frameworkjs' . DS . 'init.php';
if (file_exists($file)) {
	require_once $file;
}

?>