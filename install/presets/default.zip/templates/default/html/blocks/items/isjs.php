<?php

namespace is;

require_once DR . 'vendor' . DS . 'isengine' . DS . 'framework' . DS . 'js' . DS . 'init.php';

?>