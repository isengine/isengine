<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

/*
media="(orientation: portrait)"
media="(orientation: landscape)"
media="print" для печати и для режима "для слабовидящих"
*/

?>

<!-- META -->

<?php

$view -> get('layout') -> launch('blocks:default', 'meta:default');
$view -> get('layout') -> launch('blocks:default', 'meta:standart');

if (System::typeIterable($view -> get('seo|metadata'))) {
foreach ($view -> get('seo|metadata') as $item) {
	$view -> get('layout') -> launch('blocks:default', 'meta:' . $item);
}
unset($key, $item);
}

$view -> get('layout') -> launch('blocks:default', 'meta:canonical');
$view -> get('layout') -> launch('blocks:default', 'meta:verification');

?>