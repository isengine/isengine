<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;
use is\Components\Display;
use is\Components\Log;
use is\Components\State;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

$view -> get('layout') -> launch('blocks:default', 'items:html');

?>
<head>
<?php
	
	$view -> get('layout') -> launch('blocks:default', 'items:google');
	$view -> get('layout') -> launch('blocks:default', 'items:yandex');
	$view -> get('layout') -> launch('blocks:default', 'items:meta');
	$view -> get('layout') -> launch('blocks:default', 'items:webapp');
	$view -> get('layout') -> launch('blocks:default', 'items:icons');
	$view -> get('layout') -> launch('blocks:default', 'items:ie');
	
	$view -> get('layout') -> launch('blocks:default', 'items:preload');
	
	$view -> get('layout') -> launch('blocks:default', 'items:libraries');
	$view -> get('layout') -> launch('blocks:default', 'items:variables');
	$view -> get('layout') -> launch('blocks:default', 'items:assets');
	
	$view -> get('layout') -> launch('blocks:default', 'items:reactive');
	
	$view -> get('layout') -> launch('blocks:' . $view -> get('state|template'), 'head');
	
?>
</head>
<?php
	
	$view -> get('layout') -> launch('blocks:default', 'items:body');
	$view -> get('layout') -> launch('blocks:default', 'items:assets');
	
	$view -> get('layout') -> launch('blocks:' . $view -> get('state|template'), 'header');
	
	$view -> get('layout') -> launch('blocks:default', 'items:h1');
	
?>