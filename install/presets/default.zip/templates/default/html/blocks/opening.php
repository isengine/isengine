<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Sessions;
use is\Components\Display;
use is\Components\Log;
use is\Components\State;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

$view -> get('layout') -> launch('blocks:default', 'html');

?>
<head>
<?php
	
	$view -> get('layout') -> launch('blocks:default', 'google');
	$view -> get('layout') -> launch('blocks:default', 'yandex');
	$view -> get('layout') -> launch('blocks:default', 'meta');
	$view -> get('layout') -> launch('blocks:default', 'webapp');
	$view -> get('layout') -> launch('blocks:default', 'icons');
	$view -> get('layout') -> launch('blocks:default', 'ie');
	
	$view -> get('layout') -> launch('blocks:default', 'preload');
	
	$view -> get('layout') -> launch('blocks:default', 'libraries');
	$view -> get('layout') -> launch('blocks:default', 'variables');
	$view -> get('layout') -> launch('blocks:default', 'assets');
	
	$view -> get('layout') -> launch('blocks:' . $view -> get('state|template'), 'head');
	
?>
</head>
<?php
	
	$view -> get('layout') -> launch('blocks:default', 'body');
	$view -> get('layout') -> launch('blocks:default', 'assets');
	
	$view -> get('layout') -> launch('blocks:' . $view -> get('state|template'), 'header');
	
	$view -> get('layout') -> launch('blocks:default', 'h1');
	
?>