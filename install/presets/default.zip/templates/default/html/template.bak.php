<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Paths;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

//$p = $view -> get('lang') -> get('information:work:0');
//$s = '{phone|{lang|information:phone:0}}';
//$p = $view -> get('call') -> launch($s);

//$p = $view -> get('detect') -> get('type');
//$p = $view -> get('state') -> get('domain');

//echo '[' . print_r($p, 1) . ']';
//echo '<br>[' . $view -> get('state') -> main() . ']';
//echo '<br>[' . $view -> get('state') -> home() . ']';
//echo '<br>[' . $view -> get('state') -> match('main') . ']';
//echo '<br>[' . $view -> get('state') -> match('home') . ']';

//$p = $template -> view -> temp();
//$p = $template -> lang() -> get('information:work:0');
//$s = '{phone|{lang|information:phone:0}}';
//$p = $view -> get('call') -> launch($s);
//echo '[' . $p . ']';
//echo '<br>[' . $view -> get('state') -> main() . ']';
//echo '<br>[' . $view -> get('state') -> home() . ']';
//echo '<br>[' . $view -> get('state') -> match('main') . ']';
//echo '<br>[' . $view -> get('state') -> match('home') . ']';

//$s = '{phone|{lang|information:phone:0}}';
//$p = Strings::pairs($s);
//echo '+++';
//echo '[' . print_r($p, 1) . ']';
//echo Sessions::getCookie('lang');

$view -> get('layout') -> launch('blocks:default', 'items:opening');
$view -> get('layout') -> launch('blocks:default', 'items:routing');
$view -> get('layout') -> launch('blocks:default', 'items:ending');

?>