<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Paths;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

$view -> get('layout') -> launch('blocks:default', 'items:opening');
?>
<section class="main">
	<div class="container">
		<div class="row">
<?php
$view -> get('layout') -> launch('blocks:default', 'items:routing');
?>
		</div>
	</div>
</section>
<?php
$view -> get('layout') -> launch('blocks:default', 'items:ending');
?>