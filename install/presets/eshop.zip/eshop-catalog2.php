<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

//echo print_r($object -> getData(), 1);

global $index;
$index = 0;

function isEshopCatalogNavCreate($array, $level = 0) {
	Objects::each($array, function($item, $key) use ($level) {
		$level++;
		global $index;
		$index++;
		$isarray = System::typeOf($item, 'iterable');
?>
	<div class="accordion-item accordion-level-<?= $level; ?>">
		<div class="accordion-header d-flex justify-content-between align-items-center" id="accordion-<?= $index; ?>">
			<a href="" class="color-dark col py-1 me-2 accordion-link<?= $isarray ? ' accordion-dropdown' : null; ?>">
				<?= $isarray || !$item ? $key : $item; ?>
			</a>
			<?php if ($isarray) { ?>
			<button class="btn collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accordionCollapse-<?= $index; ?>" aria-expanded="false" aria-controls="accordionCollapse-<?= $index; ?>">
				<i class="bi-chevron-right"></i>
			</button>
			<?php } ?>
		</div>
		<?php if ($isarray) { ?>
		<div id="accordionCollapse-<?= $index; ?>" class="accordion-collapse collapse" aria-labelledby="accordion-<?= $index; ?>">
			<div class="accordion-body">
				<?php isEshopCatalogNavCreate($item, $level); ?>
			</div>
		</div>
		<?php } ?>
	</div>
<?php 
	}, false);
}
?>

<div class="accordion" id="accordionNav">
<?php isEshopCatalogNavCreate($object -> getData()); ?>
</div>