<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="row icons" id="block-collapse">
	<?php Objects::each($object -> getData(), function($item) use ($view) { ?>
	<a href="<?= $item['block'] ? '#block-collapse-' . $item['block'] : ($item['link'] ? $item['link'] : '#'); ?>" class="col color-dark icons-link collapsed"<?= $item['block'] ? ' data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="block-collapse-' . $item['block'] . '"' : null; ?>>
		<div class="icons-box">
			<i class="<?= $item['icon']; ?>"></i>
			<?php if ($item['badge']) { ?>
			<span><?= $item['badge']; ?></span>
			<?php } ?>
		</div>
		<p class="d-none d-md-block"><?= $item['title']; ?></p>
	</a>
	<?php if ($item['block']) { ?>
	<div class="collapse icons-block" id="block-collapse-<?= $item['block']; ?>" data-bs-parent="#block-collapse">
		<div class="row m-0">
			<div class="col flex-shrink-1"></div>
			<div class="col-auto icons-container bg-white border rounded shadow py-3">
				<div class="row">
					<div class="col-12 text-end">
						<button
							class="btn-close"
							type="button"
							data-bs-toggle="collapse"
							data-bs-target="#block-collapse-<?= $item['block']; ?>"
							aria-label="Close"
							aria-expanded="true"
							aria-controls="block-collapse-<?= $item['block']; ?>"
						></button>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<?php $view -> get('layout') -> launch('blocks', 'icons:' . $item['block']); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php } ?>
	<?php }); ?>
</div>