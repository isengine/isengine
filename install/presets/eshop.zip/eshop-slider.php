<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;

$count = Objects::len($object -> getData());

if (!$count) {
	return;
}

?>

<div id="carousel" class="carousel slide" data-bs-ride="carousel">
	<div class="carousel-indicators">
		<?php System::loop($count, function($c) { ?>
		<button type="button" data-bs-target="#carousel" data-bs-slide-to="<?= $c; ?>" class="<?= $c ? null : ' active'; ?>" aria-current="true" aria-label="Slide <?= $c++; ?>"></button>
		<?php }); ?>
	</div>
	<div class="carousel-inner">
		<?php Objects::each($object -> getData(), function($item, $key) { ?>
		<div class="carousel-item<?= $key ? null : ' active'; ?>">
			<img src="<?= $item['link']; ?>" class="d-block w-100" alt="<?= $item['title']; ?>">
			<div class="carousel-caption d-none d-md-block">
				<h5><?= $item['title']; ?></h5>
				<p><?= $item['description']; ?></p>
			</div>
		</div>
		<?php }); ?>
	</div>
	<button class="carousel-control-prev" type="button" data-bs-target="#carousel" data-bs-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Previous</span>
	</button>
	<button class="carousel-control-next" type="button" data-bs-target="#carousel" data-bs-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Next</span>
	</button>
</div>
