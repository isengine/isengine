<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

use is\Helpers\Paths;

use is\Helpers\Prepare;
use is\Helpers\Parser;
use is\Masters\Datasheet;
use is\Parents\Collection;

$view = View::getInstance();

$parents = '';

$settings = '{
	"driver" : "ExcelDB",
	"name" : "app:db",
	"collection" : "catalog",
	"rowkeys" : "0",
	"!rowkeys" : ["data:title", "data:price", "data:units"],
	"rowskip" : "0:1",
	"colskip" : "",
	"!encoding" : "CP1251",
	"fill" : 1,
	"fields" : {
		"parents" : {
			"from" : "fill",
			"!prepare" : "toObject:1|toString",
			"prepare" : [
				["toObject", 1]
			]
		},
		"data:group" : {
			"from" : "fill",
			"prepare" : "toObject"
		}
	}
}';

$settings = Parser::fromJson($settings);
$data = new Collection;

$db = new Datasheet;
$db -> init( $settings );
$db -> query('read');
$db -> rights(true);
$db -> driver -> parents( $parents );
$db -> collection($settings['collection']);
$db -> launch();
$data -> addByList( $db -> data -> getData() );
$db -> clear();
unset($db);

//System::debug($data -> getData());

?>
