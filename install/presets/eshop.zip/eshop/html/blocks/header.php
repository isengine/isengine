<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

$view -> get('block') -> launch('header:top-alert');
$view -> get('block') -> launch('header:top-nav');

$view -> get('module') -> launch('data', 'eshop-toasts');

$view -> get('block') -> launch('header:scroll-to-top');
$view -> get('block') -> launch('header:bottom-button');

?>
<header class="container-md header my-4" id="header">
	<div class="row align-items-center justify-content-between flex-nowrap d-none d-lg-flex mt-2 mb-4">
		<div class="col-auto">
			<?php $view -> get('block') -> launch('header:logo'); ?>
		</div>
		<?php $view -> get('block') -> launch('header:info'); ?>
	</div>
	<div class="row align-items-center justify-content-between position-relative">
		<div class="col-12 col-lg order-1">
			<div class="row align-items-center justify-content-between flex-nowrap">
				<div class="col-auto">
					<?php $view -> get('block') -> launch('header:catalog-button'); ?>
				</div>
				<div class="col">
					<?php $view -> get('block') -> launch('header:search'); ?>
				</div>
			</div>
		</div>
		<div class="col-12 col-lg-auto order-lg-1">
			<div class="row align-items-center justify-content-between flex-nowrap">
				<div class="col-auto d-block d-lg-none py-2">
					<?php $view -> get('block') -> launch('header:logo'); ?>
				</div>
				<div class="col-auto">
					<?php $view -> get('module') -> launch('data', 'eshop-icons'); ?>
				</div>
			</div>
		</div>
	</div>
	<?php $view -> get('module') -> launch('data', 'eshop-bottom-nav'); ?>
</header>

<?php $view -> get('block') -> launch('header:catalog'); ?>
