<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="bottom-button d-flex flex-column align-items-end">
	<div class="collapse" id="bottom-buttons-collapse">
		<?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:button rounded-circle button--blue:<i class="bi-telephone"></i>}'); ?>
		<?= $view -> get('tvars') -> launch('{mail|{lang|information:email:0}:button rounded-circle button--red:<i class="bi-envelope"></i>:Вопрос с сайта {state|site}}'); ?>
		<?= $view -> get('tvars') -> launch('{url|//www.instagram.com/is.engine/:button rounded-circle button--pink:<i class="bi-instagram"></i>}'); ?>
		<?= $view -> get('tvars') -> launch('{whatsapp|{lang|information:phone:0}:button rounded-circle button--green:<i class="bi-whatsapp"></i>:Здравствуйте! У меня есть вопрос}'); ?>
	</div>
	<a class="button rounded-circle bg-second" data-bs-toggle="collapse" href="#bottom-buttons-collapse" role="button" aria-expanded="false" aria-controls="bottom-buttons-collapse">
		<i class="bi-chat"></i>
	</a>
</div>