<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<a href="#offcanvasCatalog" class="catalog bg-theme py-0 px-4 d-block fs-6" data-bs-toggle="offcanvas" role="button" aria-controls="offcanvasCatalog">
	<!--<i class="fa fa-bars"></i>-->
	<i class="bi-list fs-2 align-middle"></i>
	<span class="ps-1 d-none d-lg-inline lh-1 align-text-bottom">Каталог товаров</span>
</a>