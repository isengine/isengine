<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>

<section class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasCatalog" aria-labelledby="offcanvasCatalogLabel">
	<div class="offcanvas-header">
		<h5 class="offcanvas-title" id="offcanvasCatalogLabel">
			<?php $view -> get('block') -> launch('header:logo'); ?>
		</h5>
		<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
	</div>
	<div class="offcanvas-body">
		<a href="/catalog/" class="h5 d-inline-block py-2 ps-md-3 pe-4 color-dark">
			Каталог
		</a>
		<?php $view -> get('module') -> launch('data', 'eshop-catalog'); ?>
		<?php
			$nav = $view -> get('state|structure');
			$lang = $view -> get('lang|this:top-nav');
		?>
		
		<h5 class="d-block py-2 ps-md-3 mt-4 color-dark">
			Меню
		</h5>
		<ul class="nav">
			<?php Objects::each($nav, function($item, $key) use ($lang) { ?>
			<li class="nav-item">
				<a class="nav-link color-nav p-0 pe-2 py-md-2 px-md-3" href="/<?= $key; ?>/"><?= $lang[$key]; ?></a>
			</li>
			<?php }, true); ?>
		</ul>
		
		<?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:h3 d-block py-2 ps-md-3 mt-4 color-nav}'); ?>
		
		<ul class="nav">
			<?php Objects::each($view -> get('lang|social'), function($item) { ?>
			<li class="nav-item">
				<a class="nav-link color-nav p-0 pe-2 py-md-2 px-md-3 fs-6" href="<?= $item['url']; ?>">
					<i class="<?= $item['class']; ?>"></i>
				</a>
			</li>
			<?php }, true); ?>
		</ul>
		
	</div>
</section>
