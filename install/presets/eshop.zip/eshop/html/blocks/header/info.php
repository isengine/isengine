<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="col-auto">
	<?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:color-second fs-4 fw-bold}'); ?>
	<br>
	<span class="color-grey">
	<?= $view -> get('tvars') -> launch('{mail|{lang|information:email:0}:color-grey}'); ?>
	<br>
	<?= $view -> get('tvars') -> launch('{url|#:color-grey:{lang|calltoaction}}'); ?>
	</span>
</div>
<div class="col-auto flex-shrink-1 ms-auto">
	<span class="color-grey">
		<?= $view -> get('lang|common:work', 'upperFirst'); ?>
	</span>
	<br>
		<?= $view -> get('lang|information:work:0', 'lower'); ?>,
		<?= $view -> get('lang|information:work:1', 'lower'); ?>,
		<?= $view -> get('lang|information:work:2', 'lower'); ?>
</div>
<div class="col-auto flex-shrink-1">
	<span class="color-grey">
		<?= $view -> get('lang|common:address', 'upperFirst'); ?>
	</span>
	<br>
		<?= $view -> get('lang|information:address', 'lower'); ?>
</div>