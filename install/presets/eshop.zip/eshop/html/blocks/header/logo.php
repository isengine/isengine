<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<a href="/" class="color-dark">
	<div class="row align-items-center">
		<div class="col-auto pe-1 pe-lg-2">
			<img class="logo" src="https://raw.githubusercontent.com/isengine/docs/master/logo/poster.svg" alt="<?= $view -> get('lang|title'); ?>">
		</div>
<!--
		<div class="col ps-0 pe-1 pe-lg-4">
			<span class="fs-2">isEngine</span>
			<br>
			Framework
		</div>
-->
	</div>
</a>