<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<a href="#" class="scroll-to-top rounded bg-theme">
	<i class="bi-chevron-up"></i>
</a>
