<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="container-fluid mb-2 top-alert alert" id="top-alert" role="alert">
	<div class="row">
		<div class="col-12">
			<div class="container">
				<div class="row align-items-center">
					<div class="col">
						<strong>Holy guacamole!</strong> You should check in on some of those fields below.
					</div>
					<div class="col-auto">
						<button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>