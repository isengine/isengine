<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

$nav = $view -> get('state|structure');
$lang = $view -> get('lang|this:top-nav');

?>
<section class="container top-nav d-none d-lg-block" id="top-nav">
	<ul class="nav">
		<?php Objects::each($nav, function($item, $key) use ($lang) { ?>
		<li class="nav-item">
			<!--<a class="nav-link active" aria-current="page" href="#">Active</a>-->
			<a class="nav-link" href="/<?= $key; ?>/"><?=  $lang[$key]; ?></a>
		</li>
		<?php }, true); ?>
	</ul>
</section>