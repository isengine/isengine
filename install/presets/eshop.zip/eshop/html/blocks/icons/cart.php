<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="container">
	<div class="h1">В корзине ничего нет</div>
	<p class="fs-6">Для выбора товаров, перейдите в каталог</p>
	<p><a class="btn bg-theme btn-lg mt-4" href="#" role="button">В каталог</a></p>
</div>