<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\Objects;
use is\Masters\View;

// читаем

$view = View::getInstance();

?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<script>
var toastElList = [].slice.call(document.querySelectorAll('.toast'))
var toastList = toastElList.map(function(toastEl) {
  return new bootstrap.Toast(toastEl, {
	  "animation" : true,
	  "autohide" : false
  }).show()
});
</script>


