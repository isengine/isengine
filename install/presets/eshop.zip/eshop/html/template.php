<?php

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Paths;
use is\Components\Config;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

$config = Config::getInstance();
$view = View::getInstance();

//$view -> get('block') -> launch('items:opening', 'default', null);
$view -> get('layout') -> launch('blocks:default', 'items:opening');

//$map = $view -> get('content|entry') -> getData();
$map = $view -> get('map') -> getData();
//$map = $view -> get('content');//|map');
System::debug($map);

$view -> get('block') -> launch('items:routing', 'default', null);
$view -> get('block') -> launch('items:ending', 'default', null);
?>