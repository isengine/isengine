<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$item = $object -> getData();

?>
<section>
	<div class="container">
		<div class="row">
			<div class="about-box-layout8 order-xl-2 order-lg-2 col-lg-8">
				<h1 class="item-title"><?= $item['title']; ?></h1>
				<div class="sub-title"><?= $item['sub']; ?></div>
				<p><?= $item['description']; ?></p>
			</div>
			<div class="about-box-layout9 order-xl-1 order-lg-1 col-lg-4">
				<img src="/img/about/title.png" alt="about" class="img-fluid">
			</div>
		</div>
	</div>
</section>