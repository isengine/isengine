<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

use is\Masters\View;

$view = View::getInstance(); 

?>
<section class="features-wrap-layout1">
	<div class="features-box-layout1 d-lg-flex bg-light-primary100">
		<div class="item-inner-wrapper">
			<div class="item-content d-flex align-items-center">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-12">
							<div class="item-content-inner content-dark">
								<h2 class="item-title"><?= $view -> get('lang|this:feature:title'); ?></h2>
								<p><?= $view -> get('lang|this:feature:description'); ?></p>
								<ul class="list-item">
									<?php Objects::each($object -> getData(), function($item) { ?>
										<li><?= $item; ?></li>
									<?php }); ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="item-inner-wrapper">
			<img src="/img/feature/title.jpg" class="img-responsive" alt="feature">
		</div>
	</div>
</section>