	<!-- Inne Page Banner Area Start Here -->
	<section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="/img/figure/figure2.jpg">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumbs-area">
						<h1>All Departments</h1>
						<ul>
							<li>
								<a href="#">Home</a>
							</li>
							<li>Departments</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Inne Page Banner Area End Here -->
	<!-- All Departments Area Start Here -->
	<section class="departments-wrap-layout8">
		<div class="container">
			<div class="row">
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department13.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Dental
										Care</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department14.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Eye
										Care</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department15.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Cardiology</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department16.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Orthopedic</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department17.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Pregnancy</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department18.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Neurology</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department19.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Hepatology</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department13.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Dental
										Care</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6 col-md-6 col-12">
					<div class="departments-box-layout5">
						<div class="item-img">
							<img src="/img/department/department16.jpg" alt="department" class="img-fluid">
							<div class="item-content">
								<h3 class="item-title title-bar-primary3"><a href="single-departments.html">Orthopedic</a></h3>
								<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
								<a href="single-departments.html" class="item-btn">DETAILS</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- All Departments  Area End Here -->
	<!-- Call to Action Area Start Here -->
	<section class="call-to-action-wrap-layout2 bg-common parallaxie" data-bg-image="/img/figure/figure4.jpg">
		<div class="container">
			<div class="call-to-action-box-layout2">
				<h2>We Provide the highest level of satisfaction<span> care &amp; services to our patients.</span></h2>
				<a href="#" class="item-btn">Make an Appointment</a>
			</div>
		</div>
	</section>
	<!-- Call to Action End Here -->