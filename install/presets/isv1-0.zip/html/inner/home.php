<?php

page('various', 'html');

?>