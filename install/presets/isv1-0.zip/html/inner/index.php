<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header1');
$view -> get('module') -> launch('data', 'slider');
$view -> get('module') -> launch('data', 'about:about-action');
$view -> get('module') -> launch('data', 'services:services-carousel');
$view -> get('module') -> launch('data', 'feature:feature2');
$view -> get('module') -> launch('data', 'progress');
$view -> get('module') -> launch('data', 'award');
$view -> get('module') -> launch('data', 'team');
$view -> get('module') -> launch('data', 'schedule');
$view -> get('layout') -> launch('blocks', 'banner');
$view -> get('module') -> launch('data', 'testimonials:testimonials-news');
$view -> get('layout') -> launch('blocks', 'call1');

?>