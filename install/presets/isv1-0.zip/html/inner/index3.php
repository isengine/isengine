<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header3');
$view -> get('module') -> launch('data', 'slider:slider3');
$view -> get('module') -> launch('data', 'info:info2');
$view -> get('module') -> launch('data', 'about:about-video');
$view -> get('module') -> launch('data', 'services:services2');
$view -> get('module') -> launch('data', 'feature');
$view -> get('module') -> launch('data', 'progress');
$view -> get('module') -> launch('data', 'team2');
$view -> get('module') -> launch('data', 'award');
$view -> get('module') -> launch('data', 'gallery');
$view -> get('layout') -> launch('blocks', 'call1');
$view -> get('module') -> launch('data', 'testimonials:testimonials-news');
$view -> get('module') -> launch('data', 'brands');

?>