<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="about-wrap-layout2">
	<div class="container">
		<div class="row">
			<div class="about-box-layout6 col-lg-6">
				<?php $view -> get('layout') -> launch('blocks', 'about:main'); ?>
			</div>
			<div class="about-box-layout7 col-lg-6">
				<?php $view -> get('layout') -> launch('blocks', 'about:video'); ?>
			</div>
		</div>
	</div>
</section>