<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section>
	<div class="container">
		<div class="row">
			<div class="about-box-layout8 order-xl-2 order-lg-2 col-lg-8">
				<?php $view -> get('layout') -> launch('blocks', 'about:main'); ?>
			</div>
			<div class="about-box-layout9 order-xl-1 order-lg-1 col-lg-4">
				<?php $view -> get('layout') -> launch('blocks', 'about:image'); ?>
			</div>
		</div>
	</div>
</section>