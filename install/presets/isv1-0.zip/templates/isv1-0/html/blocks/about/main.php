<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<h1 class="item-title"><?= $view -> get('lang|this:about:title'); ?></h1>
<div class="sub-title"><?= $view -> get('lang|this:about:sub'); ?></div>
<?= $view -> get('lang|this:about:description'); ?>