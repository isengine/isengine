<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<h2 class="item-title"><?= $view -> get('lang|this:about:title'); ?></h2>
<div class="sub-title"><?= $view -> get('lang|this:about:sub'); ?></div>
<?= $view -> get('lang|this:about:description'); ?>