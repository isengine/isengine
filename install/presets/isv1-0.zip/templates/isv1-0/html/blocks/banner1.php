<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Banner Area Start Here -->
<section class="banner-wrap-layout1 parallaxie" data-bg-image="/img/banner/background.jpg">
	<div class="container">
		<div class="row">
			<div class="col-xl-5 col-lg-8 col-md-10 col-12">
				<div class="banner-box-layout1">
					<h2 class="item-title"><?= $view -> get('lang|this:banner:title'); ?></h2>
					<h3 class="phone-number"><?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-white}'); ?></h3>
					<p><?= $view -> get('lang|this:banner:call-description'); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Banner End Here -->