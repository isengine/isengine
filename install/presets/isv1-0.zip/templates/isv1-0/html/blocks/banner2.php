<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="call-to-action-wrap-layout2 bg-common parallaxie" data-bg-image="/img/banner/background.jpg">
	<div class="container">
		<div class="call-to-action-box-layout2">
			<h2><?= $view -> get('lang|this:banner:description'); ?></span></h2>
			<a href="<?= $view -> get('lang|this:calltoaction:link'); ?>" class="item-btn"><?= $view -> get('lang|this:calltoaction:title'); ?></a>
		</div>
	</div>
</section>