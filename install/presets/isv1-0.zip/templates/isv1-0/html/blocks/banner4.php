<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="call-to-action-wrap-layout1">
	<div class="container">
		<div class="row">
			<div class="call-to-action-box-layout1 col-xl-6 col-lg-6 col-md-12 col-12">
				<h2 class="item-title"><?= $view -> get('lang|this:banner:call-title'); ?></h2>
			</div>
			<div class="call-to-action-box-layout1 col-xl-6 col-lg-6 col-md-12 col-12">
				<h2 class="item-title">
					<i class="fas fa-phone"></i><?= $view -> get('lang|this:banner:call-action'); ?><?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-white}'); ?></h2>
			</div>
		</div>
	</div>
</section>