<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<div class="widget widget-call-to-action">
	<div class="media">
		<i class="fas fa-headphones fa-3x item-img"></i>
		<div class="media-body space-sm">
			<h4>
				<?= $view -> get('lang|this:banner:call-action'); ?>
			</h4>
			<span>
				<?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-white}'); ?>
			</span>
		</div>
	</div>
</div>