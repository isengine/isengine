<?php

namespace is;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<h2 class="item-title"><?= $view -> get('lang|this:feature:title'); ?></h2>
<p><?= $view -> get('lang|this:feature:description'); ?></p>
<ul class="list-item">
	<?php $view -> get('module') -> launch('data', 'feature'); ?>
</ul>