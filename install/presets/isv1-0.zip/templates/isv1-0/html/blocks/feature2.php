<?php

namespace is;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="features-wrap-layout1">
	<div class="features-box-layout1 d-lg-flex bg-primary100">
		<div class="item-inner-wrapper">
			<div class="item-content d-flex align-items-center">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-12">
							<div class="item-content-inner content-light">
								<?php $view -> get('layout') -> launch('blocks', 'feature:module'); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php $view -> get('layout') -> launch('blocks', 'feature:image'); ?>
	</div>
</section>