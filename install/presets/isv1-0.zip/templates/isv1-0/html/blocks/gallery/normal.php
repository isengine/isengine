<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="gallery-wrap-layout1 bg-accent100">
	<?php $view -> get('module') -> launch('data', 'gallery'); ?> 
</section>