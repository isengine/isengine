<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Header Area Start Here -->
<header id="header_1">
	<div class="header-top-bar bg-primary100 d-none d-md-block">
		<div class="container">
			<div class="row">
				<div class="col-xl-8 col-lg-9 col-md-12 col-12 header-contact-layout3">
					<ul>
						<li><i class="fas fa-map-marker-alt"></i><?= $view -> get('lang|information:address'); ?></li>
						<li>
							<i class="fas fa-phone"></i>
							<?= $view -> get('lang|common:call', 'upperFirst') . ': '; ?>
							<?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-white}'); ?>
						</li>
						<li><i class="far fa-clock"></i><?php $view -> get('layout') -> launch('blocks', 'sub:work-alone'); ?></li>
					</ul>
				</div>
				<div class="col-xl-4 col-lg-3 col-md-12 col-12 header-social-layout2">
					<ul>
						<?php $view -> get('layout') -> launch('blocks', 'sub:social'); ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="header-menu-area header-menu-layout4">
		<div class="container">
			<div class="row no-gutters d-flex align-items-center">
				<div class="col-lg-2 logo-area-layout1">
					<?php $view -> get('layout') -> launch('blocks', 'sub:top-logo'); ?>
				</div>
				<div class="col-lg-7 position-static">
					<div class="template-main-menu">
						<?php //$view -> get('layout') -> launch('blocks', 'sub:nav'); ?>
						<?php $view -> get('module') -> launch('data', 'nav'); ?>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="header-action-items-layout1">
						<ul>
							<li class="d-none d-xl-block">
								<?php $view -> get('layout') -> launch('blocks', 'sub:search'); ?>
							</li>
							<li class="cart-area-dark">
								<?php $view -> get('layout') -> launch('blocks', 'sub:cart'); ?>
							</li>
							<li>
								<a href="<?= $view -> get('lang|this:calltoaction:link'); ?>" class="action-items-primary-btn ml-3"><?= $view -> get('lang|this:calltoaction:title'); ?></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<!-- Header Area End Here -->