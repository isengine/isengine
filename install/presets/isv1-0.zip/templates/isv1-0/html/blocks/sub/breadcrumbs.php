<?php

namespace is;
use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;

use is\Masters\View;

$view = View::getInstance();

$lang = $view -> get('lang|this:nav');
$route = $view -> get('state|route');
$last = System::typeIterable($route) ? Objects::last($route, 'value') : 'index';
$url = '/';
$title = $lang['title'][$last];

?>
<section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="/img/breadcrumbs/background.jpg">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="breadcrumbs-area">
					<h1><?= $title ? $title : $lang[$last]; ?></h1>
					<ul>
						<li>
							<a href="<?= $url; ?>"><?= $lang['index']; ?></a>
						</li>
						<?php
							Objects::each($route, function($item, $key, $pos) use ($lang, $url) {
								if ($pos === 'last' || $pos === 'alone') {
						?>
						<li><?= $lang[$item]; ?></li>
						<?php
								} else {
									$url .= $item . '/';
						?>
						<li>
							<a href="<?= $url; ?>"><?= $lang['index']; ?></a>
						</li>
						<?php
								}
							});
						?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>