<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="footer-bottom-wrap">
	<div class="copyright">© <?= date('Y') . ' ' . $view -> get('lang|title') . '. ' . $view -> get('lang|common:copyrights'); ?> <a href="<?= $view -> get('lang|agency:site'); ?>" target="blank"><?= $view -> get('lang|agency:name'); ?></a></div>
</section>