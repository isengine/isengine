<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<a href="/" class="temp-logo">
	<img src="/img/logo.png" alt="<?= $view -> get('lang|title'); ?> logo" class="img-fluid">
</a>