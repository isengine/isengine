<?php

namespace is;
use is\Helpers\System;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

$key = Objects::first($view -> get('lang|information:work'), 'key');
$val = Objects::first($view -> get('lang|information:work'), 'value');
echo (!System::type($key, 'numeric') ? $key . ' ' : null) . $val;

?>