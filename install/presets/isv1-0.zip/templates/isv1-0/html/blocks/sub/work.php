<?php

namespace is;
use is\Helpers\System;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<ul>
	<?php
		Objects::each($view -> get('lang|information:work'), function($item, $key) {
			echo '<li>' . (!System::type($key, 'numeric') ? $key . ' ' : null) . $item . '</li>';
		});
	?>
</ul>