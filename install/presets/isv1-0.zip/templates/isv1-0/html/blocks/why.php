<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="why-choose-wrap-layout1">
	<div class="container">
		<div class="row">
			<div class="why-choose-box-layout1 col-lg-6">
				<h2 class="item-title"><?= $view -> get('lang|this:why:title'); ?></h2>
				<p class="sub-title"><?= $view -> get('lang|this:why:description'); ?></p>
				<div class="choose-list-layout1">
					<?php $view -> get('module') -> launch('data', 'why:accordeon'); ?>
				</div>
			</div>
			<div class="why-choose-box-layout2 col-lg-6">
				<?php $view -> get('layout') -> launch('blocks', 'about:image'); ?>
			</div>
		</div>
	</div>
</section>