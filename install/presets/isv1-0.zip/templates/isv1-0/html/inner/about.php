<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>

<section class="about-wrap-layout3">
	<div class="container">
		<div class="row" id="no-equal-gallery">
			<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12 no-equal-item">
				<div class="widget widget-about-info">
					<ul class="nav nav-tabs tab-nav-list">
						<li class="nav-item">
							<a class="active" href="#related1" data-toggle="tab" aria-expanded="false">Who We
								Are</a>
						</li>
						<li class="nav-item">
							<a href="#related2" data-toggle="tab" aria-expanded="false">Our Mission</a>
						</li>
						<li class="nav-item">
							<a href="#related3" data-toggle="tab" aria-expanded="false">Experience</a>
						</li>
						<li class="nav-item">
							<a href="#related4" data-toggle="tab" aria-expanded="false">Awards</a>
						</li>
						<li class="nav-item">
							<a href="#related5" data-toggle="tab" aria-expanded="false">Success Story</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-xl-9 col-lg-8 no-equal-item">
				<div class="tab-content">
					<div class="tab-pane fade active show" id="related1">
						<div class="about-box-layout5">
							<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque.</p>
							<div class="row about-img">
								<div class="col-md-6 col-12">
									<img src="/img/about/about5.jpg" alt="about">
								</div>
								<div class="col-md-6 col-12">
									<img src="/img/about/about6.jpg" alt="about">
									<div class="item-btn">
										<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
											<i class="flaticon-play-button"></i>
										</a>
									</div>
								</div>
							</div>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
								et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
							<ul class="about-info">
								<li>Keep Patients First</li>
								<li>Pursue Excellence</li>
								<li>Keep Everyone Safe</li>
								<li>Manage Your Resources</li>
								<li>Work Together</li>
								<li>Keep Learning</li>
							</ul>
							<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
								perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
								adipiscing. Aliquam class bibendum mattis fusceut persecenas.
								Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
								mus. Hymenaeos eros.</p>
						</div>
					</div>
					<div class="tab-pane fade" id="related2">
						<div class="about-box-layout5">
							<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque.</p>
							<div class="row about-img">
								<div class="col-md-6 col-12">
									<img src="/img/about/about5.jpg" alt="about">
								</div>
								<div class="col-md-6 col-12">
									<img src="/img/about/about6.jpg" alt="about">
									<div class="item-btn">
										<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
											<i class="flaticon-play-button"></i>
										</a>
									</div>
								</div>
							</div>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
								et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
							<ul class="about-info">
								<li>Keep Patients First</li>
								<li>Pursue Excellence</li>
								<li>Keep Everyone Safe</li>
								<li>Manage Your Resources</li>
								<li>Work Together</li>
								<li>Keep Learning</li>
							</ul>
							<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
								perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
								adipiscing. Aliquam class bibendum mattis fusceut persecenas.
								Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
								mus. Hymenaeos eros.</p>
						</div>
					</div>
					<div class="tab-pane fade" id="related3">
						<div class="about-box-layout5">
							<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque.</p>
							<div class="row about-img">
								<div class="col-md-6 col-12">
									<img src="/img/about/about5.jpg" alt="about">
								</div>
								<div class="col-md-6 col-12">
									<img src="/img/about/about6.jpg" alt="about">
									<div class="item-btn">
										<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
											<i class="flaticon-play-button"></i>
										</a>
									</div>
								</div>
							</div>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
								et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
							<ul class="about-info">
								<li>Keep Patients First</li>
								<li>Pursue Excellence</li>
								<li>Keep Everyone Safe</li>
								<li>Manage Your Resources</li>
								<li>Work Together</li>
								<li>Keep Learning</li>
							</ul>
							<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
								perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
								adipiscing. Aliquam class bibendum mattis fusceut persecenas.
								Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
								mus. Hymenaeos eros.</p>
						</div>
					</div>
					<div class="tab-pane fade" id="related4">
						<div class="about-box-layout5">
							<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque.</p>
							<div class="row about-img">
								<div class="col-md-6 col-12">
									<img src="/img/about/about5.jpg" alt="about">
								</div>
								<div class="col-md-6 col-12">
									<img src="/img/about/about6.jpg" alt="about">
									<div class="item-btn">
										<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
											<i class="flaticon-play-button"></i>
										</a>
									</div>
								</div>
							</div>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
								et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
							<ul class="about-info">
								<li>Keep Patients First</li>
								<li>Pursue Excellence</li>
								<li>Keep Everyone Safe</li>
								<li>Manage Your Resources</li>
								<li>Work Together</li>
								<li>Keep Learning</li>
							</ul>
							<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
								perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
								adipiscing. Aliquam class bibendum mattis fusceut persecenas.
								Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
								mus. Hymenaeos eros.</p>
						</div>
					</div>
					<div class="tab-pane fade" id="related5">
						<div class="about-box-layout5">
							<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque.</p>
							<div class="row about-img">
								<div class="col-md-6 col-12">
									<img src="/img/about/about5.jpg" alt="about">
								</div>
								<div class="col-md-6 col-12">
									<img src="/img/about/about6.jpg" alt="about">
									<div class="item-btn">
										<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
											<i class="flaticon-play-button"></i>
										</a>
									</div>
								</div>
							</div>
							<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
								Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
								mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
								mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
								undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
								et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
							<ul class="about-info">
								<li>Keep Patients First</li>
								<li>Pursue Excellence</li>
								<li>Keep Everyone Safe</li>
								<li>Manage Your Resources</li>
								<li>Work Together</li>
								<li>Keep Learning</li>
							</ul>
							<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
								perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
								adipiscing. Aliquam class bibendum mattis fusceut persecenas.
								Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
								bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
								mus. Hymenaeos eros.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12 no-equal-item">
				<div class="widget widget-call-to-action-light">
					<div class="media">
						<img src="/img/figure/figure6.png" alt="figure">
						<div class="media-body space-sm">
							<h4>Emergency Cases</h4>
							<span>2-800-700-6200</span>
						</div>
					</div>
				</div>
				<div class="widget widget-ad-area">
					<div class="ad-wrap">
						<img src="/img/figure/figure5.jpg" alt="Figure">
						<div class="item-btn-wrap">
							<a class="item-btn" href="#">SEE DETAILS<i class="fas fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $view -> get('module') -> launch('data', 'team'); ?>
<?php $view -> get('module') -> launch('data', 'award'); ?>