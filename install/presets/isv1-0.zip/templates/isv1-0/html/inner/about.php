<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>

<section class="about-wrap-layout3">
	<div class="container">
		<div class="row" id="no-equal-gallery">
			
			<?php $view -> get('module') -> launch('data', 'about-tabs'); ?>
			
			<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12 no-equal-item">
				<?php $view -> get('layout') -> launch('blocks', 'banner5'); ?>
				<?php $view -> get('module') -> launch('data', 'ad'); ?>
			</div>
		</div>
	</div>
</section>

<?php $view -> get('module') -> launch('data', 'team'); ?>
<?php $view -> get('module') -> launch('data', 'award'); ?>