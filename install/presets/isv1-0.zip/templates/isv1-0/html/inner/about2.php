<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>

<section class="about-wrap-layout5">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="about-box-layout13">
					<?php $view -> get('layout') -> launch('blocks', 'feature:module'); ?>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="about-box-layout14">
					<?php $view -> get('layout') -> launch('blocks', 'about:video'); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $view -> get('module') -> launch('data', 'services:services-more'); ?>
<?php $view -> get('module') -> launch('data', 'indicators'); ?>
<?php $view -> get('layout') -> launch('blocks', 'why'); ?>
<?php $view -> get('module') -> launch('data', 'testimonials'); ?>
<?php $view -> get('module') -> launch('data', 'brands'); ?>