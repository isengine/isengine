<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>

<!-- About Us Start Here -->
<section class="about-wrap-layout5">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="about-box-layout13">
					<h2 class="item-title">Our Best Laboratory
						<span>Medical Center</span>
					</h2>
					<p>We offer extensive medical services for our patients recommend that you use officia.simply dummy
						text of theprinting and typesetting industry medical officia.simply dummy text of theprinting
						and typesetting industry.</p>
					<ul class="list-info">
						<li>Qualified Staff of Doctors</li>
						<li>Feel like you are at Home Services</li>
						<li>24x7 Emergency Services</li>
						<li>Easy and Affordable Billing</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="about-box-layout14">
					<div class="item-video">
						<img src="/img/about/about2.jpg" alt="about">
						<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
						<i class="flaticon-play-button"></i>
						</a>
					</div>
				</div>   
			</div>
		</div>
	</div>
</section>
<!-- About Us Area End Here --> 

<?php $view -> get('module') -> launch('data', 'services:services-more'); ?>
<?php $view -> get('module') -> launch('data', 'indicators'); ?>

<!-- Why Choose Area Start Here -->
<section class="why-choose-wrap-layout1">
	<div class="container">
		<div class="row">
			<div class="why-choose-box-layout1 col-lg-6">
				<h2 class="item-title">Why People Choose Us?</h2>
				<p class="sub-title">We offer extensive medical services for our patients recommend that you use officia.</p>
				<div class="choose-list-layout1">
					<div class="panel-group" id="accordion">
						<div class="panel panel-default">
							<div class="panel-heading active">
								<div class="panel-title">
									<a aria-expanded="false" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Using Innovative Technology</a>
								</div>
							</div>
							<div aria-expanded="false" id="collapseOne" role="tabpanel" class="panel-collapse collapse show">
								<div class="panel-body">
									<p>Moimply dummy text of the printing and type settingaindustry. Lorem Ipsum has
										been the industry’s standard dummy text ever since thelong established fact
										thaaret </p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="panel-title">
									<a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Guarantee Success of Treatments</a>
								</div>
							</div>
							<div aria-expanded="false" id="collapseTwo" role="tabpanel" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Moimply dummy text of the printing and type settingaindustry. Lorem Ipsum has
										been the industry’s standard dummy text ever since thelong established fact
										thaaret </p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="panel-title">
									<a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Accepting Insurance Cards</a>
								</div>
							</div>
							<div aria-expanded="false" id="collapseThree" role="tabpanel" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Moimply dummy text of the printing and type settingaindustry. Lorem Ipsum has
										been the industry’s standard dummy text ever since thelong established fact
										thaaret </p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="why-choose-box-layout2 col-lg-6">
				<img src="/img/about/about2.png" alt="about" class="img-fluid">
			</div>
		</div>
	</div>
</section>
<!-- Why Choose Area End Here -->

<?php $view -> get('module') -> launch('data', 'testimonials'); ?>
<?php $view -> get('module') -> launch('data', 'brands'); ?>