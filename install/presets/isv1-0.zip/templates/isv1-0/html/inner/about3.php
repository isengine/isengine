<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>

<section class="about-wrap-layout4">
	<div class="container">
		<?php $view -> get('module') -> launch('data', 'about-slider'); ?>
	</div>
</section>

<section class="bg-light-secondary100">
	<div class="container">
		<div class="row">
			<div class="about-box-layout11 col-lg-7 col-12">
				<?php $view -> get('layout') -> launch('blocks', 'about:submain'); ?>
			</div>
			<div class="about-box-layout12 col-lg-5 col-12">
				<?php $view -> get('layout') -> launch('blocks', 'about:image'); ?>
			</div>
		</div>
	</div>
</section>

<?php $view -> get('module') -> launch('data', 'indicators'); ?>
<?php $view -> get('module') -> launch('data', 'team'); ?>
<?php $view -> get('module') -> launch('data', 'testimonials'); ?>
<?php $view -> get('module') -> launch('data', 'brands'); ?>
