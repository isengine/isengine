<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>

<!-- About Area Start Here -->
<section class="about-wrap-layout4">
	<div class="container">
		<div id="slick-carousel-wrap2" class="row about-box-layout10">
			<div class="col-lg-6 col-md-5 about-img carousel-nav">
				<div class="nav-item"><img src="/img/about/about3.jpg" alt="brand" class="img-fluid"></div>
				<div class="nav-item"><img src="/img/about/about4.jpg" alt="brand" class="img-fluid"></div>
				<div class="nav-item"><img src="/img/about/about3.jpg" alt="brand" class="img-fluid"></div>
				<div class="nav-item"><img src="/img/about/about4.jpg" alt="brand" class="img-fluid"></div>
			</div>
			<div class="col-lg-6 col-md-7 carousel-content about-content">
				<div class="single-item">
					<h2 class="item-title">Laboratory Place
						<span>In Medicine Practice</span>
					</h2>
					<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
						ulm hedi corper turet.</p>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
				</div>
				<div class="single-item">
					<h2 class="item-title">Laboratory Place
						<span>In Medicine Practice</span>
					</h2>
					<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
						ulm hedi corper turet.</p>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
				</div>
				<div class="single-item">
					<h2 class="item-title">Laboratory Place
						<span>In Medicine Practice</span>
					</h2>
					<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
						ulm hedi corper turet.</p>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
				</div>
				<div class="single-item">
					<h2 class="item-title">Laboratory Place
						<span>In Medicine Practice</span>
					</h2>
					<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
						ulm hedi corper turet.</p>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- About Area End Here -->

<!-- About Area Start Here -->
<section class="bg-light-secondary100">
	<div class="container">
		<div class="row">
			<div class="about-box-layout11 col-lg-7 col-12">
				<h2 class="item-title">We Here To Care
					<span>About Health</span>
				</h2>
				<div class="sub-title">Hospital imply dummy text of the printing and type setng industry been the industry.</div>
				<p>Mtandard dummy texr since when an unknown printer took a galley.MediPoint Lorem ipsum dolor sit amet,
					consetetur sadipscing elitr, At accusam aliquyam.'s standard dummy texr since when an unknown
					printer took a galley consetetur. Moimply dummy text of the printing and type settingaindustry. Lorem Ipsum has
					been the industry’s standard dummy text ever since thelong established fact thaaret</p>
				<img src="/img/about/sign1.png" alt="sign" class="img-fluid">
			</div>
			<div class="about-box-layout12 col-lg-5 col-12">
				<img src="/img/about/about4.png" alt="about" class="img-fluid">
			</div>
		</div>
	</div>
</section>
<!-- About Area End Here -->

<?php $view -> get('module') -> launch('data', 'indicators'); ?>
<?php $view -> get('module') -> launch('data', 'team'); ?>
<?php $view -> get('module') -> launch('data', 'testimonials'); ?>
<?php $view -> get('module') -> launch('data', 'brands'); ?>
