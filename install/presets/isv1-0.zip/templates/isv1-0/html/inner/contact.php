<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="contact-wrap-layout">
	<div class="container">
		<div class="google-map-area">
			<?php $view -> get('module') -> launch('map'); ?>
		</div>
		<div class="row">
			<div class="col-lg-8">
				<div class="contact-box-layout1">
					<h3 class="title title-bar-primary4"><?= $view -> get('lang|this:submit:title'); ?></h3>
					<?php $view -> get('module') -> launch('data', 'form-contact'); ?>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="contact-box-layout1">
					<h3 class="title title-bar-primary4"><?= $view -> get('lang|common:address'); ?></h3>
					<div class="contact-info">
						<ul>
							<li>
								<i class="fas fa-map-marker-alt"></i>
								<?= $view -> get('lang|information:address'); ?>
							</li>
							<li>
								<i class="far fa-envelope"></i>
								<?= $view -> get('tvars') -> launch('{mail|{lang|information:email:0}:text-dark}'); ?>
							</li>
							<li>
								<i class="fas fa-phone"></i>
								<?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-dark}'); ?>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>