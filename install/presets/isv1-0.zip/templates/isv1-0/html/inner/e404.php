	<!-- Error Page Area Start Here -->
	<section class="error-wrap-layout1 bg-light-accent100 inner-page-top-margin">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="error-box-layout1">
						<img src="/img/404.png" alt="404" class="img-fluid">
						<h2 class="title">OOPS! That Page Can’t Be Found</h2>
						<p class="details">The page your are looking for is not available or has been removed. Try
							going to Home Page by using the buton below</p>
						<a href="#" class="item-btn">Go Back Home</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Error Page Area End Here -->