<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header1');
$view -> get('module') -> launch('data', 'slider');
$view -> get('layout') -> launch('blocks', 'about-action');
$view -> get('module') -> launch('data', 'services:services-carousel');
$view -> get('layout') -> launch('blocks', 'feature2');
$view -> get('module') -> launch('data', 'progress');
$view -> get('module') -> launch('data', 'award');
$view -> get('module') -> launch('data', 'team');
$view -> get('module') -> launch('data', 'schedule');
$view -> get('layout') -> launch('blocks', 'banner1');
$view -> get('module') -> launch('data', 'testimonials:testimonials-news');
$view -> get('layout') -> launch('blocks', 'banner3');

?>