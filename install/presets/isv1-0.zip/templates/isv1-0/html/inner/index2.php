<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header2');
$view -> get('module') -> launch('data', 'slider:slider4');
$view -> get('module') -> launch('data', 'action');
$view -> get('module') -> launch('data', 'about:about-info');
$view -> get('module') -> launch('data', 'services:services-slider');
$view -> get('module') -> launch('data', 'indicators:indicators2');
$view -> get('module') -> launch('data', 'progress');
$view -> get('module') -> launch('data', 'schedule');
$view -> get('module') -> launch('data', 'testimonials');
$view -> get('module') -> launch('data', 'gallery');
$view -> get('layout') -> launch('blocks', 'banner1');
$view -> get('module') -> launch('data', 'news');
$view -> get('module') -> launch('data', 'brands');

?>