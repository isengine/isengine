<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header4');
$view -> get('module') -> launch('data', 'slider:slider2');
$view -> get('module') -> launch('data', 'info:info-in-previous');
$view -> get('module') -> launch('data', 'about');
$view -> get('module') -> launch('data', 'services:services-more');
$view -> get('module') -> launch('data', 'progress');
$view -> get('module') -> launch('data', 'award');
$view -> get('module') -> launch('data', 'team3');
$view -> get('module') -> launch('data', 'schedule');
$view -> get('module') -> launch('data', 'indicators');
$view -> get('module') -> launch('data', 'shop');
$view -> get('module') -> launch('data', 'testimonials');
$view -> get('module') -> launch('data', 'news:news2');
$view -> get('layout') -> launch('blocks', 'banner4');

?>