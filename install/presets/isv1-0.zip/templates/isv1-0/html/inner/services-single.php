<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="single-department-wrap-layout1 bg-light-primary100">
	<div class="container">
		<div class="row" id="no-equal-gallery">
			<?php $view -> get('module') -> launch('data', 'services:services-tabs'); ?>
			
			<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12 no-equal-item">
				<?php $view -> get('layout') -> launch('blocks', 'banner5'); ?>
				<?php $view -> get('layout') -> launch('blocks', 'work'); ?>
				<div class="widget widget-appointment">
					<h3 class="section-title-light title-bar-light"><?= $view -> get('lang|this:services:form'); ?></h3>
					<?php $view -> get('module') -> launch('data', 'form-services'); ?>
				</div>
			</div>
		</div>
	</div>
</section>