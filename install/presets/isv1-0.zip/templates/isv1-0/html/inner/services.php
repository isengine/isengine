<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="departments-wrap-layout8 bg-light-accent100">
	<div class="container">
		<div class="row">
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department1.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Dental Care</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>06</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department2.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Orthopedic</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>08</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department3.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Eye Care</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>02</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department4.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Cardiology</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>10</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department5.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Gynecology</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>06</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department6.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Hepatology</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>08</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department7.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Pediatrics</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>02</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department8.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Medicne</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>10</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department9.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Neurology</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>06</span>Specialist Docotrs</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department10.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Diabetes</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>08</span>Specialist Docotrs
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department11.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Gastroenterology</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>02</span>Specialist Docotrs
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-lg-4 col-md-6 col-12 menu-item">
				<div class="departments-box-layout1">
					<div class="item-img">
						<img src="/img/department/department12.jpg" alt="department" class="img-fluid">
						<div class="item-btn-wrap">
							<a href="single-departments.html" class="item-btn">Details</a>
						</div>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-departments.html">Ophthalmology</a>
						</h3>
						<ul class="department-info">
							<li>
								<i class="flaticon-doctor"></i>
								<span>10</span>Specialist Docotrs
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $view -> get('layout') -> launch('blocks', 'banner2'); ?>