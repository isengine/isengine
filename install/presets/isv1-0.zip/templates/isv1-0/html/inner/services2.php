<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="departments-wrap-layout8">
	<div class="container">
		<div class="row">
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department13.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Dental Care</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department14.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Eye Care</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department15.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Cardiology</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department16.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Orthopedic</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department17.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Pregnancy</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department18.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Neurology</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department19.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Hepatology</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department13.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Dental Care</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-lg-6 col-md-6 col-12">
				<div class="departments-box-layout5">
					<div class="item-img">
						<img src="/img/department/department16.jpg" alt="department" class="img-fluid">
						<div class="item-content">
							<h3 class="item-title title-bar-primary3">
								<a href="single-departments.html">Orthopedic</a>
							</h3>
							<p>Eye ipsum dolor sit amet, consectetur inglity wisi enim minim veniam</p>
							<a href="single-departments.html" class="item-btn">DETAILS</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $view -> get('layout') -> launch('blocks', 'banner2'); ?>