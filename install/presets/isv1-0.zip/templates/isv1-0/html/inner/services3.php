	<!-- Department Start Here -->
	<section class="departments-wrap-layout5 bg-light-accent100">
		<div class="container">
			<div class="row gutters-20">
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-medical"></i>
							<h3 class="item-title"><a href="single-departments.html">Dental Care</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-pills"></i>
							<h3 class="item-title"><a href="single-departments.html">Medicine</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-human-hip"></i>
							<h3 class="item-title"><a href="single-departments.html">Orthopedic</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-heart"></i>
							<h3 class="item-title"><a href="single-departments.html">Cardiology</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-doctor-stethoscope"></i>
							<h3 class="item-title"><a href="single-departments.html">Primary Care</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-eye"></i>
							<h3 class="item-title"><a href="single-departments.html">Eye Care</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4 float-shadow">
						<div class="box-content">
							<i class="flaticon-ambulance"></i>
							<h3 class="item-title"><a href="single-departments.html">Emergency</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-first-aid-kit"></i>
							<h3 class="item-title"><a href="single-departments.html">Skilled Doctors</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-12">
					<div class="departments-box-layout4">
						<div class="box-content">
							<i class="flaticon-medal"></i>
							<h3 class="item-title"><a href="single-departments.html">Certified Clinic</a></h3>
							<p>There are many variations of of Lorem Ipsum available, but the majority have
								suffered..</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Department Area End Here -->