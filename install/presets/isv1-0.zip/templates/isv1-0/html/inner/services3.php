<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<section class="departments-wrap-layout5 bg-light-accent100">
	<div class="container">
		<div class="row gutters-20">
			<?php $view -> get('module') -> launch('data', 'services:services-main3'); ?>
		</div>
	</div>
</section>