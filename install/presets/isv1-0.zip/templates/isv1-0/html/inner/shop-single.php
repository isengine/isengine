	<!-- Shop Details Start Here -->
	<section class="single-product-wrap bg-light-primary100">
		<div class="container">
			<div class="row">
				<div class="col-xl-9 col-lg-8 col-12 margin-b-30r">
					<div class="single-product-box">
						<div class="row">
							<div class="col-xl-6 col-12">
								<div class="single-product-gallery">
									<div class="tab-content">
										<div role="tabpanel" class="tab-pane fade active show" id="fitness-related1">
											<a href="#">
												<img alt="single" src="/img/shop/shop6.png" class="img-responsive">
											</a>
										</div>
										<div role="tabpanel" class="tab-pane fade" id="fitness-related2">
											<a href="#">
												<img alt="single" src="/img/shop/shop6.png" class="img-responsive">
											</a>
										</div>
										<div role="tabpanel" class="tab-pane fade" id="fitness-related3">
											<a href="#">
												<img alt="single" src="/img/shop/shop6.png" class="img-responsive">
											</a>
										</div>
									</div>
									<ul class="nav nav-tabs">
										<li class="nav-item">
											<a href="#fitness-related1" data-toggle="tab" aria-expanded="false"
												class="active">
												<img alt="fitness-related1" src="/img/shop/shop7.png" class="img-responsive">
											</a>
										</li>
										<li class="nav-item">
											<a href="#fitness-related2" data-toggle="tab" aria-expanded="false">
												<img alt="fitness-related2" src="/img/shop/shop7.png" class="img-responsive">
											</a>
										</li>
										<li class="nav-item">
											<a href="#fitness-related3" data-toggle="tab" aria-expanded="false">
												<img alt="fitness-related3" src="/img/shop/shop7.png" class="img-responsive">
											</a>
										</li>
									</ul>
								</div>
							</div>
							<div class="col-xl-6 col-12">
								<div class="single-product-info">
									<h2 class="item-title">Medical Product Title</h2>
									<ul class="rating">
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
									</ul>
									<div class="price">$59.00</div>
									<div class="item-sku">SKU:
										<span>SB0059</span>
									</div>
									<div class="item-stock">Availablity:
										<span> Instock</span>
									</div>
									<p>Working from home meant we couldsnack and coffee our breaks change our desks
										or view,
										good, drink on the job, even spend the weather started getting.</p>
									<div class="cart-action-area">
										<form id="cart-quantity">
											<ul class="cart-quantity">
												<li>
													<div class="input-group quantity-holder" id="quantity-holder2">
														<input type="text" name='quantity' class="form-control quantity-input"
															value="1" placeholder="1">
														<div class="btn-quantity-select">
															<button class="quantity-plus" type="button">
																<i class="fas fa-plus"></i>
															</button>
															<button class="quantity-minus" type="button">
																<i class="fas fa-minus"></i>
															</button>
														</div>
													</div>
												</li>
												<li>
													<a href="#" class="item-btn">Add To Cart</a>
												</li>
											</ul>
										</form>
										<ul class="cart-favourite">
											<li>
												<a href="#">
													<i class="flaticon-exchange-arrows"></i>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="flaticon-favorite-heart-button"></i>
												</a>
											</li>
										</ul>
									</div>
									<div class="product-share">
										<ul>
											<li>Share With:</li>
											<li>
												<a href="#">
													<i class="fab fa-facebook-f"></i>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="fab fa-twitter"></i>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="fab fa-linkedin-in"></i>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="fab fa-pinterest-p"></i>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="fab fa-skype"></i>
												</a>
											</li>
											<li>
												<a href="#">
													<i class="fab fa-youtube"></i>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="single-product-tab">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12">
								<ul class="nav nav-tabs">
									<li class="nav-item">
										<a href="#description" data-toggle="tab" aria-expanded="false" class="active">Description</a>
									</li>
									<li class="nav-item">
										<a href="#review" data-toggle="tab" aria-expanded="false">Reviews(3)</a>
									</li>
								</ul>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12">
								<div class="tab-content">
									<div role="tabpanel" class="tab-pane fade active show" id="description">
										<p>Yorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla
											augue
											nec est tristique auctor. Donec non est at libero vulputate rutrum.
											Morbi
											justo gravida semper.</p>
										<ul class="list-content">
											<li>Seat Height – Floor to Seat: 24”</li>
											<li>Frame Material: Wood</li>
											<li>Seat Material: Wood</li>
											<li>Adjustable Height: No</li>
											<li>Overall: 24” H x 17” W x 14” D</li>
										</ul>
									</div>
									<div role="tabpanel" class="tab-pane fade" id="review">
										<p>Porem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
											nonummy nibh
											euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut
											wisi
											enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit
											lobortis
											nisl ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit
											adipiscing
											elit ut laoreet dolore magna aliquam.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="related-product">
						<h3 class="item-title title-bar-primary2">Related Products</h3>
						<div class="rc-carousel nav-control-layout6" data-loop="true" data-items="2" data-margin="30"
							data-autoplay="true" data-autoplay-timeout="5000" data-smart-speed="2000" data-dots="false"
							data-nav="true" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true"
							data-r-x-small-dots="false" data-r-x-medium="2" data-r-x-medium-nav="true"
							data-r-x-medium-dots="false" data-r-small="3" data-r-small-nav="true" data-r-small-dots="false"
							data-r-medium="3" data-r-medium-nav="true" data-r-medium-dots="false" data-r-large="3"
							data-r-large-nav="true" data-r-large-dots="false" data-r-extra-large="4"
							data-r-extra-large-nav="false" data-r-extra-large-dots="false">
							<div class="shop-box-layout1">
								<div class="item-img">
									<img src="/img/shop/shop1.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
							<div class="shop-box-layout1">
								<div class="item-img">
									<img src="/img/shop/shop2.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
							<div class="shop-box-layout1">
								<div class="item-img">
									<img src="/img/shop/shop3.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
							<div class="shop-box-layout1">
								<div class="item-img">
									<img src="/img/shop/shop4.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
							<div class="shop-box-layout1">
								<div class="item-img">
									<img src="/img/shop/shop5.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12">
					<div class="widget widget-categories">
						<h3 class="section-title title-bar-primary">Categories</h3>
						<ul>
							<li>
								<a href="#">Cardiology
									<span>15</span>
								</a>
							</li>
							<li>
								<a href="#">Dental
									<span>10</span>
								</a>
							</li>
							<li>
								<a href="#">Laboratory
									<span>14</span>
								</a>
							</li>
							<li>
								<a href="#">Research
									<span>13</span>
								</a>
							</li>
							<li>
								<a href="#">Eye
									<span>19</span>
								</a>
							</li>
						</ul>
					</div>
					<div class="widget widget-top-rated">
						<h3 class="section-title title-bar-primary">Related Products</h3>
						<ul>
							<li class="media">
								<div class="top-rated-img">
									<a href="#">
										<img src="/img/shop/shop1.jpg" class="img-responsive" alt="related">
									</a>
								</div>
								<div class="media-body space-md top-rated-content">
									<h4>
										<a href="#">Thermometer</a>
									</h4>
									<ul class="rating">
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
									</ul>
									<div class="amount">
										<span class="currency">$</span>15</div>
								</div>
							</li>
							<li class="media">
								<div class="top-rated-img">
									<a href="#">
										<img src="/img/shop/shop1.jpg" class="img-responsive" alt="related">
									</a>
								</div>
								<div class="media-body space-md top-rated-content">
									<h4>
										<a href="#">Thermometer</a>
									</h4>
									<ul class="rating">
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
									</ul>
									<div class="amount">
										<span class="currency">$</span>15</div>
								</div>
							</li>
							<li class="media">
								<div class="top-rated-img">
									<a href="#">
										<img src="/img/shop/shop1.jpg" class="img-responsive" alt="related">
									</a>
								</div>
								<div class="media-body space-md top-rated-content">
									<h4>
										<a href="#">Thermometer</a>
									</h4>
									<ul class="rating">
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
									</ul>
									<div class="amount">
										<span class="currency">$</span>15</div>
								</div>
							</li>
						</ul>
					</div>
					<div class="widget widget-price-range">
						<h3 class="section-title title-bar-primary">Filder By Price</h3>
						<div id="price-range-wrapper" class="price-range-wrapper">
							<div id="price-range-filter"></div>
							<div class="price-filter-wrap d-flex align-items-center">
								<div class="price-range-select">
									<div class="price-range">Price:</div>
									<div class="price-range" id="price-range-min"></div>
									<div class="price-range">-</div>
									<div class="price-range" id="price-range-max"></div>
								</div>
								<div class="filter-button">
									<button class="item-btn btn-ghost size-xs radius-4 text-capitalize" type="submit"
										value="Login">Filter</button>
								</div>
							</div>
						</div>
					</div>
					<div class="widget widget-tag">
						<h3 class="section-title title-bar-primary">Tags</h3>
						<ul>
							<li>
								<a href="#">Dental</a>
							</li>
							<li>
								<a href="#">Eye Care</a>
							</li>
							<li>
								<a href="#">Labrotary</a>
							</li>
							<li>
								<a href="#">Care</a>
							</li>
							<li>
								<a href="#">Health</a>
							</li>
							<li>
								<a href="#">Modern Clinic</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Shop Details End Here -->