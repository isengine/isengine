<section class="team-wrap-layout3 bg-light-accent100">
	<div class="container">
		<!--
		<div class="team-search-box">
			<form action="get">
				<div class="row">
					<div class="col-xl-4">
						<div class="form-group">
							<select class="select2">
								<option value="0">Select Department</option>
								<option value="1">Cardiology</option>
								<option value="2">Gastroenterology</option>
								<option value="3">Neurology</option>
								<option value="4">Urology</option>
								<option value="4">UGC</option>
							</select>
						</div>
					</div>
					<div class="col-xl-6">
						<div class="form-group">
							<input class="doctor-name form-control" type="text" placeholder="Type Doctor Name Here ..."
								name="doctor-name" value="">
						</div>
					</div>
					<div class="col-xl-2">
						<div class="form-group">
							<button type="submit" class="item-btn">Search</button>
						</div>
					</div>
				</div>
			</form>
		</div>
		-->
		<div class="row">
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team21.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team22.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team23.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team24.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team25.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team26.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team27.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="team-box-layout1">
					<div class="media media-none-lg media-none-md media-none--xs">
						<div class="item-img">
							<img src="/img/team/team28.png" alt="Team1" class="img-fluid rounded-circle media-img-auto">
						</div>
						<div class="media-body">
							<div class="item-content">
								<h4 class="item-title">
									<a href="single-doctor.html">Dr.Mark Willy</a>
								</h4>
								<p class="designation">Associate Eye</p>
								<div class="item-degree">BDS, FCPS (Hons), PhD (Japan)</div>
								<ul class="item-btns">
									<li>
										<a href="single-doctor.html" class="item-btn btn-ghost">View Profile</a>
									</li>
									<li>
										<a href="single-doctor.html" class="item-btn btn-fill">Make an
											Appointment</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<ul class="pagination-layout2 margin-t-50r">
			<li>
				<a href="#">Previous</a>
			</li>
			<li class="active">
				<a href="#">1</a>
			</li>
			<li>
				<a href="#">2</a>
			</li>
			<li>
				<a href="#">3</a>
			</li>
			<li>
				<a href="#">Next</a>
			</li>
		</ul>
	</div>
</section>