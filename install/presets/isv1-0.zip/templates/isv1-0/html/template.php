<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Paths;
use is\Helpers\Parser;
use is\Helpers\Datetimes;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

$page = Strings::join($view -> get('state|route'), ':');
$nobreadcrumbs = Objects::match(
	$view -> get('special') -> search( $page ? $page : 'index' ),
	'nobreadcrumbs'
);
unset($page);

//$view -> get('layout') -> launch('blocks', 'guitar');
$view -> get('layout') -> launch('blocks:default', 'items:opening');

?>

<div id="preloader"></div>

<a href="#wrapper" data-type="section-switch" class="scrollUp">
	<i class="fas fa-angle-double-up"></i>
</a>

<div id="wrapper" class="wrapper">
	<?php
		// uncomment next line on production
		// раскомментируйте следующую строку на рабочем проекте
		//$view -> get('layout') -> launch('blocks', 'header1');
		
		$state = $view -> get('state') -> getData();
		unset($state['settings']);
		
		if (!(
			!$state['parents'] &&
			(!$state['page'] || Strings::find($state['page'], 'index', 0))
		)) {
			// comment next line on production
			// закомментируйте следующую строку на рабочем проекте
			$view -> get('layout') -> launch('blocks', 'header1');
			
			if (!$nobreadcrumbs) { $view -> get('layout') -> launch('blocks', 'sub:breadcrumbs'); }
		}
		
		unset($state);
		
		$view -> get('layout') -> launch('blocks:default', 'items:routing');
	?>
</div>

<?php $view -> get('layout') -> launch('blocks:default', 'items:ending'); ?>