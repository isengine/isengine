<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Paths;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

//

use is\Components\Uri;
use is\Components\Config;

$config = Config::getInstance();
$uri = Uri::getInstance();

// читаем

$view = View::getInstance();

// код

$view -> get('layout') -> launch('blocks:default', 'items:opening');
?>
<main class="">
<?php $view -> get('layout') -> launch('blocks:default', 'items:routing'); ?>
</main>
<?php $view -> get('layout') -> launch('blocks:default', 'items:ending'); ?>