<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;
use is\Masters\View;

$view = View::getInstance(); 

$item = &$object -> settings;

?>
<!-- About Area Start Here -->
<section class="about-wrap-layout1" data-bg-image="<?= $item['background']; ?>">
	<div class="container">
		<div class="row">
			<div class="about-box-layout1 order-xl-2 col-xl-5 col-12">
				<div class="item-content">
					<h2 class="item-title"><?= $item['title']; ?></h2>
					<div class="sub-title"><?= $item['sub']; ?></div>
					<?= $item['description']; ?>
				</div>
			</div>
			<div class="about-box-layout2 order-xl-3 col-xl-4 col-lg-7 col-12">
				<?php $view -> get('module') -> launch('data', 'action1'); ?>
			</div>
			<div class="about-box-layout2 order-xl-1 col-xl-3 col-lg-5 col-12">
				<div class="item-img">
					<img src="<?= $item['image']; ?>" alt="about" class="img-fluid">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- About Area End Here -->