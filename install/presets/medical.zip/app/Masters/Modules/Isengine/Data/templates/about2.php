<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

use is\Masters\View;

$view = View::getInstance(); 

$item = &$object -> settings;

?>
<!-- About Area Start Here -->
<section class="about-wrap-layout2">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-12">
				<div class="about-box-layout3">
					<h2 class="item-title"><?= $item['title']; ?></h2>
					<?= $item['description']; ?>
				</div>
			</div>
			<div class="col-lg-8 col-12">
				<div class="row">
					<?php $view -> get('module') -> launch('data', 'action5'); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- About Area End Here -->