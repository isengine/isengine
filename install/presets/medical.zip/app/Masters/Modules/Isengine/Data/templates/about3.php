<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;
$item = &$object -> settings;

?>
<!-- About Area Start Here -->
<section class="about-wrap-layout2">
	<div class="container">
		<div class="row">
			<div class="about-box-layout6 col-lg-6">
				<h1 class="item-title"><?= $item['title']; ?></h1>
				<div class="sub-title"><?= $item['sub']; ?></div>
				<?= $item['description']; ?>
			</div>
			<div class="about-box-layout7 col-lg-6">
				<div class="item-video">
					<img src="https://img.youtube.com/vi/<?= $item['video']; ?>/maxresdefault.jpg" alt="about">
					<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=<?= $item['video']; ?>">
						<i class="flaticon-play-button"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- About Area End Here -->