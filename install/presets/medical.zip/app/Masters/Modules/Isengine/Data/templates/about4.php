<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;
$item = &$object -> settings;

Objects::each($object -> settings['data'], function($item) use (&$content){
	
	$content .= '
		<li>
			<a href="' . $item['link'] . '">
				<i class="' . $item['icon'] . '"></i>
				' . $item['title'] . '
			</a>
		</li>
	';
	
});

?>
<!-- About Area Start Here -->
<section>
	<div class="container">
		<div class="row">
			<div class="about-box-layout8 order-xl-2 order-lg-2 col-lg-8">
				<h1 class="item-title"><?= $item['title']; ?></h1>
				<div class="sub-title"><?= $item['sub']; ?></div>
				<p><?= $item['description']; ?></p>
			</div>
			<div class="about-box-layout9 order-xl-1 order-lg-1 col-lg-4">
				<img src="<?= $item['image']; ?>" alt="about" class="img-fluid">
			</div>
		</div>
	</div>
</section>
<!-- About Area End Here -->