<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item) use (&$content){
	
	$content .= '
		<li>
			<a href="' . $item['link'] . '">
				<i class="' . $item['icon'] . '"></i>
				' . $item['title'] . '
			</a>
		</li>
	';
	
});

?>
<ul>
	<?= $content; ?>
</ul>