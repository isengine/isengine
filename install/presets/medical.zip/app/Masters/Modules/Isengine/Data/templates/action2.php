<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item) use (&$content){
	
	$content .= '
		<div class="col-lg-4 col-12">
			<div class="call-to-action-box-layout3">
				<div class="single-item">
					<a href="' . $item['link'] . '"><i class="' . $item['icon'] . '"></i> ' . $item['title'] . '</a>
				</div>
			</div>
		</div>
	';
	
});

?>
<!-- Call to Action Area Start Here -->
<section class="call-to-action-wrap-layout3">
	<div class="container">
		<div class="row">
			<?= $content; ?>
		</div>
	</div>
</section>
<!-- Call to Action Area Start Here -->