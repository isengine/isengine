<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item) use (&$content){
	
	$content .= '
		<div class="single-item col-lg-3 col-md-6 col-12">
			<div class="service-box-layout1">
				<div class="item-icon">
					<i class="' . $item['icon'] . '"></i>
				</div>
				<h4 class="item-title">
					<a href="' . $item['link'] . '">' . $item['title'] . '</a>
				</h4>
				' . $item['description'] . '
			</div>
		</div>
	';
	
});

?>
<!-- Service Area Start Here -->
<section class="service-wrap-layout1 bg-light-primary100">
	<div class="container">
		<div class="row no-gutters service-inner-layout1">
			<?= $content; ?>
		</div>
	</div>
</section>
<!-- Service Area End Here -->