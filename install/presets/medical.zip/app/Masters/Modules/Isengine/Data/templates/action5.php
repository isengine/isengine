<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item) use (&$content){
	
	$content .= '
		<div class="col-md-6 col-12">
			<div class="about-box-layout4">
				<div class="media">
					<div class="item-icon">
						<i class="' . $item['icon'] . '"></i>
					</div>
					<div class="media-body space-md">
						<h3 class="item-title">' . $item['title'] . '</h3>
						<p>' . $item['description'] . '</p>
					</div>
				</div>
			</div>
		</div>
	';
	
});

?>
<?= $content; ?>