<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

$object -> settings = Objects::reverse($object -> settings);
$object -> settings = Objects::get($object -> settings, 0, 3);

$class = ['1st', '2nd', '3rd'];

Objects::each($object -> settings, function($item, $key) use (&$content, $class){
	$data = $item['data'];
	$content .= '
		<div class="blog-col-' . $class[$key] . ' col-xl-4 col-lg-6 col-md-6 col-12">
			<div class="blog-box-layout2">
				<div class="item-img">
					<a href="/single-news/">
						<img src="' . $data['image'] . '" class="img-fluid" alt="blog">
					</a>
				</div>
				<div class="item-content">
					<div class="post-date">' . $item['ctime'] . '</div>
					<h3 class="item-title">
						<a href="/single-news/">' . $data['title'] . '</a>
					</h3>
					' . $data['description'] . '
					<div class="post-actions-wrapper">
						<ul>
							<li>
								<a class="item-btn" href="/single-news/">Read More<i class="fas fa-long-arrow-alt-right"></i></a>
							</li>
							<li>
								<a href="#"><i class="far fa-comments"></i>05</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	';
});

?>
<!-- Blog-Area Start Here -->
<section class="blog-wrap-layout1 bg-accent100">
	<div class="container">
		<div class="section-heading heading-dark text-center heading-layout1">
			<h2>Latest From Blog</h2>
			<p>Modern Hospital Facilities</p>
		</div>
		<div class="row">
			<?= $content; ?>
		</div>
	</div>
</section>
<!-- Blog-Area End Here -->