<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item, $key) use (&$content){
	
	$key = Strings::get(Strings::add($key + 1, 1, 0, true), -2);
	
	$content .= '
		<div class="departments-box-layout2">
			<span class="departments-sl">' . $key . '.</span>
			<div class="item-icon"><i class="' . $item['icon'] . '"></i></div>
			<h3 class="item-title"><a href="' . $item['link'] . '">' . $item['title'] . '</a></h3>
			' . $item['description'] . '
			<a class="item-btn" href="' . $item['link'] . '">' . $item['button'] . '</a>
		</div>
	';
	
});

?>
<div class="rc-carousel nav-control-layout2"
	data-loop="true"
	data-items="4"
	data-margin="20"
	data-autoplay="false"
	data-autoplay-timeout="5000"
	data-custom-nav="#owl-nav1"
	data-smart-speed="2000"
	data-dots="false"
	data-nav="false"
	data-nav-speed="false"
	data-r-x-small="1"
	data-r-x-small-nav="true"
	data-r-x-small-dots="false"
	data-r-x-medium="2"
	data-r-x-medium-nav="false"
	data-r-x-medium-dots="false"
	data-r-small="2"
	data-r-small-nav="false"
	data-r-small-dots="false"
	data-r-medium="3"
	data-r-medium-nav="false"
	data-r-medium-dots="false"
	data-r-large="4"
	data-r-large-nav="false"
	data-r-large-dots="false"
	data-r-extra-large="4"
	data-r-extra-large-nav="false"
	data-r-extra-large-dots="false"
>
	<?= $content; ?>
</div>