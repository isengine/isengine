<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$images = null;
$content = null;


Objects::each($object -> settings, function($item) use (&$images, &$content){
	
	$images .= '
		<div class="nav-item"><i class="' . $item['icon'] . '"></i>' . $item['title'] . '</div>
	';
	
	$content .= '
		<div class="single-item">
			<div class="media media-none--lg">
				<div class="item-img">
					<img src="/img/department/department26.jpg" alt="department" class="img-fluid">
				</div>
				<div class="media-body">
					<h2 class="item-title">' . $item['sub'] . '</h2>
					' . $item['description'] . '
					<a href="' . $item['link'] . '" class="item-btn">' . $item['button'] . '</a>
					<div class="ctg-item-icon"><i class="' . $item['icon'] . '"></i></div>
				</div>
			</div>
		</div>
	';
	
});

?>
<div id="slick-carousel-wrap" class="departments-box-layout3">
	<div class="nav-wrap carousel-nav">
		<?= $images; ?>
	</div>
	<div class="carousel-content">
		<?= $content; ?>
	</div>
</div>