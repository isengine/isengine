<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item) use (&$content){
	
	$content .= '
		<div class="col-lg-3 col-md-6 col-sm-6 col-12">
			<div class="single-box">
				<i class="' . $item['icon'] . '"></i>
				<p>
					<a href="' . $item['link'] . '">' . $item['title'] . '</a>
				</p>
			</div>
		</div>
	';
	
});

?>
<?= $content; ?>