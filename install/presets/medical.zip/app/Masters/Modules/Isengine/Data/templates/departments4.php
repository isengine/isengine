<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item, $key) use (&$content){
	
	$content .= '
		<div class="col-xl-3 col-lg-6 col-md-6 col-12 menu-item' . ($key > 3 ? ' hidden' : null) . '">
			<div class="departments-box-layout1">
				<div class="item-img">
					<img src="' . $item['image'] . '" alt="department" class="img-fluid">
					<div class="item-btn-wrap">
						<a href="' . $item['link'] . '" class="item-btn">' . $item['button'] . '</a>
					</div>
				</div>
				<div class="item-content">
					<h3 class="item-title">
						<a href="' . $item['link'] . '">' . $item['title'] . '</a>
					</h3>
					<ul class="department-info">
						<li>' . $item['description'] . '</li>
					</ul>
				</div>
			</div>
		</div>
	';
	
});

?>
<?= $content; ?>