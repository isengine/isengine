<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

$object -> settings = Objects::reverse($object -> settings);
$object -> settings = Objects::get($object -> settings, 0, 2);

Objects::each($object -> settings, function($item) use (&$content){
	$data = $item['data'];
	$content .= '
		<div class="blog-box-layout1">
			<h3 class="item-title"><a href="/single-news/">' . $data['title'] . '</a></h3>
			<ul class="entry-meta">
				<li><i class="far fa-calendar-alt"></i>' . $item['ctime'] . '</li>
				<li><i class="fas fa-user"></i>Posted by <a href="#">' . $item['owner'] . '</a></li>
			</ul>
		</div>
	';
});

?>
<?= $content; ?>