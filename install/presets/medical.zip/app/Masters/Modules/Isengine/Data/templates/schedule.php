<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$table = &$object -> settings['table'];
$build = &$object -> settings['build'];
$cset = &$object -> settings['content'];

$x_count = $object -> settings['table']['x']['count'];
if ( $object -> settings['table']['y'] ) {
	$x_count++;
}

$y_count = $object -> settings['table']['y']['count'];

$head = null;
$content = null;

$x = 0;
while ($x < $x_count) {
	if ($x > 0) {
		$head .= '
			<td>
				<div class="schedule-day-heading">' . $table['x']['title'][$x] . '</div>
			</td>
		';
	} else {
		$head .= '
			<th>
				<div class="schedule-time-heading">' . $table['x']['title'][$x] . '</div>
			</th>
		';
	}
	$x++;
}

$y = 0;
while ($y < $y_count) {
	$content .= '
		<tr>
			<th scope="row">
				<div class="schedule-time-wrapper">' . $table['y']['title'][$y] . '</div>
			</th>
	';
	
	$x = 0;
	while ($x < $x_count) {
		$content .= '
			<td>
				<div class="schedule-item-wrapper">
		';
		$c = null;
		Objects::each($build[$y][$x], function($item) use (&$c, $cset){
			$item = $cset[$item];
			$c .= '
					<div class="media">
						<div class="item-img">
							<img src="' . $item['image'] . '" alt="team" class="img-fluid rounded-circle">
						</div>
						<div class="media-body">
							<h3 class="title">' . $item['title'] . '</h3>
							<div class="item-ctg">' . $item['sub'] . '</div>
							<a href="/single-details/" class="item-btn btn-fill size-xs radius-4">View Profile</a>
						</div>
					</div>
					<div class="item-ctg">' . $item['sub'] . '</div>
					<div class="item-time">' . $item['time'] . '</div>
					<div class="item-team">' . $item['team'] . '</div>
			';
		});
		$content .= $c . '
				</div>
			</td>
		';
		$x++;
	}
	
	$content .= '
		</tr>
	';
	$y++;
}

?>
<table class="table table-bordered">
	<thead>
		<tr>
			<?= $head; ?>
		</tr>
	</thead>
	<tbody>
		<?= $content; ?>
	</tbody>
</table>