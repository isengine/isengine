<?php

namespace is\Masters\Modules\Isengine\Data;

use is\Helpers\System;
use is\Helpers\Objects;
use is\Helpers\Strings;
use is\Helpers\Prepare;

$content = null;

Objects::each($object -> settings, function($item) use (&$content){
	
	$schedule = null;
	Objects::each($item['schedule'], function($i, $k) use (&$schedule){
		$schedule .= '<li>' . $k . ': <span>' . $i . '</span></li>';
	});
	
	$content .= '
		<div class="col-xl-4 col-lg-6 col-md-6 col-12">
			<div class="team-box-layout3">
				<div class="item-content">
					<div class="title-bar">
						<h3 class="item-title">
							<a href="/single-doctor/">' . $item['name'] . '</a>
						</h3>
						<p>' . $item['sub'] . '</p>
					</div>
					<div class="item-schedule">
						<ul>' . $schedule . '</ul>
						<a href="/single-doctor/" class="item-btn">Book an Appointment</a>
					</div>
				</div>
				<div class="item-img">
					<img src="' . $item['image'] . '" alt="team" class="img-fluid">
				</div>
			</div>
		</div>
	';
});

?>
<!-- Team Area Start Here -->
<section class="team-wrap-layout4 bg-light-secondary100">
	<div class="container">
		<div class="section-heading heading-dark text-center heading-layout1">
			<h2>Specialist Doctors</h2>
			<p>Experienced Doctor</p>
		</div>
		<div class="row gutters-15">
			<?= $content; ?>
		</div>
	</div>
</section>
<!-- Team Area End Here -->