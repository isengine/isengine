<!-- Brand Area Start Here -->
<section class="brand-wrap-layout1 bg-primary100">
	<div class="container">
		<div class="row">
			<div class="brand-box-layout1 col-xl-7 col-lg-6 col-md-12 col-12">
				<h2 class="item-title">We Are Certified Award Winning Hospital.</h2>
			</div>
			<div class="brand-box-layout2 col-xl-5 col-lg-6 col-md-12 col-12">
				<img src="/img/award/award-bg.png" alt="brand" class="img-fluid d-none d-lg-block">
				<ul>
					<li>
						<img src="/img/award/award1.png" alt="brand" class="img-fluid">
					</li>
					<li>
						<img src="/img/award/award2.png" alt="brand" class="img-fluid">
					</li>
					<li>
						<img src="/img/award/award3.png" alt="brand" class="img-fluid">
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- Brand Area End Here -->