<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Banner Area Start Here -->
<section class="banner-wrap-layout1 parallaxie" data-bg-image="/img/figure/figure6.jpg">
	<div class="container">
		<div class="row">
			<div class="col-xl-5 col-lg-8 col-md-10 col-12">
				<div class="banner-box-layout1">
					<h2 class="item-title">For Emergency Cases</h2>
					<h3 class="phone-number"><?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-white}'); ?></h3>
					<p>Building a healthy environment that supports development for the community. Your personal case manager will ensure that you receive the best possible care.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Banner End Here -->