<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Blog and Testimonial Area Start Here -->
<section class="both-side-half-bg">
	
	<div class="single-item">
		<div class="section-heading heading-dark heading-layout5">
			<h2>Our Latest News</h2>
		</div>
		<?php $view -> get('module') -> launch('data', 'news'); ?>
		<a class="blog-btn" href="news1.html">SEE ALL NEWS<i class="fas fa-chevron-right"></i></a>
	</div>
	
	<div class="single-item bg-common" data-bg-image="/img/figure/figure9.png">
		<div class="section-heading heading-light heading-layout5">
			<h2>Testimonials</h2>
			<div id="owl-nav3" class="owl-nav-layout2">
				<span class="rt-prev">
					<i class="fas fa-chevron-left"></i>
				</span>
				<span class="rt-next">
					<i class="fas fa-chevron-right"></i>
				</span>
			</div>
		</div>
		<?php $view -> get('module') -> launch('data', 'testimonials2'); ?>
	</div>

</section>
<!-- Blog and Testimonial Area End Here -->