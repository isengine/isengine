<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Call to Action Area Start Here -->
<section class="call-to-action-wrap-layout4">
	<div class="item-img">
		<img src="/img/figure/figure7.png" alt="figure" class="img-fluid">
	</div>
	<div class="container">
		<div class="row">
			<div class="col-xl-12 col-lg-8 col-md-8 col-12">
				<div class="call-to-action-box-layout4">
					<h2 class="item-title">We Provide the highest level of satisfaction care &amp; services to our patients.</h2>
					<div class="call-to-action-phone">
						<?= $view -> get('tvars') -> launch('{phone|<i class="fas fa-phone"></i>{lang|information:phone:0}}'); ?>
					</div>
					<div class="call-to-action-btn">
						<a href="<?= $view -> get('lang|this:calltoaction:link'); ?>" class="item-btn"><?= $view -> get('lang|this:calltoaction:title'); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Call to Action End Here -->