<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Departments Area Start Here -->
<section class="departments-wrap-layout2 bg-light-secondary100">
	<img class="left-img img-fluid" src="/img/figure/figure8.png" alt="figure">
	<div class="container">
		<div class="section-heading heading-dark text-left heading-layout1">
			<h2>Our Departments</h2>
			<p>Dedicated Services</p>
			<div id="owl-nav1" class="owl-nav-layout1">
				<span class="rt-prev">
					<i class="fas fa-chevron-left"></i>
				</span>
				<span class="rt-next">
					<i class="fas fa-chevron-right"></i>
				</span>
			</div>
		</div>
		<?php $view -> get('module') -> launch('data', 'departments1'); ?>
	</div>
</section>
<!-- Departments Area End Here -->