<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Department Area Start Here -->
<section class="departments-wrap-layout3 bg-accent100 bg-common" data-bg-image="/img/figure/figure10.png">
	<div class="container">
		<div class="section-heading heading-dark text-center heading-layout1">
			<h2>Our Departments</h2>
			<p>Dedicated Services</p>
		</div>
		<?php $view -> get('module') -> launch('data', 'departments2'); ?>
	</div>
</section>
<!-- Department Area End Here -->