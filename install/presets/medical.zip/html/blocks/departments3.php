<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Department Area Start Here -->
<section class="departments-wrap-layout6 bg-light-secondary100">
	<div class="container">
		<div class="row">
			<div class="departments-box-layout6 col-xl-4 d-none d-xl-block">
				<div class="item-img">
					<img src="/img/department/department5.png" alt="department" class="img-fluid">
				</div>
			</div>
			<div class="col-xl-8 col-12">
				<div class="departments-box-layout7">
					<div class="section-title">
						<h2 class="title">Our Departments</h2>
						<div class="sub-title">Dedicated Services</div>
					</div>
					<div class="row gutters-5">
						<?php $view -> get('module') -> launch('data', 'departments3'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Department Area End Here -->