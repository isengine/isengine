<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Departments Area Start Here -->
<section class="departments-wrap-layout7 bg-light-secondary100">
	<div class="container menu-list-wrapper">
		<div class="section-heading heading-dark text-center heading-layout1">
			<h2>Our Departments</h2>
			<p>Dedicated Services</p>
		</div>
		<div class="row menu-list">
			<?php $view -> get('module') -> launch('data', 'departments4'); ?>
		</div>
		<div class="loadmore loadmore-layout1 margin-t-20" data-count="4">
			<a href="#" class="item-btn">More Departments</a>
		</div>
	</div>
</section>
<!-- Departments Area End Here -->