<section class="features-wrap-layout1">
	<div class="features-box-layout1 d-lg-flex bg-light-primary100">
		<div class="item-inner-wrapper">
			<div class="item-content d-flex align-items-center">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-12">
							<div class="item-content-inner content-dark">
								<h2 class="item-title">Choose the best for your health</h2>
								<p>Dwisi enim ad minim veniam, quis laore nostrud exerci tation ulm hedi corper
									turet suscipit lobortis.</p>
								<ul class="list-item">
									<li>Free Consultation</li>
									<li>Quality Doctors</li>
									<li>Professional Experts</li>
									<li>Affordable Price</li>
									<li>24/7 Opened</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="item-inner-wrapper">
			<img src="/img/figure/figure8.jpg" class="img-responsive" alt="figure">
		</div>
	</div>
</section>