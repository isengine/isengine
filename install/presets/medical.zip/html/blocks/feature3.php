<section class="features-wrap-layout1">
	<div class="features-box-layout2 d-lg-flex">
		<div class="item-img">
			<img src="/img/figure/figure9.jpg" class="img-responsive" alt="figure">
		</div>
		<div class="item-content d-flex align-items-center">
			<div class="container">
				<div class="row justify-content-end">
					<div class="col-lg-6 col-sm-12 col-12">
						<div class="item-content-inner inner-title-dark">
							<h2 class="item-title">We are the trusted experts things simple</h2>
							<p>Dwisi enim ad minim veniam, quis laore nostrud exerci tation area ulm hedi
								corper turet suscipit lobortis nisl ut aliquip erat volutpat autem vel eum
								iriure dolor in hendrerit in vulputate.
							</p>
							<div class="skill-layout1">
								<div class="progress">
									<div class="lead">Efficency</div>
									<div style="width: 80%; visibility: visible; animation-duration: 1.5s; animation-delay: 0.1s;"
										data-progress="95%" class="progress-bar progress-bar-striped wow fadeInLeft animated">
										<span>80%</span>
									</div>
								</div>
								<div class="progress">
									<div class="lead">Experience</div>
									<div style="width: 95%; visibility: visible; animation-duration: 1.5s; animation-delay: 0.2s;"
										data-progress="85%" class="progress-bar progress-bar-striped wow fadeInLeft animated">
										<span>95%</span>
									</div>
								</div>
								<div class="progress">
									<div class="lead">Experience</div>
									<div style="width: 75%; visibility: visible; animation-duration: 1.5s; animation-delay: 0.3s;"
										data-progress="99%" class="progress-bar progress-bar-striped wow fadeInLeft animated">
										<span>75%</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>