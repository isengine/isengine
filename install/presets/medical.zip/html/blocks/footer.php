<?php

namespace is;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Footer Area Start Here -->
<footer>
	<section class="footer-top-wrap">
		<div class="container">
			<div class="row">
				<div class="single-item col-lg-3 col-md-6 col-12">
					<div class="footer-box">
						<div class="footer-logo">
							<a href="/"><img src="/img/logo-light.png" class="img-fluid" alt="<?= $view -> get('lang|title'); ?> footer logo"></a>
						</div>
						<div class="footer-about">
							<p><?= $view -> get('lang|description'); ?>.</p>
						</div>
						<div class="footer-contact-info">
							<ul>
								<li><i class="fas fa-map-marker-alt"></i><?= $view -> get('lang|information:address'); ?></li>
								<li><i class="fas fa-phone"></i><?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}}'); ?></li>
								<li><i class="far fa-envelope"></i>
								<?= $view -> get('tvars') -> launch('{mail|{lang|information:email:0}}'); ?>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="single-item col-lg-3 col-md-6 col-12">
					<div class="footer-box">
						<div class="footer-header">
							<h3>Departments</h3>
						</div>
						<div class="footer-departments">
							<ul>
								<li><a href="/single-departments/">Dental Care</a></li>
								<li><a href="/single-departments/">Medicine</a></li>
								<li><a href="/single-departments/">Orthopedic</a></li>
								<li><a href="/single-departments/">Emergency</a></li>
								<li><a href="/single-departments/">Skilled Doctors</a></li>
								<li><a href="/single-departments/">Certified Clinic</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="single-item col-lg-3 col-md-6 col-12">
					<div class="footer-box">
						<div class="footer-header">
							<h3>Quick Links</h3>
						</div>
						<div class="footer-quick-link">
							<ul>
								<li><a href="/about/">About Us</a></li>
								<li><a href="/about/">What We Do</a></li>
								<li><a href="/faq/">Faq</a></li>
								<li><a href="/appointment/">Appointment</a></li>
								<li><a href="/contact/">Contact</a></li>
								<li><a href="/contact/">24/7 Support</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="single-item col-lg-3 col-md-6 col-12">
					<div class="footer-box">
						<div class="footer-header">
							<h3><?= $view -> get('lang|common:work', 'upperEach'); ?></h3>
						</div>
						<div class="footer-opening-hours">
							<ul>
								<?php
									Objects::each($view -> get('lang|information:work'), function($item){
								?>
								<li><?= $item; ?></li>
								<?php
									});
								?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="footer-center-wrap">
		<div class="container">
			<div class="row no-gutters">
				<div class="col-lg-4 col-12">
					<div class="footer-social">
						<ul>
							<li><?= $view -> get('lang|common:follow', 'upperFirst'); ?></li>
							<?php $view -> get('layout') -> launch('blocks', 'sub:social'); ?>
						</ul>
					</div>
				</div>
				<div class="col-lg-8 col-12">
					<div class="row">
						<div class="col-md-6 col-12">
							<div class="newsletter-title">
								<h4 class="item-title">Stay informed and healthy</h4>
							</div>
						</div>
						<div class="col-md-6 col-12">
							<div class="newsletter-form">
								<div class="input-group stylish-input-group">
									<input type="text" class="form-control" placeholder="Enter your e-mail">
									<span class="input-group-addon">
										<button type="submit">
											<span aria-hidden="true">SIGN UP!</span>
										</button>
									</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php $view -> get('layout') -> launch('blocks', 'sub:copyright'); ?>
</footer>
<!-- Footer Area End Here -->