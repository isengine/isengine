<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Header Area Start Here -->
<header id="header_1">
	<div class="header-top-bar top-bar-border-bottom bg-light-primary100 d-none d-md-block">
		<div class="container">
			<div class="row">
				<div class="col-xl-8 col-lg-12 col-md-12 col-12 header-contact-layout1">
					<ul>
						<li>
							<i class="fas fa-phone"></i>
							<?= $view -> get('lang|common:call', 'upperFirst') . ': '; ?>
							<?= $view -> get('tvars') -> launch('{phone|{lang|information:phone:0}:text-dark}'); ?>
						</li>
						<li><i class="fas fa-map-marker-alt"></i><?= $view -> get('lang|information:address'); ?></li>
						<li><i class="far fa-clock"></i><?= $view -> get('lang|information:work:0'); ?></li>
					</ul>
				</div>
				<div class="col-xl-4 d-none d-xl-block">
					<ul class="header-social-layout1">
						<?php $view -> get('layout') -> launch('blocks', 'sub:social'); ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="header-menu-area header-menu-layout1">
		<div class="container">
			<div class="row no-gutters d-flex align-items-center">
				<div class="col-lg-2 col-md-2 logo-area-layout1">
					<?php $view -> get('layout') -> launch('blocks', 'sub:top-logo'); ?>
				</div>
				<div class="col-lg-7 col-md-7 position-static">
					<div class="template-main-menu">
						<?php $view -> get('layout') -> launch('blocks', 'sub:nav'); ?>
					</div>
				</div>
				<div class="col-lg-3 col-md-3">
					<div class="header-action-items-layout1">
						<ul>
							<li class="d-none d-xl-block">
								<?php $view -> get('layout') -> launch('blocks', 'sub:search'); ?>
							</li>
							<li>
								<a href="<?= $view -> get('lang|this:calltoaction:link'); ?>" class="action-items-primary-btn"><?= $view -> get('lang|this:calltoaction:title'); ?><i class="fas fa-chevron-right"></i></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<!-- Header Area End Here -->