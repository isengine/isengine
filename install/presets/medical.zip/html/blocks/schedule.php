<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<!-- Schedule Area Start Here -->
<section class="class-schedule1">
	<div class="container">
		<div class="section-heading heading-dark text-center heading-layout1">
			<h2>Specialist Doctors</h2>
			<p>Experienced Doctor</p>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="class-schedule-wrap1">
					<div class="table-responsive">
						<?php $view -> get('module') -> launch('data', 'schedule'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Schedule Area End Here -->