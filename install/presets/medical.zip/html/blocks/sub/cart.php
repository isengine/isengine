<a class="cart-trigger-icon" href="#">
	<i class="flaticon-shopping-cart"></i>
	<span>2</span>
</a>
<div class="cart-items">
	<div class="cart-item">
		<div class="cart-img">
			<a href="#">
				<img src="img/shop/cart1.png" alt="product" class="img-fluid">
			</a>
		</div>
		<div class="cart-title">
			<a href="#">Pressure</a>
			<span>Code: STPT601</span>
		</div>
		<div class="cart-quantity">X 1</div>
		<div class="cart-price">$249</div>
		<div class="cart-trash">
			<a href="#">
				<i class="far fa-trash-alt"></i>
			</a>
		</div>
	</div>
	<div class="cart-item">
		<div class="cart-img">
			<a href="#">
				<img src="img/shop/cart2.png" alt="product" class="img-fluid">
			</a>
		</div>
		<div class="cart-title">
			<a href="#">Stethoscope</a>
			<span>Code: STPT602</span>
		</div>
		<div class="cart-quantity">X 1</div>
		<div class="cart-price">$189</div>
		<div class="cart-trash">
			<a href="#">
				<i class="far fa-trash-alt"></i>
			</a>
		</div>
	</div>
	<div class="cart-item">
		<div class="cart-img">
			<a href="#">
				<img src="img/shop/cart3.png" alt="product" class="img-fluid">
			</a>
		</div>
		<div class="cart-title">
			<a href="#">Microscope</a>
			<span>Code: STPT603</span>
		</div>
		<div class="cart-quantity">X 2</div>
		<div class="cart-price">$379</div>
		<div class="cart-trash">
			<a href="#">
				<i class="far fa-trash-alt"></i>
			</a>
		</div>
	</div>
	<div class="cart-item">
		<div class="cart-btn">
			<a href="#" class="item-btn">View Cart</a>
			<a href="#" class="item-btn">Checkout</a>
		</div>
	</div>
</div>