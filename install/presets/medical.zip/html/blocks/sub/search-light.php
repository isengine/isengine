<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

?>
<form id="top-search-form" class="header-search-light">
	<input type="text" class="search-input" placeholder="<?= $view -> get('lang|common:search', 'upperFirst'); ?>..." required="">
	<button class="search-button">
		<i class="flaticon-search"></i>
	</button>
</form>