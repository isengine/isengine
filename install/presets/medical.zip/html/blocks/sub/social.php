<?php

namespace is;
use is\Helpers\Objects;
use is\Masters\View;

$view = View::getInstance();

Objects::each($view -> get('lang|social'), function($item){
?>
<li><a href="<?= $item['url']; ?>" alt="<?= $item['name']; ?>" title="<?= $item['name']; ?>"><i class="<?= $item['class']; ?>"></i></a></li>
<?php
});
?>