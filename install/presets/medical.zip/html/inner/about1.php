	<!-- Inne Page Banner Area Start Here -->
	<section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="/img/figure/figure2.jpg">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumbs-area">
						<h1>About Us</h1>
						<ul>
							<li>
								<a href="index.html">Home</a>
							</li>
							<li>About</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Inne Page Banner Area End Here -->
	<!-- About Area Start Here -->
	<section class="about-wrap-layout3">
		<div class="container">
			<div class="row" id="no-equal-gallery">
				<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12 no-equal-item">
					<div class="widget widget-about-info">
						<ul class="nav nav-tabs tab-nav-list">
							<li class="nav-item">
								<a class="active" href="#related1" data-toggle="tab" aria-expanded="false">Who We
									Are</a>
							</li>
							<li class="nav-item">
								<a href="#related2" data-toggle="tab" aria-expanded="false">Our Mission</a>
							</li>
							<li class="nav-item">
								<a href="#related3" data-toggle="tab" aria-expanded="false">Experience</a>
							</li>
							<li class="nav-item">
								<a href="#related4" data-toggle="tab" aria-expanded="false">Awards</a>
							</li>
							<li class="nav-item">
								<a href="#related5" data-toggle="tab" aria-expanded="false">Success Story</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-xl-9 col-lg-8 no-equal-item">
					<div class="tab-content">
						<div class="tab-pane fade active show" id="related1">
							<div class="about-box-layout5">
								<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque.</p>
								<div class="row about-img">
									<div class="col-md-6 col-12">
										<img src="/img/about/about5.jpg" alt="about">
									</div>
									<div class="col-md-6 col-12">
										<img src="/img/about/about6.jpg" alt="about">
										<div class="item-btn">
											<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
												<i class="flaticon-play-button"></i>
											</a>
										</div>
									</div>
								</div>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
									et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
								<ul class="about-info">
									<li>Keep Patients First</li>
									<li>Pursue Excellence</li>
									<li>Keep Everyone Safe</li>
									<li>Manage Your Resources</li>
									<li>Work Together</li>
									<li>Keep Learning</li>
								</ul>
								<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
									perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
									adipiscing. Aliquam class bibendum mattis fusceut persecenas.
									Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
									mus. Hymenaeos eros.</p>
							</div>
						</div>
						<div class="tab-pane fade" id="related2">
							<div class="about-box-layout5">
								<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque.</p>
								<div class="row about-img">
									<div class="col-md-6 col-12">
										<img src="/img/about/about5.jpg" alt="about">
									</div>
									<div class="col-md-6 col-12">
										<img src="/img/about/about6.jpg" alt="about">
										<div class="item-btn">
											<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
												<i class="flaticon-play-button"></i>
											</a>
										</div>
									</div>
								</div>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
									et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
								<ul class="about-info">
									<li>Keep Patients First</li>
									<li>Pursue Excellence</li>
									<li>Keep Everyone Safe</li>
									<li>Manage Your Resources</li>
									<li>Work Together</li>
									<li>Keep Learning</li>
								</ul>
								<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
									perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
									adipiscing. Aliquam class bibendum mattis fusceut persecenas.
									Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
									mus. Hymenaeos eros.</p>
							</div>
						</div>
						<div class="tab-pane fade" id="related3">
							<div class="about-box-layout5">
								<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque.</p>
								<div class="row about-img">
									<div class="col-md-6 col-12">
										<img src="/img/about/about5.jpg" alt="about">
									</div>
									<div class="col-md-6 col-12">
										<img src="/img/about/about6.jpg" alt="about">
										<div class="item-btn">
											<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
												<i class="flaticon-play-button"></i>
											</a>
										</div>
									</div>
								</div>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
									et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
								<ul class="about-info">
									<li>Keep Patients First</li>
									<li>Pursue Excellence</li>
									<li>Keep Everyone Safe</li>
									<li>Manage Your Resources</li>
									<li>Work Together</li>
									<li>Keep Learning</li>
								</ul>
								<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
									perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
									adipiscing. Aliquam class bibendum mattis fusceut persecenas.
									Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
									mus. Hymenaeos eros.</p>
							</div>
						</div>
						<div class="tab-pane fade" id="related4">
							<div class="about-box-layout5">
								<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque.</p>
								<div class="row about-img">
									<div class="col-md-6 col-12">
										<img src="/img/about/about5.jpg" alt="about">
									</div>
									<div class="col-md-6 col-12">
										<img src="/img/about/about6.jpg" alt="about">
										<div class="item-btn">
											<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
												<i class="flaticon-play-button"></i>
											</a>
										</div>
									</div>
								</div>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
									et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
								<ul class="about-info">
									<li>Keep Patients First</li>
									<li>Pursue Excellence</li>
									<li>Keep Everyone Safe</li>
									<li>Manage Your Resources</li>
									<li>Work Together</li>
									<li>Keep Learning</li>
								</ul>
								<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
									perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
									adipiscing. Aliquam class bibendum mattis fusceut persecenas.
									Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
									mus. Hymenaeos eros.</p>
							</div>
						</div>
						<div class="tab-pane fade" id="related5">
							<div class="about-box-layout5">
								<h2 class="item-title">Let’s Know Short Story About Medilink Centeral Hospital.</h2>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque.</p>
								<div class="row about-img">
									<div class="col-md-6 col-12">
										<img src="/img/about/about5.jpg" alt="about">
									</div>
									<div class="col-md-6 col-12">
										<img src="/img/about/about6.jpg" alt="about">
										<div class="item-btn">
											<a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=1iIZeIy7TqM">
												<i class="flaticon-play-button"></i>
											</a>
										</div>
									</div>
								</div>
								<p>Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Maecenas. Eros mus.
									Hymenaeos eros. Nisi mauris et adipiscing. Aliquam class bibendum
									mattis fusceut persecenas. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi
									mauris et adipisc iquam class bibendum non mattis fusceut perspiciatis
									undeuisque. Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris
									et adipisc iquam class bibendum non mattis fusceut perspiciatise.</p>
								<ul class="about-info">
									<li>Keep Patients First</li>
									<li>Pursue Excellence</li>
									<li>Keep Everyone Safe</li>
									<li>Manage Your Resources</li>
									<li>Work Together</li>
									<li>Keep Learning</li>
								</ul>
								<p>Hymenaeos eros. Nisi mauris et adipisc iquam class bibendum non mattis fusceut
									perspiciatis undeuisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et
									adipiscing. Aliquam class bibendum mattis fusceut persecenas.
									Quisque. Maecenas. Eros mus. Hymenaeos eros. Nisi mauris et adipisc iquam class
									bibendum non mattis fusceut perspiciatis undeuisque. Quisque. Maecenas. Eros
									mus. Hymenaeos eros.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12 no-equal-item">
					<div class="widget widget-call-to-action-light">
						<div class="media">
							<img src="/img/figure/figure6.png" alt="figure">
							<div class="media-body space-sm">
								<h4>Emergency Cases</h4>
								<span>2-800-700-6200</span>
							</div>
						</div>
					</div>
					<div class="widget widget-ad-area">
						<div class="ad-wrap">
							<img src="/img/figure/figure5.jpg" alt="Figure">
							<div class="item-btn-wrap">
								<a class="item-btn" href="#">SEE DETAILS<i class="fas fa-chevron-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- About Area Start Here -->
	<!-- Team Area Start Here -->
	<section class="team-wrap-layout1 bg-light-secondary100">
		<img class="left-img img-fluid" src="/img/figure/figure4.png" alt="figure">
		<img class="right-img img-fluid" src="/img/figure/figure5.png" alt="figure">
		<div class="container">
			<div class="section-heading heading-dark text-left heading-layout1">
				<h2>Specialist Doctors</h2>
				<p>Experienced Doctor</p>
				<div id="owl-nav1" class="owl-nav-layout1">
					<span class="rt-prev">
						<i class="fas fa-chevron-left"></i>
					</span>
					<span class="rt-next">
						<i class="fas fa-chevron-right"></i>
					</span>
				</div>
			</div>
			<div class="rc-carousel nav-control-layout2" data-loop="true" data-items="4" data-margin="30"
				data-autoplay="false" data-autoplay-timeout="5000" data-custom-nav="#owl-nav1" data-smart-speed="2000"
				data-dots="false" data-nav="false" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true"
				data-r-x-small-dots="false" data-r-x-medium="2" data-r-x-medium-nav="false" data-r-x-medium-dots="false"
				data-r-small="2" data-r-small-nav="false" data-r-small-dots="false" data-r-medium="3"
				data-r-medium-nav="false" data-r-medium-dots="false" data-r-large="3" data-r-large-nav="false"
				data-r-large-dots="false" data-r-extra-large="4" data-r-extra-large-nav="false"
				data-r-extra-large-dots="false">
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team33.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Zinia Zara</a>
						</h3>
						<p>Gynaecology</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team34.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Nadim Kamal</a>
						</h3>
						<p>Orthopaedics</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team35.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Rihana Roy</a>
						</h3>
						<p>Lense Expert</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team36.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Steven Roy</a>
						</h3>
						<p>Cardiology</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Team Area End Here -->
	<!-- Brand Area Start Here -->
	<section class="brand-wrap-layout1 bg-primary100">
		<div class="container">
			<div class="row">
				<div class="brand-box-layout1 col-xl-7 col-lg-6 col-md-12 col-12">
					<h2 class="item-title">We Are Certified Award Winning Hospital.</h2>
				</div>
				<div class="brand-box-layout2 col-xl-5 col-lg-6 col-md-12 col-12">
					<img src="/img/brand/brand-bg1.png" alt="brand" class="img-fluid d-none d-lg-block">
					<ul>
						<li>
							<img src="/img/brand/brand1.png" alt="brand" class="img-fluid">
						</li>
						<li>
							<img src="/img/brand/brand2.png" alt="brand" class="img-fluid">
						</li>
						<li>
							<img src="/img/brand/brand3.png" alt="brand" class="img-fluid">
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<!-- Brand Area End Here -->