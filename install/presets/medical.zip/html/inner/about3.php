	<!-- Inne Page Banner Area Start Here -->
	<section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="/img/figure/figure2.jpg">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumbs-area">
						<h1>About Us</h1>
						<ul>
							<li>
								<a href="index.html">Home</a>
							</li>
							<li>About 3</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Inne Page Banner Area End Here -->
	<!-- About Area Start Here -->
	<section class="about-wrap-layout4">
		<div class="container">
			<div id="slick-carousel-wrap2" class="row about-box-layout10">
				<div class="col-lg-6 col-md-5 about-img carousel-nav">
					<div class="nav-item"><img src="/img/about/about3.jpg" alt="brand" class="img-fluid"></div>
					<div class="nav-item"><img src="/img/about/about4.jpg" alt="brand" class="img-fluid"></div>
					<div class="nav-item"><img src="/img/about/about3.jpg" alt="brand" class="img-fluid"></div>
					<div class="nav-item"><img src="/img/about/about4.jpg" alt="brand" class="img-fluid"></div>
				</div>
				<div class="col-lg-6 col-md-7 carousel-content about-content">
					<div class="single-item">
						<h2 class="item-title">Laboratory Place
							<span>In Medicine Practice</span>
						</h2>
						<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
							ulm hedi corper turet.</p>
						<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
					</div>
					<div class="single-item">
						<h2 class="item-title">Laboratory Place
							<span>In Medicine Practice</span>
						</h2>
						<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
							ulm hedi corper turet.</p>
						<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
					</div>
					<div class="single-item">
						<h2 class="item-title">Laboratory Place
							<span>In Medicine Practice</span>
						</h2>
						<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
							ulm hedi corper turet.</p>
						<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
					</div>
					<div class="single-item">
						<h2 class="item-title">Laboratory Place
							<span>In Medicine Practice</span>
						</h2>
						<p class="sub-title">Ut wisi enim ad minim veniam, quis laore nostrud exerci tation
							ulm hedi corper turet.</p>
						<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam harum atque voluptatibus quasi quisquam cupiditate magnam quidem, sapiente, impedit similique et aliquam amet hic? Ad dolorem cum aliquam quas dolores? Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- About Area End Here -->
	<!-- About Area Start Here -->
	<section class="bg-light-secondary100">
		<div class="container">
			<div class="row">
				<div class="about-box-layout11 col-lg-7 col-12">
					<h2 class="item-title">We Here To Care
						<span>About Health</span>
					</h2>
					<div class="sub-title">Hospital imply dummy text of the printing and type setng industry been the industry.</div>
					<p>Mtandard dummy texr since when an unknown printer took a galley.MediPoint Lorem ipsum dolor sit amet,
						consetetur sadipscing elitr, At accusam aliquyam.'s standard dummy texr since when an unknown
						printer took a galley consetetur. Moimply dummy text of the printing and type settingaindustry. Lorem Ipsum has
						been the industry’s standard dummy text ever since thelong established fact thaaret</p>
					<img src="/img/about/sign1.png" alt="sign" class="img-fluid">
				</div>
				<div class="about-box-layout12 col-lg-5 col-12">
					<img src="/img/about/about4.png" alt="about" class="img-fluid">
				</div>
			</div>
		</div>
	</section>
	<!-- About Area End Here -->
	<!-- Progress Area Start Here -->
	<section class="progress-wrap-layout2 bg-overlay bg-overlay-primary80 bg-common parallaxie" data-bg-image="/img/figure/figure1.jpg">
		<div class="container">
			<div class="row">
				<div class="progress-box-layout2 col-md-4">
					<div class="inner-item">
						<div class="counting-text counter" data-num="59">59</div>
						<p>Health Sections</p>
					</div>
				</div>
				<div class="progress-box-layout2 col-md-4">
					<div class="inner-item">
						<div class="counting-text counter" data-num="4709">4709</div>
						<p>Happy Patients</p>
					</div>
				</div>
				<div class="progress-box-layout2 col-md-4">
					<div class="inner-item">
						<div class="counting-text counter" data-num="128">128</div>
						<p>Quality Doctors</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Progress Area End Here -->
	<!-- Team Area Start Here -->
	<section class="team-wrap-layout1 bg-light-secondary100">
		<img class="left-img img-fluid" src="/img/figure/figure4.png" alt="figure">
		<img class="right-img img-fluid" src="/img/figure/figure5.png" alt="figure">
		<div class="container">
			<div class="section-heading heading-dark text-left heading-layout1">
				<h2>Specialist Doctors</h2>
				<p>Experienced Doctor</p>
				<div id="owl-nav2" class="owl-nav-layout1">
					<span class="rt-prev">
						<i class="fas fa-chevron-left"></i>
					</span>
					<span class="rt-next">
						<i class="fas fa-chevron-right"></i>
					</span>
				</div>
			</div>
			<div class="rc-carousel nav-control-layout2" data-loop="true" data-items="4" data-margin="30"
				data-autoplay="false" data-autoplay-timeout="5000" data-custom-nav="#owl-nav2" data-smart-speed="2000"
				data-dots="false" data-nav="false" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true"
				data-r-x-small-dots="false" data-r-x-medium="2" data-r-x-medium-nav="false" data-r-x-medium-dots="false"
				data-r-small="2" data-r-small-nav="false" data-r-small-dots="false" data-r-medium="3"
				data-r-medium-nav="false" data-r-medium-dots="false" data-r-large="3" data-r-large-nav="false"
				data-r-large-dots="false" data-r-extra-large="4" data-r-extra-large-nav="false"
				data-r-extra-large-dots="false">
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team33.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Zinia Zara</a>
						</h3>
						<p>Gynaecology</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team34.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Nadim Kamal</a>
						</h3>
						<p>Orthopaedics</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team35.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Rihana Roy</a>
						</h3>
						<p>Lense Expert</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
				<div class="team-box-layout2">
					<div class="item-img">
						<img src="/img/team/team36.png" alt="Team1" class="img-fluid rounded-circle">
						<ul class="item-icon">
							<li>
								<a href="single-doctor.html">
									<i class="fas fa-plus"></i>
								</a>
							</li>
						</ul>
					</div>
					<div class="item-content">
						<h3 class="item-title">
							<a href="single-doctor.html">Dr. Steven Roy</a>
						</h3>
						<p>Cardiology</p>
					</div>
					<div class="item-schedule">
						<ul>
							<li>Mon - Tues
								<span>08.00 :17.00</span>
							</li>
							<li>Fri - Sat
								<span>09.00 :12.00</span>
							</li>
							<li>Sun - Mon
								<span>08.00 :17.00</span>
							</li>
						</ul>
						<a href="single-doctor.html" class="item-btn">MAKE AN APPOINTMENT</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Team Area End Here -->
	<!-- Testimonial Area Start Here -->
	<section class="testmonial-wrap-layout2 bg-common" data-bg-image="/img/testimonial/testimonial-bg1.jpg">
		<div class="container">
			<div class="rc-carousel dot-control-layout2" data-loop="true" data-items="1" data-margin="30" data-autoplay="true" data-autoplay-timeout="5000"
				data-smart-speed="2000" data-dots="true" data-nav="false" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="false"
				data-r-x-small-dots="true" data-r-x-medium="1" data-r-x-medium-nav="false" data-r-x-medium-dots="true" data-r-small="1"
				data-r-small-nav="false" data-r-small-dots="true" data-r-medium="1" data-r-medium-nav="false" data-r-medium-dots="true"
				data-r-large="1" data-r-large-nav="false" data-r-large-dots="true" data-r-extra-large="1" data-r-extra-large-nav="false"
				data-r-extra-large-dots="true">
				<div class="testmonial-box-layout3">
					<div class="item-img">
						<img src="/img/testimonial/testimonial3.jpg" class="img-fulid rounded-circle" alt="Robert Addison">
					</div>
					<div class="item-content">
						<p>Rimply dummy text of the printing and tRimply dummy text of the printing and typesetting industry.
							psum has been the industry.</p>
						<h3 class="item-title">Robert Adison</h3>
						<h4 class="sub-title">Professor</h4>
					</div>
				</div>
				<div class="testmonial-box-layout3">
					<div class="item-img">
						<img src="/img/testimonial/testimonial3.jpg" class="img-fulid rounded-circle bg-common" alt="Robert Addison">
					</div>
					<div class="item-content">
						<p>Rimply dummy text of the printing and tRimply dummy text of the printing and typesetting industry.
							psum has been the industry.</p>
						<h3 class="item-title">Robert Adison</h3>
						<h4 class="sub-title">Professor</h4>
					</div>
				</div>
				<div class="testmonial-box-layout3">
					<div class="item-img">
						<img src="/img/testimonial/testimonial3.jpg" class="img-fulid rounded-circle bg-common" alt="Robert Addison">
					</div>
					<div class="item-content">
						<p>Rimply dummy text of the printing and tRimply dummy text of the printing and typesetting industry.
							psum has been the industry.</p>
						<h3 class="item-title">Robert Adison</h3>
						<h4 class="sub-title">Professor</h4>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Testimonial Area End Here -->
	<!-- Brand Area Start Here -->
	<section class="brand-wrap-layout2 bg-light-primary100">
		<div class="container">
			<div class="rc-carousel nav-control-layout4" data-loop="true" data-items="5" data-margin="30"
				data-autoplay="false" data-autoplay-timeout="5000" data-smart-speed="2000" data-dots="false"
				data-nav="true" data-nav-speed="false" data-r-x-small="2" data-r-x-small-nav="true"
				data-r-x-small-dots="false" data-r-x-medium="2" data-r-x-medium-nav="true" data-r-x-medium-dots="false"
				data-r-small="3" data-r-small-nav="true" data-r-small-dots="false" data-r-medium="5"
				data-r-medium-nav="true" data-r-medium-dots="false" data-r-large="5" data-r-large-nav="true"
				data-r-large-dots="false" data-r-extra-large="5" data-r-extra-large-nav="true"
				data-r-extra-large-dots="false">
				<div class="brand-box-layout3">
					<img src="/img/brand/brand4.png" alt="brand" class="img-fluid">
				</div>
				<div class="brand-box-layout3">
					<img src="/img/brand/brand5.png" alt="brand" class="img-fluid">
				</div>
				<div class="brand-box-layout3">
					<img src="/img/brand/brand6.png" alt="brand" class="img-fluid">
				</div>
				<div class="brand-box-layout3">
					<img src="/img/brand/brand7.png" alt="brand" class="img-fluid">
				</div>
				<div class="brand-box-layout3">
					<img src="/img/brand/brand8.png" alt="brand" class="img-fluid">
				</div>
				<div class="brand-box-layout3">
					<img src="/img/brand/brand9.png" alt="brand" class="img-fluid">
				</div>
				<div class="brand-box-layout3">
					<img src="/img/brand/brand10.png" alt="brand" class="img-fluid">
				</div>
				<div class="brand-box-layout3">
					<img src="/img/brand/brand5.png" alt="brand" class="img-fluid">
				</div>
			</div>
		</div>
	</section>
	<!-- Brand Area End Here -->