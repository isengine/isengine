<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header1');
$view -> get('module') -> launch('data', 'slider1');
$view -> get('module') -> launch('data', 'about1');
$view -> get('layout') -> launch('blocks', 'departments1');
$view -> get('layout') -> launch('blocks', 'feature1');
$view -> get('layout') -> launch('blocks', 'feature3');
$view -> get('layout') -> launch('blocks', 'award');
$view -> get('module') -> launch('data', 'team1');
$view -> get('layout') -> launch('blocks', 'schedule');
$view -> get('layout') -> launch('blocks', 'banner');
$view -> get('layout') -> launch('blocks', 'blogtestimonials');
$view -> get('layout') -> launch('blocks', 'call1');

?>