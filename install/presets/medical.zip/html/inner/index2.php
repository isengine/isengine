<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header2');
$view -> get('module') -> launch('data', 'slider2');
$view -> get('module') -> launch('data', 'action2');
$view -> get('module') -> launch('data', 'about2');
$view -> get('layout') -> launch('blocks', 'departments2');
$view -> get('module') -> launch('data', 'progress1');
$view -> get('layout') -> launch('blocks', 'feature3');
$view -> get('layout') -> launch('blocks', 'schedule');
$view -> get('module') -> launch('data', 'testimonials1');
$view -> get('module') -> launch('data', 'gallery');
$view -> get('layout') -> launch('blocks', 'banner');
$view -> get('module') -> launch('data', 'blog1');
$view -> get('module') -> launch('data', 'brands');

?>