<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header3');
$view -> get('module') -> launch('data', 'slider3');
$view -> get('module') -> launch('data', 'action3');
$view -> get('module') -> launch('data', 'about3');
$view -> get('layout') -> launch('blocks', 'departments3');
$view -> get('layout') -> launch('blocks', 'feature2');
$view -> get('layout') -> launch('blocks', 'feature3');
$view -> get('module') -> launch('data', 'team2');
$view -> get('layout') -> launch('blocks', 'award');
$view -> get('module') -> launch('data', 'gallery');
$view -> get('layout') -> launch('blocks', 'call1');
$view -> get('layout') -> launch('blocks', 'blogtestimonials');
$view -> get('module') -> launch('data', 'brands');

?>