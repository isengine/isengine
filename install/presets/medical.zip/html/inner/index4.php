<?php

namespace is;
use is\Masters\View;

$view = View::getInstance();

$view -> get('layout') -> launch('blocks', 'header4');
$view -> get('module') -> launch('data', 'slider4');
$view -> get('module') -> launch('data', 'action4');
$view -> get('module') -> launch('data', 'about4');
$view -> get('layout') -> launch('blocks', 'departments4');
$view -> get('layout') -> launch('blocks', 'feature3');
$view -> get('layout') -> launch('blocks', 'award');
$view -> get('module') -> launch('data', 'team3');
$view -> get('layout') -> launch('blocks', 'schedule');
$view -> get('module') -> launch('data', 'progress2');
$view -> get('module') -> launch('data', 'shop');
$view -> get('module') -> launch('data', 'testimonials1');
$view -> get('module') -> launch('data', 'blog2');
$view -> get('layout') -> launch('blocks', 'call2');

?>