	<!-- Inne Page Banner Area Start Here -->
	<section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="/img/figure/figure2.jpg">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumbs-area">
						<h1>All Doctors</h1>
						<ul>
							<li>
								<a href="#">Home</a>
							</li>
							<li>All Doctors</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Inne Page Banner Area End Here -->
	<!-- Special Offer Start Here -->
	<section class="pricing-wrap-layout1 bg-light-accent100">
		<div class="container">
			<div class="section-heading heading-dark text-center heading-layout3">
				<h2>Our Pricing Plan</h2>
				<p>Choose your Affordable Price &amp; Package</p>
			</div>
			<div class="row gutters-20">
				<div class="col-xl-3 col-lg-6 col-md-6 col-12">
					<div class="pricing-box-layout1">
						<h3>Regular</h3>
						<div class="pricing title-bar-primary6">
							<span class="currency">$</span>
							<span class="amount">29</span>
						</div>
						<div class="box-content">
							<ul>
								<li>Dental Implant</li>
								<li>Another Feature</li>
								<li>Another Major Feature</li>
								<li>-</li>
								<li>-</li>
								<li>-</li>
							</ul>
							<a href="#" class="item-btn">Buy Now</a>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-6 col-md-6 col-12">
					<div class="pricing-box-layout1">
						<h3>Standard</h3>
						<div class="pricing title-bar-primary6">
							<span class="currency">$</span>
							<span class="amount">39</span>
						</div>
						<div class="box-content">
							<ul>
								<li>Dental Implant</li>
								<li>Another Feature</li>
								<li>Another Major Feature</li>
								<li>Emergency Care</li>
								<li>-</li>
								<li>-</li>
							</ul>
							<a href="#" class="item-btn">Buy Now</a>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-6 col-md-6 col-12">
					<div class="pricing-box-layout1">
						<h3>Business</h3>
						<div class="pricing title-bar-primary6">
							<span class="currency">$</span>
							<span class="amount">59</span>
						</div>
						<div class="box-content">
							<ul>
								<li>Dental Implant</li>
								<li>Another Feature</li>
								<li>Another Major Feature</li>
								<li>Dental Implant</li>
								<li>Another Feature</li>
								<li>-</li>
							</ul>
							<a href="#" class="item-btn">Buy Now</a>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-6 col-md-6 col-12">
					<div class="pricing-box-layout1">
						<h3>Premium</h3>
						<div class="pricing title-bar-primary6">
							<span class="currency">$</span>
							<span class="amount">99</span>
						</div>
						<div class="box-content">
							<ul>
								<li>Dental Implant</li>
								<li>Another Feature</li>
								<li>Another Major Feature</li>
								<li>Dental Implant</li>
								<li>Another Feature</li>
								<li>Another Major Feature</li>
							</ul>
							<a href="#" class="item-btn">Buy Now</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Special Offer End Here -->
	<!-- Call To Action Start Here -->
	<section class="call-to-action-wrap-layout1">
		<div class="container">
			<div class="row">
				<div class="call-to-action-box-layout1 col-xl-6 col-lg-6 col-md-12 col-12">
					<h2 class="item-title">Do You Need Any Medical Help?</h2>
				</div>
				<div class="call-to-action-box-layout1 col-xl-6 col-lg-6 col-md-12 col-12">
					<h2 class="item-title">
						<i class="fas fa-phone"></i>Please Call Now: +123 884400</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- Call To Action End Here -->