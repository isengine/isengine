	<!-- Inne Page Banner Area Start Here -->
	<section class="inner-page-banner bg-common inner-page-top-margin" data-bg-image="/img/figure/figure2.jpg">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumbs-area">
						<h1>Shop Grid Page</h1>
						<ul>
							<li>
								<a href="#">Home</a>
							</li>
							<li>Shop Page</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Inne Page Banner Area End Here -->
	<!-- Shop Area Start Here -->
	<section class="shop-wrap-layout1 bg-light-primary100">
		<div class="container">
			<div class="row">
				<div class="col-xl-9 col-lg-8 col-12">
					<div class="row">
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop1.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop2.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop3.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop4.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop5.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop2.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop3.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop4.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
						<div class="col-xl-4 col-lg-6 col-md-4 col-sm-6 col-12">
							<div class="shop-box-layout1 margin-b-30">
								<div class="item-img">
									<img src="/img/shop/shop5.png" alt="shop" class="img-fluid">
									<ul class="shop-action-items">
										<li>
											<a href="#">
												<i class="flaticon-shopping-cart"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-exchange-arrows"></i>
											</a>
										</li>
										<li>
											<a href="#">
												<i class="flaticon-favorite-heart-button"></i>
											</a>
										</li>
									</ul>
								</div>
								<div class="item-content">
									<h4 class="item-title">
										<a href="single-shop.html">Medical Bottle</a>
									</h4>
									<div class="rate-items">
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
										<div class="rate-item">
											<i class="fas fa-star"></i>
										</div>
									</div>
									<div class="item-price">$60.00</div>
								</div>
							</div>
						</div>
					</div>
					<ul class="pagination-layout2 margin-t-30">
						<li>
							<a href="#">Previous</a>
						</li>
						<li class="active">
							<a href="#">1</a>
						</li>
						<li>
							<a href="#">2</a>
						</li>
						<li>
							<a href="#">3</a>
						</li>
						<li>
							<a href="#">Next</a>
						</li>
					</ul>
				</div>
				<div class="sidebar-widget-area sidebar-break-md col-xl-3 col-lg-4 col-12">
					<div class="widget widget-categories">
						<h3 class="section-title title-bar-primary">Categories</h3>
						<ul>
							<li>
								<a href="#">Cardiology
									<span>15</span>
								</a>
							</li>
							<li>
								<a href="#">Dental
									<span>10</span>
								</a>
							</li>
							<li>
								<a href="#">Laboratory
									<span>14</span>
								</a>
							</li>
							<li>
								<a href="#">Research
									<span>13</span>
								</a>
							</li>
							<li>
								<a href="#">Eye
									<span>19</span>
								</a>
							</li>
						</ul>
					</div>
					<div class="widget widget-top-rated">
						<h3 class="section-title title-bar-primary">Related Products</h3>
						<ul>
							<li class="media">
								<div class="top-rated-img">
									<a href="#">
										<img src="/img/shop/shop1.jpg" class="img-responsive" alt="related">
									</a>
								</div>
								<div class="media-body space-md top-rated-content">
									<h4>
										<a href="#">Thermometer</a>
									</h4>
									<ul class="rating">
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
									</ul>
									<div class="amount">
										<span class="currency">$</span>15</div>
								</div>
							</li>
							<li class="media">
								<div class="top-rated-img">
									<a href="#">
										<img src="/img/shop/shop1.jpg" class="img-responsive" alt="related">
									</a>
								</div>
								<div class="media-body space-md top-rated-content">
									<h4>
										<a href="#">Thermometer</a>
									</h4>
									<ul class="rating">
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
									</ul>
									<div class="amount">
										<span class="currency">$</span>15</div>
								</div>
							</li>
							<li class="media">
								<div class="top-rated-img">
									<a href="#">
										<img src="/img/shop/shop1.jpg" class="img-responsive" alt="related">
									</a>
								</div>
								<div class="media-body space-md top-rated-content">
									<h4>
										<a href="#">Thermometer</a>
									</h4>
									<ul class="rating">
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
										<li>
											<i class="fa fa-star" aria-hidden="true"></i>
										</li>
									</ul>
									<div class="amount">
										<span class="currency">$</span>15</div>
								</div>
							</li>
						</ul>
					</div>
					<div class="widget widget-price-range">
						<h3 class="section-title title-bar-primary">Filder By Price</h3>
						<div id="price-range-wrapper" class="price-range-wrapper">
							<div id="price-range-filter"></div>
							<div class="price-filter-wrap d-flex align-items-center">
								<div class="price-range-select">
									<div class="price-range">Price:</div>
									<div class="price-range" id="price-range-min"></div>
									<div class="price-range">-</div>
									<div class="price-range" id="price-range-max"></div>
								</div>
								<div class="filter-button">
									<button class="item-btn btn-ghost size-xs radius-4 text-capitalize" type="submit"
										value="Login">Filter</button>
								</div>
							</div>
						</div>
					</div>
					<div class="widget widget-tag">
						<h3 class="section-title title-bar-primary">Tags</h3>
						<ul>
							<li>
								<a href="#">Dental</a>
							</li>
							<li>
								<a href="#">Eye Care</a>
							</li>
							<li>
								<a href="#">Labrotary</a>
							</li>
							<li>
								<a href="#">Care</a>
							</li>
							<li>
								<a href="#">Health</a>
							</li>
							<li>
								<a href="#">Modern Clinic</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Shop Area End Here -->