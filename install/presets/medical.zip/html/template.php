<?php

// Рабочее пространство имен

namespace is;

use is\Helpers\System;
use is\Helpers\Strings;
use is\Helpers\Objects;
use is\Helpers\Paths;
use is\Helpers\Parser;
use is\Helpers\Datetimes;
use is\Components\Display;
use is\Components\Log;
use is\Masters\View;

// читаем

$view = View::getInstance();

// код

$view -> get('layout') -> launch('blocks:default', 'items:opening');

?>

<!-- Preloader Start Here -->
<div id="preloader"></div>
<!-- Preloader End Here -->

<!-- scrollUp Start Here -->
<a href="#wrapper" data-type="section-switch" class="scrollUp">
	<i class="fas fa-angle-double-up"></i>
</a>
<!-- scrollUp End Here -->

<div id="wrapper" class="wrapper">
<?php $view -> get('layout') -> launch('blocks:default', 'items:routing'); ?>
</div>

<?php $view -> get('layout') -> launch('blocks:default', 'items:ending'); ?>